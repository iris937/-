# tests/test_runner.py
"""
Test Runner System for all Linear Algebra exercises
Manages and executes unit tests for each exercise
"""

import importlib
import sys
import os
from typing import Dict, List, Tuple
import traceback

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestRunner:
    def __init__(self):
        self.test_modules = {}
        self.exercise_names = {
            1: "Scalars, Vectors, and Shapes",
            2: "Vector Addition and Scalar Multiplication", 
            3: "Norms and Inner Product",
            4: "Orthogonality and Projection",
            5: "Matrix Multiplication",
            6: "Transpose, Symmetry, Orthogonal Matrices",
            7: "Linear Transformations, Image, Kernel",
            8: "Rank, Low-Rank Factorizations, LoRA",
            9: "Singular Value Decomposition (SVD)",
            10: "Eigenvalues and Eigenvectors",
            11: "Final Integrative Exercise"
        }
        self.load_test_modules()
    
    def load_test_modules(self):
        """Load all available test modules"""
        for i in range(1, 12):
            try:
                module_name = f"tests.test_exercise_{i}"
                module = importlib.import_module(module_name)
                self.test_modules[i] = module
            except ImportError:
                # Test module doesn't exist yet
                self.test_modules[i] = None
    
    def run_single_test(self, exercise_num: int) -> bool:
        """Run test for a single exercise"""
        if exercise_num not in range(1, 12):
            print(f"❌ Invalid exercise number: {exercise_num}")
            return False
        
        exercise_name = self.exercise_names[exercise_num]
        print(f"\n{'='*60}")
        print(f"RUNNING TEST: Exercise {exercise_num} - {exercise_name}")
        print('='*60)
        
        test_module = self.test_modules.get(exercise_num)
        if test_module is None:
            print(f"⚠️  Test module for Exercise {exercise_num} not found!")
            print("Creating placeholder test...")
            return self.create_placeholder_test(exercise_num)
        
        try:
            # Look for test functions in the module
            test_functions = [attr for attr in dir(test_module) 
                            if attr.startswith('test_') and callable(getattr(test_module, attr))]
            
            if not test_functions:
                print(f"⚠️  No test functions found in test module for Exercise {exercise_num}")
                return False
            
            passed_tests = 0
            total_tests = len(test_functions)
            
            for test_func_name in test_functions:
                print(f"\n▶ Running {test_func_name}...")
                test_func = getattr(test_module, test_func_name)
                
                try:
                    result = test_func()
                    if result:
                        print(f"✓ {test_func_name} PASSED")
                        passed_tests += 1
                    else:
                        print(f"❌ {test_func_name} FAILED")
                except Exception as e:
                    print(f"❌ {test_func_name} ERROR: {e}")
                    traceback.print_exc()
            
            # Print summary
            print(f"\n📊 TEST SUMMARY for Exercise {exercise_num}:")
            print(f"   Passed: {passed_tests}/{total_tests}")
            print(f"   Success Rate: {(passed_tests/total_tests)*100:.1f}%")
            
            if passed_tests == total_tests:
                print(f"🎉 All tests PASSED for Exercise {exercise_num}!")
                return True
            else:
                print(f"⚠️  Some tests FAILED for Exercise {exercise_num}")
                return False
                
        except Exception as e:
            print(f"❌ Error running tests for Exercise {exercise_num}: {e}")
            traceback.print_exc()
            return False
    
    def run_all_tests(self) -> Dict[int, bool]:
        """Run tests for all exercises"""
        print("\n" + "="*70)
        print("RUNNING ALL EXERCISE TESTS")
        print("="*70)
        
        results = {}
        passed_exercises = 0
        
        for exercise_num in range(1, 12):
            print(f"\n{'-'*50}")
            result = self.run_single_test(exercise_num)
            results[exercise_num] = result
            if result:
                passed_exercises += 1
        
        # Overall summary
        print(f"\n{'='*70}")
        print("OVERALL TEST RESULTS")
        print("="*70)
        
        for exercise_num, passed in results.items():
            status = "✓ PASSED" if passed else "❌ FAILED"
            print(f"Exercise {exercise_num:2d}: {self.exercise_names[exercise_num]:40} {status}")
        
        print(f"\nOVERALL SUMMARY:")
        print(f"Exercises Passed: {passed_exercises}/11")
        print(f"Success Rate: {(passed_exercises/11)*100:.1f}%")
        
        if passed_exercises == 11:
            print("🎊 ALL TESTS PASSED! Excellent work!")
        else:
            print(f"⚠️  {11-passed_exercises} exercise(s) need attention")
        
        return results
    
    def create_placeholder_test(self, exercise_num: int) -> bool:
        """Create a placeholder test when test module is missing"""
        try:
            # Try to import and run the exercise directly
            module_name = f"exercises.exercise_{exercise_num}"
            exercise_module = importlib.import_module(module_name)
            
            # Look for a test function in the exercise module
            if hasattr(exercise_module, f'test_exercise_{exercise_num}'):
                test_func = getattr(exercise_module, f'test_exercise_{exercise_num}')
                print(f"▶ Running embedded test function...")
                result = test_func()
                return result
            else:
                print(f"⚠️  No test function found. Creating basic validation...")
                return self.basic_exercise_validation(exercise_num, exercise_module)
                
        except ImportError:
            print(f"❌ Exercise {exercise_num} module not found!")
            return False
        except Exception as e:
            print(f"❌ Error creating placeholder test: {e}")
            return False
    
    def basic_exercise_validation(self, exercise_num: int, exercise_module) -> bool:
        """Perform basic validation of an exercise module"""
        try:
            # Check if exercise class exists
            class_name = f"Exercise{exercise_num}"
            if not hasattr(exercise_module, class_name):
                print(f"❌ Class {class_name} not found in module")
                return False
            
            # Try to instantiate the exercise
            exercise_class = getattr(exercise_module, class_name)
            
            # Mock logging system
            class MockLoggingSystem:
                def set_current_exercise(self, ex_num, step): pass
                def complete_step(self, ex_num, step): pass
                def complete_exercise(self, ex_num): pass
                def log_student_response(self, ex_num, step, question, response): pass
            
            mock_logger = MockLoggingSystem()
            exercise = exercise_class(mock_logger)
            
            # Basic method checks
            required_methods = [
                'get_concept_explanation',
                'get_concept_question', 
                'get_required_parameters',
                'execute_exercise',
                'get_result_explanation_question'
            ]
            
            for method in required_methods:
                if not hasattr(exercise, method):
                    print(f"❌ Required method {method} not found")
                    return False
                if not callable(getattr(exercise, method)):
                    print(f"❌ {method} is not callable")
                    return False
            
            print("✓ Basic structure validation passed")
            
            # Try to get concept explanation
            try:
                explanation = exercise.get_concept_explanation()
                if not explanation or len(explanation.strip()) < 10:
                    print("⚠️  Concept explanation seems too short")
                else:
                    print("✓ Concept explanation validated")
            except Exception as e:
                print(f"❌ Error getting concept explanation: {e}")
                return False
            
            # Try to get required parameters
            try:
                params = exercise.get_required_parameters()
                if not isinstance(params, dict):
                    print("❌ get_required_parameters should return a dictionary")
                    return False
                print(f"✓ Required parameters validated: {list(params.keys())}")
            except Exception as e:
                print(f"❌ Error getting required parameters: {e}")
                return False
            
            print(f"✓ Basic validation completed for Exercise {exercise_num}")
            return True
            
        except Exception as e:
            print(f"❌ Basic validation failed: {e}")
            return False
    
    def generate_test_report(self, results: Dict[int, bool]) -> str:
        """Generate a detailed test report"""
        report = []
        report.append("LINEAR ALGEBRA EXERCISES - TEST REPORT")
        report.append("=" * 50)
        report.append(f"Generated: {os.popen('date').read().strip()}")
        report.append("")
        
        passed = sum(results.values())
        total = len(results)
        
        report.append(f"SUMMARY: {passed}/{total} exercises passed ({(passed/total)*100:.1f}%)")
        report.append("")
        
        report.append("DETAILED RESULTS:")
        report.append("-" * 20)
        
        for exercise_num, passed in results.items():
            status = "PASS" if passed else "FAIL"
            exercise_name = self.exercise_names.get(exercise_num, f"Exercise {exercise_num}")
            report.append(f"Exercise {exercise_num:2d}: {exercise_name:40} [{status}]")
        
        report.append("")
        
        if passed < total:
            failed_exercises = [num for num, result in results.items() if not result]
            report.append("FAILED EXERCISES:")
            for ex_num in failed_exercises:
                report.append(f"  - Exercise {ex_num}: {self.exercise_names[ex_num]}")
        
        return "\n".join(report)
    
    def save_test_report(self, results: Dict[int, bool], filename: str = None):
        """Save test report to file"""
        if filename is None:
            from datetime import datetime
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"test_report_{timestamp}.txt"
        
        report = self.generate_test_report(results)
        
        os.makedirs("logs", exist_ok=True)
        filepath = os.path.join("logs", filename)
        
        with open(filepath, 'w') as f:
            f.write(report)
        
        print(f"📄 Test report saved to: {filepath}")
        return filepath

def main():
    """Test the test runner itself"""
    runner = TestRunner()
    
    print("Test Runner System Initialized")
    print(f"Available tests: {list(runner.test_modules.keys())}")
    
    # Run a single test as example
    if 1 in runner.test_modules:
        runner.run_single_test(1)

if __name__ == "__main__":
    main()