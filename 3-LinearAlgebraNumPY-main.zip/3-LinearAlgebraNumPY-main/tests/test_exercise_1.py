# tests/test_exercise_1.py
"""
Unit tests for Exercise 1: Scalars, Vectors, and Shapes
Tests all functionality and edge cases
"""

import sys
import os
import numpy as np
import unittest
from unittest.mock import Mock, patch
from io import StringIO

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from exercises.exercise_1 import Exercise1

class TestExercise1(unittest.TestCase):
    def setUp(self):
        """Set up test fixtures"""
        # Mock logging system
        self.mock_logger = Mock()
        self.exercise = Exercise1(self.mock_logger)
    
    def test_concept_explanation(self):
        """Test that concept explanation exists and is comprehensive"""
        explanation = self.exercise.get_concept_explanation()
        
        # Check explanation exists and has content
        self.assertIsInstance(explanation, str)
        self.assertGreater(len(explanation), 100)
        
        # Check key concepts are mentioned
        explanation_lower = explanation.lower()
        key_concepts = ['scalar', 'vector', 'shape', 'numpy', 'deep learning']
        
        for concept in key_concepts:
            self.assertIn(concept, explanation_lower, 
                         f"Concept '{concept}' not found in explanation")
        
        print("✓ Concept explanation test passed")
    
    def test_concept_question(self):
        """Test that concept question is meaningful"""
        question = self.exercise.get_concept_question()
        
        self.assertIsInstance(question, str)
        self.assertGreater(len(question), 20)
        
        # Should ask about difference between scalar and vector
        question_lower = question.lower()
        self.assertIn('scalar', question_lower)
        self.assertIn('vector', question_lower)
        
        print("✓ Concept question test passed")
    
    def test_required_parameters(self):
        """Test required parameters structure"""
        params = self.exercise.get_required_parameters()
        
        self.assertIsInstance(params, dict)
        self.assertGreater(len(params), 0)
        
        # Check expected parameters exist
        expected_params = ['vector1_size', 'vector2_size', 'scalar_value']
        for param in expected_params:
            self.assertIn(param, params, f"Parameter '{param}' missing")
        
        # Check all values are strings (descriptions)
        for param, description in params.items():
            self.assertIsInstance(description, str)
            self.assertGreater(len(description), 5)
        
        print("✓ Required parameters test passed")
    
    def test_execute_exercise_basic(self):
        """Test basic exercise execution"""
        test_params = {
            "vector1_size": 5,
            "vector2_size": 3,
            "scalar_value": 2.5
        }
        
        # Suppress matplotlib output during testing
        with patch('matplotlib.pyplot.show'):
            results = self.exercise.execute_exercise(test_params)
        
        # Check results structure
        self.assertIsInstance(results, dict)
        
        # Check required result keys
        required_keys = ['vector1', 'vector2', 'scalar', 'properties', 'row_vector', 'column_vector']
        for key in required_keys:
            self.assertIn(key, results, f"Result key '{key}' missing")
        
        # Validate vector1
        vector1 = results['vector1']
        self.assertIsInstance(vector1, np.ndarray)
        self.assertEqual(len(vector1), 5)
        self.assertEqual(vector1.shape, (5,))
        
        # Validate vector2
        vector2 = results['vector2']
        self.assertIsInstance(vector2, np.ndarray)
        self.assertEqual(len(vector2), 3)
        self.assertEqual(vector2.shape, (3,))
        
        # Validate scalar
        self.assertEqual(results['scalar'], 2.5)
        
        # Validate shape transformations
        row_vector = results['row_vector']
        column_vector = results['column_vector']
        
        self.assertEqual(row_vector.shape, (1, 5))
        self.assertEqual(column_vector.shape, (5, 1))
        
        # Check that transformations preserve data
        np.testing.assert_array_equal(vector1, row_vector.flatten())
        np.testing.assert_array_equal(vector1, column_vector.flatten())
        
        print("✓ Basic exercise execution test passed")
    
    def test_execute_exercise_edge_cases(self):
        """Test exercise with edge case parameters"""
        edge_cases = [
            {"vector1_size": 1, "vector2_size": 1, "scalar_value": 0},
            {"vector1_size": 10, "vector2_size": 2, "scalar_value": -1.5},
            {"vector1_size": 2, "vector2_size": 8, "scalar_value": 100.0}
        ]
        
        for i, test_params in enumerate(edge_cases):
            with self.subTest(case=i):
                with patch('matplotlib.pyplot.show'):
                    results = self.exercise.execute_exercise(test_params)
                
                # Basic structure checks
                self.assertIsInstance(results, dict)
                self.assertIn('vector1', results)
                self.assertIn('vector2', results)
                
                # Size validation
                self.assertEqual(len(results['vector1']), test_params['vector1_size'])
                self.assertEqual(len(results['vector2']), test_params['vector2_size'])
                self.assertEqual(results['scalar'], test_params['scalar_value'])
        
        print("✓ Edge cases test passed")
    
    def test_result_explanation_question(self):
        """Test result explanation question generation"""
        test_params = {
            "vector1_size": 4,
            "vector2_size": 3,
            "scalar_value": 2.0
        }
        
        with patch('matplotlib.pyplot.show'):
            results = self.exercise.execute_exercise(test_params)
        
        question = self.exercise.get_result_explanation_question(results)
        
        self.assertIsInstance(question, str)
        self.assertGreater(len(question), 50)
        
        # Should reference the specific results
        question_str = str(question)
        self.assertIn('Vector 1', question_str)
        self.assertIn('Vector 2', question_str)
        self.assertIn(str(test_params['scalar_value']), question_str)
        
        print("✓ Result explanation question test passed")
    
    def test_properties_calculation(self):
        """Test that vector properties are calculated correctly"""
        test_params = {
            "vector1_size": 4,
            "vector2_size": 3, 
            "scalar_value": 2.0
        }
        
        with patch('matplotlib.pyplot.show'):
            results = self.exercise.execute_exercise(test_params)
        
        vector1 = results['vector1']
        properties = results['properties']
        
        # Check Vector 1 properties
        v1_props = properties['Vector 1']
        
        self.assertEqual(v1_props['shape'], vector1.shape)
        self.assertEqual(v1_props['sum'], np.sum(vector1))
        self.assertEqual(v1_props['mean'], np.mean(vector1))
        self.assertEqual(v1_props['length'], len(vector1))
        np.testing.assert_array_equal(v1_props['values'], vector1)
        
        print("✓ Properties calculation test passed")
    
    def test_shape_transformations(self):
        """Test vector shape transformations"""
        test_params = {
            "vector1_size": 6,
            "vector2_size": 4,
            "scalar_value": 1.0
        }
        
        with patch('matplotlib.pyplot.show'):
            results = self.exercise.execute_exercise(test_params)
        
        vector1 = results['vector1']
        row_vector = results['row_vector']
        column_vector = results['column_vector']
        
        # Test shapes
        self.assertEqual(vector1.shape, (6,))
        self.assertEqual(row_vector.shape, (1, 6))
        self.assertEqual(column_vector.shape, (6, 1))
        
        # Test data preservation
        np.testing.assert_array_equal(vector1, row_vector.flatten())
        np.testing.assert_array_equal(vector1, column_vector.flatten())
        
        # Test transpose relationships
        np.testing.assert_array_equal(row_vector.T, column_vector)
        np.testing.assert_array_equal(column_vector.T, row_vector)
        
        print("✓ Shape transformations test passed")
    
    def test_inheritance_and_methods(self):
        """Test that exercise properly inherits from ExerciseBase"""
        from exercise_base import ExerciseBase
        
        self.assertIsInstance(self.exercise, ExerciseBase)
        
        # Check required methods exist
        required_methods = [
            'define_steps',
            'get_concept_explanation',
            'get_concept_question',
            'execute_exercise',
            'get_result_explanation_question',
            'get_required_parameters'
        ]
        
        for method in required_methods:
            self.assertTrue(hasattr(self.exercise, method))
            self.assertTrue(callable(getattr(self.exercise, method)))
        
        # Check exercise properties
        self.assertEqual(self.exercise.exercise_num, 1)
        self.assertEqual(self.exercise.title, "Scalars, Vectors, and Shapes")
        
        print("✓ Inheritance and methods test passed")

# Standalone test functions for compatibility with test runner
def test_exercise_1_comprehensive():
    """Comprehensive test function for Exercise 1"""
    print("Running comprehensive test for Exercise 1...")
    
    # Run all unit tests
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestExercise1)
    
    # Capture test output
    stream = StringIO()
    runner = unittest.TextTestRunner(stream=stream, verbosity=2)
    result = runner.run(suite)
    
    # Print summary
    if result.wasSuccessful():
        print(f"✓ All {result.testsRun} tests passed!")
        return True
    else:
        print(f"❌ {len(result.failures)} failures, {len(result.errors)} errors")
        for test, error in result.failures + result.errors:
            print(f"   - {test}: {error}")
        return False

def test_exercise_1_basic():
    """Basic functionality test for Exercise 1"""
    print("Running basic test for Exercise 1...")
    
    try:
        # Mock logging system
        class MockLoggingSystem:
            def set_current_exercise(self, ex_num, step): pass
            def complete_step(self, ex_num, step): pass
            def complete_exercise(self, ex_num): pass
            def log_student_response(self, ex_num, step, question, response): pass
        
        mock_logger = MockLoggingSystem()
        exercise = Exercise1(mock_logger)
        
        # Test basic methods
        explanation = exercise.get_concept_explanation()
        assert len(explanation) > 100, "Concept explanation too short"
        
        question = exercise.get_concept_question()
        assert len(question) > 20, "Concept question too short"
        
        params = exercise.get_required_parameters()
        assert isinstance(params, dict), "Parameters not a dictionary"
        assert len(params) >= 3, "Not enough parameters"
        
        # Test execution with sample parameters
        test_params = {
            "vector1_size": 5,
            "vector2_size": 3,
            "scalar_value": 2.5
        }
        
        with patch('matplotlib.pyplot.show'):
            results = exercise.execute_exercise(test_params)
        
        assert isinstance(results, dict), "Results not a dictionary"
        assert 'vector1' in results, "vector1 missing from results"
        assert 'vector2' in results, "vector2 missing from results"
        
        result_question = exercise.get_result_explanation_question(results)
        assert len(result_question) > 50, "Result question too short"
        
        print("✓ Exercise 1 basic test completed successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Exercise 1 basic test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_exercise_1_quick():
    """Quick smoke test for Exercise 1"""
    try:
        from exercises.exercise_1 import Exercise1
        print("✓ Exercise 1 module imports successfully")
        return True
    except Exception as e:
        print(f"❌ Exercise 1 import failed: {e}")
        return False

if __name__ == "__main__":
    # Run tests when executed directly
    print("Running Exercise 1 Tests...")
    print("=" * 40)
    
    success = test_exercise_1_comprehensive()
    if success:
        print("\n🎉 All Exercise 1 tests passed!")
    else:
        print("\n⚠️  Some Exercise 1 tests failed")
    
    exit(0 if success else 1)