# tests/test_exercise_2.py
"""
Unit tests for Exercise 2: Vector Addition and Scalar Multiplication
Tests vector operations and their properties
"""

import sys
import os
import numpy as np
import unittest
from unittest.mock import Mock, patch
from io import StringIO

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from exercises.exercise_2 import Exercise2

class TestExercise2(unittest.TestCase):
    def setUp(self):
        """Set up test fixtures"""
        # Mock logging system
        self.mock_logger = Mock()
        self.exercise = Exercise2(self.mock_logger)
    
    def test_concept_explanation(self):
        """Test that concept explanation covers vector operations"""
        explanation = self.exercise.get_concept_explanation()
        
        self.assertIsInstance(explanation, str)
        self.assertGreater(len(explanation), 200)
        
        # Check key concepts are mentioned
        explanation_lower = explanation.lower()
        key_concepts = ['vector addition', 'scalar multiplication', 'component-wise', 
                       'residual', 'transformer', 'magnitude', 'direction']
        
        for concept in key_concepts:
            self.assertIn(concept, explanation_lower, 
                         f"Concept '{concept}' not found in explanation")
        
        print("✓ Concept explanation test passed")
    
    def test_required_parameters(self):
        """Test required parameters structure"""
        params = self.exercise.get_required_parameters()
        
        self.assertIsInstance(params, dict)
        
        expected_params = ['vector_dimension', 'num_random_vectors', 'scalar_positive', 
                          'scalar_negative', 'scalar_fractional']
        for param in expected_params:
            self.assertIn(param, params, f"Parameter '{param}' missing")
        
        print("✓ Required parameters test passed")
    
    def test_execute_exercise_2d(self):
        """Test exercise execution with 2D vectors"""
        test_params = {
            "vector_dimension": 2,
            "num_random_vectors": 3,
            "scalar_positive": 1.5,
            "scalar_negative": -0.8,
            "scalar_fractional": 0.3
        }
        
        with patch('matplotlib.pyplot.show'):
            results = self.exercise.execute_exercise(test_params)
        
        # Check results structure
        self.assertIsInstance(results, dict)
        required_keys = ['vectors_u', 'vectors_v', 'dimension', 'num_vectors', 'scalars', 'results_data']
        for key in required_keys:
            self.assertIn(key, results)
        
        # Check dimensions
        self.assertEqual(results['dimension'], 2)
        self.assertEqual(results['num_vectors'], 3)
        self.assertEqual(results['vectors_u'].shape, (3, 2))
        self.assertEqual(results['vectors_v'].shape, (3, 2))
        
        # Check scalars
        scalars = results['scalars']
        self.assertEqual(scalars['positive'], 1.5)
        self.assertEqual(scalars['negative'], -0.8)
        self.assertEqual(scalars['fractional'], 0.3)
        
        print("✓ 2D exercise execution test passed")
    
    def test_vector_operations_correctness(self):
        """Test that vector operations are computed correctly"""
        test_params = {
            "vector_dimension": 3,
            "num_random_vectors": 2,
            "scalar_positive": 2.0,
            "scalar_negative": -1.0,
            "scalar_fractional": 0.5
        }
        
        with patch('matplotlib.pyplot.show'):
            results = self.exercise.execute_exercise(test_params)
        
        results_data = results['results_data']
        self.assertEqual(len(results_data), 2)
        
        for data in results_data:
            u = data['u']
            v = data['v']
            u_plus_v = data['u_plus_v']
            alpha_pos_u = data['alpha_pos_u']
            alpha_neg_u = data['alpha_neg_u']
            alpha_frac_u = data['alpha_frac_u']
            
            # Test vector addition
            expected_sum = u + v
            np.testing.assert_array_almost_equal(u_plus_v, expected_sum)
            
            # Test scalar multiplications
            np.testing.assert_array_almost_equal(alpha_pos_u, 2.0 * u)
            np.testing.assert_array_almost_equal(alpha_neg_u, -1.0 * u)
            np.testing.assert_array_almost_equal(alpha_frac_u, 0.5 * u)
            
            # Test magnitude relationships
            mags = data['magnitudes']
            self.assertAlmostEqual(mags['mag_u'], np.linalg.norm(u))
            self.assertAlmostEqual(mags['mag_pos'], 2.0 * np.linalg.norm(u))
            self.assertAlmostEqual(mags['mag_neg'], np.linalg.norm(u))  # Absolute value
            self.assertAlmostEqual(mags['mag_frac'], 0.5 * np.linalg.norm(u))
        
        print("✓ Vector operations correctness test passed")
    
    def test_scalar_multiplication_properties(self):
        """Test scalar multiplication properties"""
        test_params = {
            "vector_dimension": 4,
            "num_random_vectors": 1,
            "scalar_positive": 3.0,
            "scalar_negative": -2.0,
            "scalar_fractional": 0.25
        }
        
        with patch('matplotlib.pyplot.show'):
            results = self.exercise.execute_exercise(test_params)
        
        data = results['results_data'][0]
        u = data['u']
        
        # Test scaling properties
        pos_scaled = data['alpha_pos_u']
        neg_scaled = data['alpha_neg_u']
        frac_scaled = data['alpha_frac_u']
        
        # Check that positive scaling preserves direction
        if np.linalg.norm(u) > 0:
            u_normalized = u / np.linalg.norm(u)
            pos_normalized = pos_scaled / np.linalg.norm(pos_scaled)
            np.testing.assert_array_almost_equal(u_normalized, pos_normalized)
        
        # Check that negative scaling reverses direction
        if np.linalg.norm(u) > 0 and np.linalg.norm(neg_scaled) > 0:
            u_normalized = u / np.linalg.norm(u)
            neg_normalized = neg_scaled / np.linalg.norm(neg_scaled)
            np.testing.assert_array_almost_equal(u_normalized, -neg_normalized)
        
        # Check magnitude scaling
        self.assertAlmostEqual(np.linalg.norm(pos_scaled), 3.0 * np.linalg.norm(u), places=10)
        self.assertAlmostEqual(np.linalg.norm(neg_scaled), 2.0 * np.linalg.norm(u), places=10)
        self.assertAlmostEqual(np.linalg.norm(frac_scaled), 0.25 * np.linalg.norm(u), places=10)
        
        print("✓ Scalar multiplication properties test passed")
    
    def test_vector_addition_properties(self):
        """Test vector addition properties (commutativity, etc.)"""
        # Create deterministic vectors for testing
        u = np.array([1.0, 2.0, 3.0])
        v = np.array([4.0, -1.0, 2.0])
        
        # Test commutativity: u + v = v + u
        sum1 = u + v
        sum2 = v + u
        np.testing.assert_array_almost_equal(sum1, sum2)
        
        # Test with zero vector
        zero = np.zeros_like(u)
        sum_with_zero = u + zero
        np.testing.assert_array_almost_equal(u, sum_with_zero)
        
        # Test associativity with third vector
        w = np.array([0.5, -2.0, 1.5])
        sum_assoc1 = (u + v) + w
        sum_assoc2 = u + (v + w)
        np.testing.assert_array_almost_equal(sum_assoc1, sum_assoc2)
        
        print("✓ Vector addition properties test passed")
    
    def test_edge_cases(self):
        """Test edge cases and boundary conditions"""
        edge_cases = [
            {"vector_dimension": 1, "num_random_vectors": 1, "scalar_positive": 1.0, 
             "scalar_negative": -1.0, "scalar_fractional": 0.1},
            {"vector_dimension": 5, "num_random_vectors": 1, "scalar_positive": 0.0, 
             "scalar_negative": -0.0, "scalar_fractional": 1.0},
            {"vector_dimension": 2, "num_random_vectors": 1, "scalar_positive": 100.0, 
             "scalar_negative": -100.0, "scalar_fractional": 0.001}
        ]
        
        for i, test_params in enumerate(edge_cases):
            with self.subTest(case=i):
                with patch('matplotlib.pyplot.show'):
                    results = self.exercise.execute_exercise(test_params)
                
                self.assertIsInstance(results, dict)
                self.assertEqual(results['dimension'], test_params['vector_dimension'])
                self.assertEqual(results['num_vectors'], test_params['num_random_vectors'])
        
        print("✓ Edge cases test passed")
    
    def test_result_explanation_question(self):
        """Test result explanation question generation"""
        test_params = {
            "vector_dimension": 2,
            "num_random_vectors": 2,
            "scalar_positive": 1.5,
            "scalar_negative": -0.7,
            "scalar_fractional": 0.4
        }
        
        with patch('matplotlib.pyplot.show'):
            results = self.exercise.execute_exercise(test_params)
        
        question = self.exercise.get_result_explanation_question(results)
        
        self.assertIsInstance(question, str)
        self.assertGreater(len(question), 100)
        
        # Should reference the specific scalars used
        question_str = str(question)
        self.assertIn('1.5', question_str)
        self.assertIn('-0.7', question_str)
        self.assertIn('0.4', question_str)
        
        print("✓ Result explanation question test passed")
    
    def test_inheritance_and_methods(self):
        """Test that exercise properly inherits from ExerciseBase"""
        from exercise_base import ExerciseBase
        
        self.assertIsInstance(self.exercise, ExerciseBase)
        
        # Check exercise properties
        self.assertEqual(self.exercise.exercise_num, 2)
        self.assertEqual(self.exercise.title, "Vector Addition and Scalar Multiplication")
        
        print("✓ Inheritance and methods test passed")

# Standalone test functions for compatibility with test runner
def test_exercise_2_comprehensive():
    """Comprehensive test function for Exercise 2"""
    print("Running comprehensive test for Exercise 2...")
    
    loader = unittest.TestLoader()
    suite = loader.loadTestsFromTestCase(TestExercise2)
    
    stream = StringIO()
    runner = unittest.TextTestRunner(stream=stream, verbosity=2)
    result = runner.run(suite)
    
    if result.wasSuccessful():
        print(f"✓ All {result.testsRun} tests passed!")
        return True
    else:
        print(f"❌ {len(result.failures)} failures, {len(result.errors)} errors")
        for test, error in result.failures + result.errors:
            print(f"   - {test}: {error}")
        return False

def test_exercise_2_basic():
    """Basic functionality test for Exercise 2"""
    print("Running basic test for Exercise 2...")
    
    try:
        class MockLoggingSystem:
            def set_current_exercise(self, ex_num, step): pass
            def complete_step(self, ex_num, step): pass
            def complete_exercise(self, ex_num): pass
            def log_student_response(self, ex_num, step, question, response): pass
        
        mock_logger = MockLoggingSystem()
        exercise = Exercise2(mock_logger)
        
        # Test basic methods
        explanation = exercise.get_concept_explanation()
        assert len(explanation) > 100, "Concept explanation too short"
        
        params = exercise.get_required_parameters()
        assert isinstance(params, dict), "Parameters not a dictionary"
        
        # Test execution
        test_params = {
            "vector_dimension": 2,
            "num_random_vectors": 2,
            "scalar_positive": 2.0,
            "scalar_negative": -1.0,
            "scalar_fractional": 0.5
        }
        
        with patch('matplotlib.pyplot.show'):
            results = exercise.execute_exercise(test_params)
        
        assert isinstance(results, dict), "Results not a dictionary"
        assert 'vectors_u' in results, "vectors_u missing from results"
        
        print("✓ Exercise 2 basic test completed successfully!")
        return True
        
    except Exception as e:
        print(f"❌ Exercise 2 basic test failed: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("Running Exercise 2 Tests...")
    print("=" * 40)
    
    success = test_exercise_2_comprehensive()
    if success:
        print("\n🎉 All Exercise 2 tests passed!")
    else:
        print("\n⚠️  Some Exercise 2 tests failed")
    
    exit(0 if success else 1)