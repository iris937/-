# main.py
"""
Linear Algebra Foundations for Transformers and LoRA: Interactive Learning System
Main program with menu system and exercise management
"""

import os
import sys
import json
from datetime import datetime
from typing import Dict, Any

# Import exercise modules
from exercises.exercise_1 import Exercise1
from exercises.exercise_2 import Exercise2
from exercises.exercise_3 import Exercise3
from exercises.exercise_4 import Exercise4
from exercises.exercise_5 import Exercise5
from exercises.exercise_6 import Exercise6
from exercises.exercise_7 import Exercise7
from exercises.exercise_8 import Exercise8
from exercises.exercise_9 import Exercise9
from exercises.exercise_10 import Exercise10
from exercises.exercise_11 import Exercise11

# Import test modules
from tests.test_runner import TestRunner
from logging_system import LoggingSystem

class LinearAlgebraLearningSystem:
    def __init__(self):
        self.logging_system = LoggingSystem()
        self.test_runner = TestRunner()
        self.exercises = {
            1: Exercise1,
            2: Exercise2,
            3: Exercise3,
            4: Exercise4,
            5: Exercise5,
            6: Exercise6,
            7: Exercise7,
            8: Exercise8,
            9: Exercise9,
            10: Exercise10,
            11: Exercise11
        }
        self.exercise_names = {
            1: "Scalars, Vectors, and Shapes",
            2: "Vector Addition and Scalar Multiplication",
            3: "Norms and Inner Product",
            4: "Orthogonality and Projection",
            5: "Matrix Multiplication",
            6: "Transpose, Symmetry, Orthogonal Matrices",
            7: "Linear Transformations, Image, Kernel",
            8: "Rank, Low-Rank Factorizations, LoRA",
            9: "Singular Value Decomposition (SVD)",
            10: "Eigenvalues and Eigenvectors",
            11: "Final Integrative Exercise"
        }
        
    def display_main_menu(self):
        """Display the main menu options"""
        print("\n" + "="*60)
        print("LINEAR ALGEBRA FOUNDATIONS FOR TRANSFORMERS AND LORA")
        print("Interactive Learning System")
        print("="*60)
        print("\n1. Start/Continue Learning Exercises")
        print("2. Run Individual Exercise")
        print("3. Run All Test Units")
        print("4. Run Individual Test Unit")
        print("5. View Learning Progress")
        print("6. Reset Progress")
        print("7. Exit")
        print("\nChoose an option (1-7): ", end="")

    def display_exercise_menu(self):
        """Display the exercise selection menu"""
        print("\n" + "="*50)
        print("EXERCISE SELECTION")
        print("="*50)
        for num, name in self.exercise_names.items():
            status = self.logging_system.get_exercise_status(num)
            print(f"{num:2d}. {name} [{status}]")
        print("\n0. Return to main menu")
        print("\nChoose exercise (0-11): ", end="")

    def check_resume_session(self):
        """Check if there's an existing session to resume"""
        progress = self.logging_system.load_progress()
        if progress and progress.get('current_exercise') and progress.get('current_step'):
            current_ex = progress['current_exercise']
            current_step = progress['current_step']
            
            print(f"\nFound existing session:")
            print(f"Exercise {current_ex}: {self.exercise_names[current_ex]}")
            print(f"Last step: {current_step}")
            
            choice = input("\nDo you want to resume from where you left off? (y/n): ").lower()
            if choice == 'y':
                return current_ex, current_step
            else:
                choice = input("Start fresh? This will backup current progress (y/n): ").lower()
                if choice == 'y':
                    self.logging_system.backup_progress()
                    self.logging_system.start_new_session()
                    return None, None
        return None, None

    def run_exercise(self, exercise_num: int, resume_step: str = None):
        """Run a specific exercise"""
        if exercise_num not in self.exercises:
            print(f"Exercise {exercise_num} not found!")
            return
            
        exercise_class = self.exercises[exercise_num]
        exercise = exercise_class(self.logging_system)
        
        print(f"\n{'='*60}")
        print(f"EXERCISE {exercise_num}: {self.exercise_names[exercise_num]}")
        print('='*60)
        
        # Ask if they want to solve or just run tests
        print("\nOptions:")
        print("1. Start learning (step-by-step solving)")
        print("2. Run test unit only")
        choice = input("Choose option (1-2): ").strip()
        
        if choice == "2":
            return self.test_runner.run_single_test(exercise_num)
        elif choice == "1":
            return exercise.run(resume_step)
        else:
            print("Invalid choice!")
            return False

    def start_learning_sequence(self):
        """Start or continue the learning sequence"""
        resume_ex, resume_step = self.check_resume_session()
        
        if resume_ex:
            # Resume from specific exercise
            success = self.run_exercise(resume_ex, resume_step)
            if not success:
                return
            start_from = resume_ex + 1
        else:
            start_from = 1
            
        # Continue with remaining exercises
        for ex_num in range(start_from, 12):
            continue_choice = input(f"\nReady for Exercise {ex_num}? (y/n/q to quit): ").lower()
            if continue_choice == 'q':
                break
            elif continue_choice == 'y':
                success = self.run_exercise(ex_num)
                if not success:
                    break
            else:
                print("Skipping exercise...")
                
        print("\nLearning session completed!")

    def view_progress(self):
        """Display learning progress"""
        progress = self.logging_system.load_progress()
        if not progress:
            print("\nNo progress found!")
            return
            
        print("\n" + "="*50)
        print("LEARNING PROGRESS")
        print("="*50)
        
        for ex_num in range(1, 12):
            status = self.logging_system.get_exercise_status(ex_num)
            print(f"Exercise {ex_num:2d}: {self.exercise_names[ex_num]:40} [{status}]")
            
        if 'session_start' in progress:
            print(f"\nSession started: {progress['session_start']}")
        if 'last_activity' in progress:
            print(f"Last activity: {progress['last_activity']}")

    def run(self):
        """Main program loop"""
        print("Welcome to Linear Algebra Foundations Learning System!")
        
        while True:
            self.display_main_menu()
            choice = input().strip()
            
            if choice == '1':
                self.start_learning_sequence()
            elif choice == '2':
                self.display_exercise_menu()
                ex_choice = input().strip()
                if ex_choice.isdigit() and 1 <= int(ex_choice) <= 11:
                    self.run_exercise(int(ex_choice))
                elif ex_choice == '0':
                    continue
                else:
                    print("Invalid choice!")
            elif choice == '3':
                self.test_runner.run_all_tests()
            elif choice == '4':
                self.display_exercise_menu()
                ex_choice = input().strip()
                if ex_choice.isdigit() and 1 <= int(ex_choice) <= 11:
                    self.test_runner.run_single_test(int(ex_choice))
                elif ex_choice == '0':
                    continue
                else:
                    print("Invalid choice!")
            elif choice == '5':
                self.view_progress()
            elif choice == '6':
                confirm = input("Are you sure you want to reset all progress? (yes/no): ")
                if confirm.lower() == 'yes':
                    self.logging_system.reset_progress()
                    print("Progress reset successfully!")
            elif choice == '7':
                print("Thank you for using the Linear Algebra Learning System!")
                break
            else:
                print("Invalid choice! Please select 1-7.")

def main():
    """Entry point of the program"""
    # Ensure required directories exist
    os.makedirs('exercises', exist_ok=True)
    os.makedirs('tests', exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    
    # Run the learning system
    system = LinearAlgebraLearningSystem()
    system.run()

if __name__ == "__main__":
    main()