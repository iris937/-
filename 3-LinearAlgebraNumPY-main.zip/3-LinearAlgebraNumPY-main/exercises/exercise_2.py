# exercises/exercise_2.py
"""
Exercise 2: Vector Addition and Scalar Multiplication
Understanding vector operations and their geometric interpretations
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any
import sys
import os

# Add parent directory to path to import exercise_base
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from exercise_base import ExerciseBase

class Exercise2(ExerciseBase):
    def __init__(self, logging_system):
        super().__init__(logging_system, 2, "Vector Addition and Scalar Multiplication")
    
    def define_steps(self) -> list:
        return [
            "concept_explanation",
            "concept_check", 
            "parameters",
            "execution",
            "results"
        ]
    
    def get_concept_explanation(self) -> str:
        return """
➕ VECTOR ADDITION AND SCALAR MULTIPLICATION

KEY CONCEPTS:

1. VECTOR ADDITION:
   - Component-wise operation: [a₁, a₂] + [b₁, b₂] = [a₁+b₁, a₂+b₂]
   - Geometric interpretation: Head-to-tail method
   - Commutative: u + v = v + u
   - Associative: (u + v) + w = u + (v + w)

2. SCALAR MULTIPLICATION:
   - Scales each component: α·[a₁, a₂] = [α·a₁, α·a₂]
   - α > 1: stretches the vector
   - 0 < α < 1: compresses the vector
   - α < 0: flips direction and scales magnitude
   - α = 0: results in zero vector

3. GEOMETRIC PROPERTIES:
   - Vector addition: parallelogram rule
   - Scalar multiplication: changes magnitude, preserves/reverses direction
   - Zero vector: additive identity
   - Negative vector: additive inverse

4. APPLICATIONS IN TRANSFORMERS:
   - Residual connections: output = input + transformation(input)
   - Attention weights: weighted combination of value vectors
   - Position embeddings: added to word embeddings
   - Layer normalization: involves scalar operations

NUMPY OPERATIONS:
- u + v: element-wise addition
- alpha * u: scalar multiplication
- np.linalg.norm(): vector magnitude
        """
    
    def get_concept_question(self) -> str:
        return """
Explain the geometric meaning of vector addition and how scalar multiplication 
affects a vector's magnitude and direction. How do these operations relate to 
residual connections in Transformer architectures?
        """
    
    def get_required_parameters(self) -> Dict[str, str]:
        return {
            "vector_dimension": "Enter vector dimension (e.g., 2 for 2D visualization)",
            "num_random_vectors": "Enter number of random vector pairs to generate (e.g., 5)",
            "scalar_positive": "Enter a positive scalar value (e.g., 1.5)",
            "scalar_negative": "Enter a negative scalar value (e.g., -0.8)",
            "scalar_fractional": "Enter a fractional scalar (0 < value < 1, e.g., 0.3)"
        }
    
    def execute_exercise(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the vector addition and scalar multiplication exercise"""
        
        # Extract parameters
        dim = int(params["vector_dimension"])
        num_vectors = int(params["num_random_vectors"])
        alpha_pos = float(params["scalar_positive"])
        alpha_neg = float(params["scalar_negative"])
        alpha_frac = float(params["scalar_fractional"])
        
        # Generate random vectors
        np.random.seed(42)  # For reproducible results
        vectors_u = np.random.uniform(-5, 5, (num_vectors, dim))
        vectors_v = np.random.uniform(-5, 5, (num_vectors, dim))
        
        # Perform operations for each vector pair
        results_data = []
        for i in range(num_vectors):
            u = vectors_u[i]
            v = vectors_v[i]
            
            # Vector addition
            u_plus_v = u + v
            
            # Scalar multiplications
            alpha_pos_u = alpha_pos * u
            alpha_neg_u = alpha_neg * u
            alpha_frac_u = alpha_frac * u
            
            # Calculate magnitudes
            mag_u = np.linalg.norm(u)
            mag_v = np.linalg.norm(v)
            mag_sum = np.linalg.norm(u_plus_v)
            mag_pos = np.linalg.norm(alpha_pos_u)
            mag_neg = np.linalg.norm(alpha_neg_u)
            mag_frac = np.linalg.norm(alpha_frac_u)
            
            pair_result = {
                'pair_index': i + 1,
                'u': u,
                'v': v,
                'u_plus_v': u_plus_v,
                'alpha_pos_u': alpha_pos_u,
                'alpha_neg_u': alpha_neg_u,
                'alpha_frac_u': alpha_frac_u,
                'magnitudes': {
                    'mag_u': mag_u,
                    'mag_v': mag_v,
                    'mag_sum': mag_sum,
                    'mag_pos': mag_pos,
                    'mag_neg': mag_neg,
                    'mag_frac': mag_frac
                }
            }
            results_data.append(pair_result)
        
        # Display results table
        self.display_results_table(results_data, alpha_pos, alpha_neg, alpha_frac)
        
        # Create visualizations
        if dim == 2:
            self.create_2d_visualizations(results_data, alpha_pos, alpha_neg, alpha_frac)
        else:
            self.create_scatter_visualizations(results_data, alpha_pos, alpha_neg, alpha_frac)
        
        # Demonstrate properties
        self.demonstrate_vector_properties(vectors_u[0], vectors_v[0], alpha_pos, alpha_neg, alpha_frac)
        
        # Connection to Transformers
        self.explain_transformer_connection(vectors_u[0], vectors_v[0])
        
        results = {
            'vectors_u': vectors_u,
            'vectors_v': vectors_v,
            'dimension': dim,
            'num_vectors': num_vectors,
            'scalars': {'positive': alpha_pos, 'negative': alpha_neg, 'fractional': alpha_frac},
            'results_data': results_data
        }
        
        return results
    
    def display_results_table(self, results_data, alpha_pos, alpha_neg, alpha_frac):
        """Display results in a formatted table"""
        print(f"\n📊 VECTOR OPERATIONS RESULTS")
        print("=" * 80)
        
        # Header
        print(f"{'Pair':<4} {'||u||':<8} {'||v||':<8} {'||u+v||':<10} "
              f"{'||{α_pos:.1f}u||':<12} {'||{α_neg:.1f}u||':<12} {'||{α_frac:.1f}u||':<12}")
        print("-" * 80)
        
        # Data rows
        for data in results_data:
            mags = data['magnitudes']
            print(f"{data['pair_index']:<4} "
                  f"{mags['mag_u']:<8.2f} {mags['mag_v']:<8.2f} {mags['mag_sum']:<10.2f} "
                  f"{mags['mag_pos']:<12.2f} {mags['mag_neg']:<12.2f} {mags['mag_frac']:<12.2f}")
        
        # Summary statistics
        all_mag_u = [data['magnitudes']['mag_u'] for data in results_data]
        all_mag_pos = [data['magnitudes']['mag_pos'] for data in results_data]
        all_mag_neg = [data['magnitudes']['mag_neg'] for data in results_data]
        all_mag_frac = [data['magnitudes']['mag_frac'] for data in results_data]
        
        print("\n📈 MAGNITUDE SCALING ANALYSIS:")
        print(f"Average ||u||: {np.mean(all_mag_u):.2f}")
        print(f"Average ||{alpha_pos}u||: {np.mean(all_mag_pos):.2f} (scaling factor: {np.mean(all_mag_pos)/np.mean(all_mag_u):.2f})")
        print(f"Average ||{alpha_neg}u||: {np.mean(all_mag_neg):.2f} (scaling factor: {np.mean(all_mag_neg)/np.mean(all_mag_u):.2f})")
        print(f"Average ||{alpha_frac}u||: {np.mean(all_mag_frac):.2f} (scaling factor: {np.mean(all_mag_frac)/np.mean(all_mag_u):.2f})")
    
    def create_2d_visualizations(self, results_data, alpha_pos, alpha_neg, alpha_frac):
        """Create 2D vector visualizations for 2D vectors"""
        fig, axes = plt.subplots(2, 2, figsize=(15, 12))
        fig.suptitle('Vector Addition and Scalar Multiplication (2D)', fontsize=16)
        
        # Use first vector pair for detailed visualization
        data = results_data[0]
        u = data['u']
        v = data['v']
        u_plus_v = data['u_plus_v']
        
        # Plot 1: Vector Addition
        ax1 = axes[0, 0]
        self.plot_2d_vectors(ax1, [u, v, u_plus_v], 
                           ['u', 'v', 'u+v'], 
                           ['blue', 'red', 'green'],
                           "Vector Addition: u + v")
        
        # Show parallelogram construction
        ax1.arrow(0, 0, u[0], u[1], head_width=0.2, head_length=0.2, fc='blue', alpha=0.7)
        ax1.arrow(u[0], u[1], v[0], v[1], head_width=0.2, head_length=0.2, fc='red', alpha=0.7)
        ax1.arrow(0, 0, v[0], v[1], head_width=0.1, head_length=0.1, fc='gray', alpha=0.3, linestyle='--')
        ax1.arrow(v[0], v[1], u[0], u[1], head_width=0.1, head_length=0.1, fc='gray', alpha=0.3, linestyle='--')
        
        # Plot 2: Positive Scalar Multiplication
        ax2 = axes[0, 1]
        alpha_pos_u = data['alpha_pos_u']
        self.plot_2d_vectors(ax2, [u, alpha_pos_u], 
                           ['u', f'{alpha_pos}u'], 
                           ['blue', 'orange'],
                           f"Positive Scalar: {alpha_pos}u")
        
        # Plot 3: Negative Scalar Multiplication
        ax3 = axes[1, 0]
        alpha_neg_u = data['alpha_neg_u']
        self.plot_2d_vectors(ax3, [u, alpha_neg_u], 
                           ['u', f'{alpha_neg}u'], 
                           ['blue', 'purple'],
                           f"Negative Scalar: {alpha_neg}u")
        
        # Plot 4: Fractional Scalar Multiplication
        ax4 = axes[1, 1]
        alpha_frac_u = data['alpha_frac_u']
        self.plot_2d_vectors(ax4, [u, alpha_frac_u], 
                           ['u', f'{alpha_frac}u'], 
                           ['blue', 'brown'],
                           f"Fractional Scalar: {alpha_frac}u")
        
        plt.tight_layout()
        plt.show()
        
        # Create scatter plot of all vector operations
        self.create_scatter_plot_2d(results_data, alpha_pos, alpha_neg, alpha_frac)
    
    def plot_2d_vectors(self, ax, vectors, labels, colors, title):
        """Plot 2D vectors on given axes"""
        ax.set_aspect('equal')
        ax.grid(True, alpha=0.3)
        ax.axhline(y=0, color='k', linewidth=0.5)
        ax.axvline(x=0, color='k', linewidth=0.5)
        
        for vector, label, color in zip(vectors, labels, colors):
            ax.arrow(0, 0, vector[0], vector[1], 
                    head_width=0.3, head_length=0.3, 
                    fc=color, ec=color, alpha=0.8, linewidth=2)
            # Add label at vector tip
            ax.text(vector[0]*1.1, vector[1]*1.1, label, 
                   fontsize=10, ha='center', va='center', 
                   bbox=dict(boxstyle="round,pad=0.3", facecolor=color, alpha=0.3))
        
        ax.set_title(title)
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        
        # Set equal axis limits
        max_val = max([max(abs(v)) for v in np.concatenate(vectors)])
        ax.set_xlim(-max_val*1.2, max_val*1.2)
        ax.set_ylim(-max_val*1.2, max_val*1.2)
    
    def create_scatter_plot_2d(self, results_data, alpha_pos, alpha_neg, alpha_frac):
        """Create scatter plot showing all vector operations"""
        fig, ax = plt.subplots(1, 1, figsize=(12, 8))
        
        for i, data in enumerate(results_data):
            u = data['u']
            v = data['v']
            u_plus_v = data['u_plus_v']
            alpha_pos_u = data['alpha_pos_u']
            alpha_neg_u = data['alpha_neg_u']
            alpha_frac_u = data['alpha_frac_u']
            
            # Plot original vectors
            ax.scatter(u[0], u[1], c='blue', s=100, alpha=0.7, marker='o', label='u vectors' if i==0 else "")
            ax.scatter(v[0], v[1], c='red', s=100, alpha=0.7, marker='s', label='v vectors' if i==0 else "")
            
            # Plot results
            ax.scatter(u_plus_v[0], u_plus_v[1], c='green', s=150, alpha=0.7, marker='^', label='u+v' if i==0 else "")
            ax.scatter(alpha_pos_u[0], alpha_pos_u[1], c='orange', s=80, alpha=0.7, marker='d', label=f'{alpha_pos}u' if i==0 else "")
            ax.scatter(alpha_neg_u[0], alpha_neg_u[1], c='purple', s=80, alpha=0.7, marker='v', label=f'{alpha_neg}u' if i==0 else "")
            ax.scatter(alpha_frac_u[0], alpha_frac_u[1], c='brown', s=80, alpha=0.7, marker='*', label=f'{alpha_frac}u' if i==0 else "")
        
        ax.set_aspect('equal')
        ax.grid(True, alpha=0.3)
        ax.axhline(y=0, color='k', linewidth=0.5)
        ax.axvline(x=0, color='k', linewidth=0.5)
        ax.legend()
        ax.set_title('All Vector Operations - Scatter Plot')
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        
        plt.tight_layout()
        plt.show()
    
    def create_scatter_visualizations(self, results_data, alpha_pos, alpha_neg, alpha_frac):
        """Create scatter visualizations for higher-dimensional vectors"""
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        fig.suptitle('Vector Operations Results (Higher Dimensions)', fontsize=16)
        
        # Extract data for plotting
        magnitudes_u = [data['magnitudes']['mag_u'] for data in results_data]
        magnitudes_v = [data['magnitudes']['mag_v'] for data in results_data]
        magnitudes_sum = [data['magnitudes']['mag_sum'] for data in results_data]
        magnitudes_pos = [data['magnitudes']['mag_pos'] for data in results_data]
        magnitudes_neg = [data['magnitudes']['mag_neg'] for data in results_data]
        magnitudes_frac = [data['magnitudes']['mag_frac'] for data in results_data]
        
        # Plot 1: Magnitude comparison
        indices = range(1, len(results_data) + 1)
        axes[0, 0].bar([i-0.3 for i in indices], magnitudes_u, width=0.3, label='||u||', alpha=0.7)
        axes[0, 0].bar([i for i in indices], magnitudes_v, width=0.3, label='||v||', alpha=0.7)
        axes[0, 0].bar([i+0.3 for i in indices], magnitudes_sum, width=0.3, label='||u+v||', alpha=0.7)
        axes[0, 0].set_title('Vector Magnitudes')
        axes[0, 0].set_xlabel('Vector Pair')
        axes[0, 0].set_ylabel('Magnitude')
        axes[0, 0].legend()
        axes[0, 0].grid(True, alpha=0.3)
        
        # Plot 2: Scalar multiplication effects
        axes[0, 1].scatter(magnitudes_u, magnitudes_pos, label=f'{alpha_pos}u', alpha=0.7)
        axes[0, 1].scatter(magnitudes_u, magnitudes_neg, label=f'{alpha_neg}u', alpha=0.7)
        axes[0, 1].scatter(magnitudes_u, magnitudes_frac, label=f'{alpha_frac}u', alpha=0.7)
        axes[0, 1].plot([0, max(magnitudes_u)], [0, alpha_pos*max(magnitudes_u)], '--', alpha=0.5, label=f'y={alpha_pos}x')
        axes[0, 1].plot([0, max(magnitudes_u)], [0, abs(alpha_neg)*max(magnitudes_u)], '--', alpha=0.5, label=f'y={abs(alpha_neg)}x')
        axes[0, 1].plot([0, max(magnitudes_u)], [0, alpha_frac*max(magnitudes_u)], '--', alpha=0.5, label=f'y={alpha_frac}x')
        axes[0, 1].set_title('Scalar Multiplication: ||αu|| vs ||u||')
        axes[0, 1].set_xlabel('||u||')
        axes[0, 1].set_ylabel('||αu||')
        axes[0, 1].legend()
        axes[0, 1].grid(True, alpha=0.3)
        
        # Plot 3: Triangle inequality illustration
        triangle_diff = [abs(mag_sum - (mag_u + mag_v)) for mag_sum, mag_u, mag_v in 
                        zip(magnitudes_sum, magnitudes_u, magnitudes_v)]
        axes[1, 0].bar(indices, triangle_diff, alpha=0.7, color='red')
        axes[1, 0].set_title('Triangle Inequality: ||u+v|| ≤ ||u|| + ||v||')
        axes[1, 0].set_xlabel('Vector Pair')
        axes[1, 0].set_ylabel('||u|| + ||v|| - ||u+v||')
        axes[1, 0].grid(True, alpha=0.3)
        
        # Plot 4: Scaling factors
        scaling_factors = [mag_pos/mag_u for mag_pos, mag_u in zip(magnitudes_pos, magnitudes_u)]
        axes[1, 1].hist(scaling_factors, bins=10, alpha=0.7, edgecolor='black')
        axes[1, 1].axvline(alpha_pos, color='red', linestyle='--', label=f'Expected: {alpha_pos}')
        axes[1, 1].set_title(f'Scaling Factor Distribution for {alpha_pos}u')
        axes[1, 1].set_xlabel('||αu|| / ||u||')
        axes[1, 1].set_ylabel('Frequency')
        axes[1, 1].legend()
        axes[1, 1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.show()
    
    def demonstrate_vector_properties(self, u, v, alpha_pos, alpha_neg, alpha_frac):
        """Demonstrate key vector properties"""
        print(f"\n🔍 VECTOR PROPERTIES DEMONSTRATION")
        print("=" * 50)
        
        # Commutativity of addition
        u_plus_v = u + v
        v_plus_u = v + u
        print(f"1. COMMUTATIVITY: u + v = v + u")
        print(f"   u + v = {u_plus_v}")
        print(f"   v + u = {v_plus_u}")
        print(f"   Equal? {np.allclose(u_plus_v, v_plus_u)}")
        
        # Scalar multiplication properties
        print(f"\n2. SCALAR MULTIPLICATION PROPERTIES:")
        print(f"   α₁ = {alpha_pos}, α₂ = {alpha_neg}, α₃ = {alpha_frac}")
        print(f"   ||u|| = {np.linalg.norm(u):.3f}")
        print(f"   ||α₁u|| = {np.linalg.norm(alpha_pos * u):.3f} (factor: {alpha_pos})")
        print(f"   ||α₂u|| = {np.linalg.norm(alpha_neg * u):.3f} (factor: {abs(alpha_neg)})")
        print(f"   ||α₃u|| = {np.linalg.norm(alpha_frac * u):.3f} (factor: {alpha_frac})")
        
        # Zero vector property
        zero_vector = np.zeros_like(u)
        print(f"\n3. ZERO VECTOR PROPERTIES:")
        print(f"   u + 0 = {u + zero_vector}")
        print(f"   Equal to u? {np.allclose(u, u + zero_vector)}")
        print(f"   0 · u = {0 * u}")
        print(f"   Is zero vector? {np.allclose(0 * u, zero_vector)}")
        
        # Distributive property
        combined_scalar = alpha_pos + alpha_frac
        print(f"\n4. DISTRIBUTIVE PROPERTY:")
        print(f"   (α₁ + α₃)u = {combined_scalar}u = {combined_scalar * u}")
        print(f"   α₁u + α₃u = {alpha_pos * u + alpha_frac * u}")
        print(f"   Equal? {np.allclose(combined_scalar * u, alpha_pos * u + alpha_frac * u)}")
    
    def explain_transformer_connection(self, u, v):
        """Explain connection to Transformer architectures"""
        print(f"\n🤖 CONNECTION TO TRANSFORMER ARCHITECTURE")
        print("=" * 60)
        
        print(f"📝 RESIDUAL CONNECTIONS:")
        print(f"   - In Transformers: output = input + attention(input)")
        print(f"   - Your example: u + v represents this pattern")
        print(f"   - Helps with gradient flow and training stability")
        
        print(f"\n🎯 ATTENTION MECHANISM:")
        print(f"   - Attention weights are scalars multiplying value vectors")
        print(f"   - Your scalar multiplications (α·u) model this")
        print(f"   - Final output is weighted sum of value vectors")
        
        print(f"\n🔧 LAYER NORMALIZATION:")
        print(f"   - Involves scaling vectors by computed statistics")
        print(f"   - Similar to your scalar multiplication operations")
        
        print(f"\n📊 POSITION EMBEDDINGS:")
        print(f"   - Added to word embeddings: word_emb + pos_emb")
        print(f"   - Direct application of vector addition")
        
        # Demonstrate with actual values
        attention_weight = 0.7
        weighted_value = attention_weight * v
        residual_output = u + weighted_value
        
        print(f"\n💡 EXAMPLE SIMULATION:")
        print(f"   Input representation: {u}")
        print(f"   Attention weight: {attention_weight}")
        print(f"   Weighted value: {attention_weight} × {v} = {weighted_value}")
        print(f"   Residual output: {u} + {weighted_value} = {residual_output}")
    
    def get_result_explanation_question(self, results: Dict[str, Any]) -> str:
        scalars = results["scalars"]
        num_vectors = results["num_vectors"]
        
        return f"""
Analyzing the results from {num_vectors} vector pairs:

1. How does vector addition geometrically combine two vectors?

2. Compare the effects of the three scalar multiplications:
   - Positive scalar ({scalars['positive']}): How did it affect magnitude and direction?
   - Negative scalar ({scalars['negative']}): What happened to the vectors?
   - Fractional scalar ({scalars['fractional']}): How did this change the vectors?

3. Triangle Inequality: Did you observe ||u+v|| ≤ ||u|| + ||v|| in all cases? 
   When might ||u+v|| = ||u|| + ||v||?

4. How do these operations relate to:
   - Residual connections in Transformers?
   - Attention weight applications?
   - Position embedding additions?

5. What would happen if you used very large or very small scalar values?
        """

# Test function for the exercise
def test_exercise_2():
    """Test function for Exercise 2"""
    print("Testing Exercise 2: Vector Addition and Scalar Multiplication")
    
    # Mock logging system for testing
    class MockLoggingSystem:
        def set_current_exercise(self, ex_num, step): pass
        def complete_step(self, ex_num, step): pass
        def complete_exercise(self, ex_num): pass
        def log_student_response(self, ex_num, step, question, response): 
            print(f"Logged: {response}")
    
    mock_logger = MockLoggingSystem()
    exercise = Exercise2(mock_logger)
    
    # Test parameters
    test_params = {
        "vector_dimension": 2,
        "num_random_vectors": 3,
        "scalar_positive": 1.5,
        "scalar_negative": -0.8,
        "scalar_fractional": 0.3
    }
    
    try:
        results = exercise.execute_exercise(test_params)
        print("✓ Exercise 2 test completed successfully!")
        return True
    except Exception as e:
        print(f"❌ Exercise 2 test failed: {e}")
        return False

if __name__ == "__main__":
    test_exercise_2()