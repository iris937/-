# exercises/exercise_6.py
"""
Exercise 6: Transpose, Symmetry, Orthogonal Matrices
Understanding matrix transpose, symmetric matrices, and orthogonality
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any
import sys
import os

# Add parent directory to path to import exercise_base
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from exercise_base import ExerciseBase

class Exercise6(ExerciseBase):
    def __init__(self, logging_system):
        super().__init__(logging_system, 6, "Transpose, Symmetry, Orthogonal Matrices")
    
    def define_steps(self) -> list:
        return [
            "concept_explanation",
            "concept_check", 
            "parameters",
            "execution",
            "results"
        ]
    
    def get_concept_explanation(self) -> str:
        return """
🔄 TRANSPOSE, SYMMETRY, ORTHOGONAL MATRICES

KEY CONCEPTS:

1. MATRIX TRANSPOSE:
   - (A^T)ij = Aji (swap rows and columns)
   - Properties: (A^T)^T = A, (AB)^T = B^T A^T
   - Vector inner product: ⟨u,v⟩ = u^T v
   - Geometric meaning: reflection across main diagonal

2. SYMMETRIC MATRICES:
   - Definition: A = A^T (equal to its transpose)
   - Properties: real eigenvalues, orthogonal eigenvectors
   - Common in optimization, covariance matrices
   - Positive definite: all eigenvalues > 0

3. ORTHOGONAL MATRICES:
   - Definition: Q^T Q = I (columns are orthonormal)
   - Properties: det(Q) = ±1, preserves lengths and angles
   - Inverse: Q^(-1) = Q^T (very efficient!)
   - Represents rotations and reflections

4. GRAM-SCHMIDT PROCESS:
   - Converts linearly independent vectors to orthonormal set
   - Fundamental in QR decomposition
   - Used in constructing orthogonal bases

5. APPLICATIONS IN DEEP LEARNING:
   - Weight initialization: orthogonal matrices prevent vanishing gradients
   - Layer normalization: involves transpose operations
   - Attention mechanisms: Q^T K computations
   - Batch normalization: covariance matrix calculations
   - Regularization: orthogonal constraints on weights

6. COMPUTATIONAL BENEFITS:
   - Orthogonal matrices: numerically stable
   - Symmetric matrices: only store upper/lower triangle
   - Fast matrix inversion for orthogonal matrices

NUMPY OPERATIONS:
- A.T or np.transpose(A): transpose
- np.allclose(A, A.T): check symmetry
- np.allclose(Q.T @ Q, np.eye(n)): check orthogonality
        """
    
    def get_concept_question(self) -> str:
        return """
Explain the difference between symmetric and orthogonal matrices. Why are orthogonal 
matrices particularly useful in numerical computations, and how does the Gram-Schmidt 
process help create orthonormal bases?
        """
    
    def get_required_parameters(self) -> Dict[str, str]:
        return {
            "matrix_size": "Enter size for square matrices (e.g., 4)",
            "num_vectors": "Enter number of vectors for Gram-Schmidt (e.g., 3)",
            "random_seed": "Enter random seed (e.g., 42)",
            "demo_type": "Enter 'rotation' for 2D rotation demo or 'general' for general analysis"
        }
    
    def execute_exercise(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the transpose, symmetry, orthogonal matrices exercise"""
        
        # Extract parameters
        n = int(params["matrix_size"])
        num_vecs = min(int(params["num_vectors"]), n)  # Can't have more vectors than dimensions
        seed = int(params["random_seed"])
        demo_type = params["demo_type"].lower().strip()
        
        np.random.seed(seed)
        
        # Create test matrices
        A = np.random.uniform(-3, 3, (n, n))
        
        # Create symmetric matrix
        S = A + A.T  # Always symmetric
        
        # Create vectors for Gram-Schmidt
        random_vectors = np.random.uniform(-2, 2, (n, num_vecs))
        
        # Analyze transpose properties
        transpose_results = self.analyze_transpose(A)
        
        # Analyze symmetric matrix
        symmetric_results = self.analyze_symmetric_matrix(S)
        
        # Perform Gram-Schmidt orthogonalization
        orthogonal_results = self.gram_schmidt_process(random_vectors)
        
        # Create orthogonal matrix and analyze
        Q = orthogonal_results['orthogonal_matrix']
        orthogonal_analysis = self.analyze_orthogonal_matrix(Q)
        
        # Demonstrate properties
        properties_demo = self.demonstrate_matrix_properties(A, S, Q)
        
        # Visualization
        if demo_type == 'rotation' and n >= 2:
            visualization_results = self.visualize_rotation_transformation(Q[:2, :2])
        else:
            visualization_results = self.create_general_visualizations(A, S, Q, orthogonal_results)
        
        # Connection to neural networks
        self.explain_neural_network_applications(Q, S)
        
        results = {
            'original_matrix': A,
            'symmetric_matrix': S,
            'random_vectors': random_vectors,
            'transpose_results': transpose_results,
            'symmetric_results': symmetric_results,
            'orthogonal_results': orthogonal_results,
            'orthogonal_analysis': orthogonal_analysis,
            'properties_demo': properties_demo,
            'visualization_results': visualization_results,
            'matrix_size': n,
            'demo_type': demo_type
        }
        
        return results
    
    def analyze_transpose(self, A):
        """Analyze transpose properties"""
        print(f"\n📐 TRANSPOSE ANALYSIS")
        print("=" * 40)
        
        A_T = A.T
        A_T_T = A_T.T
        
        print(f"Original matrix A:")
        if A.shape[0] <= 4:
            print(A)
        else:
            print(f"Shape: {A.shape}, sample: A[0,0]={A[0,0]:.3f}")
        
        print(f"\nTranspose A^T:")
        if A_T.shape[0] <= 4:
            print(A_T)
        else:
            print(f"Shape: {A_T.shape}, sample: A^T[0,0]={A_T[0,0]:.3f}")
        
        # Verify (A^T)^T = A
        transpose_identity = np.allclose(A, A_T_T)
        print(f"\nTranspose properties:")
        print(f"   (A^T)^T = A? {transpose_identity}")
        
        # Check if matrix is symmetric
        is_symmetric = np.allclose(A, A_T)
        print(f"   A = A^T (symmetric)? {is_symmetric}")
        
        if not is_symmetric:
            # Symmetric and skew-symmetric parts
            symmetric_part = 0.5 * (A + A_T)
            skew_symmetric_part = 0.5 * (A - A_T)
            
            print(f"   Symmetric part: (A + A^T)/2")
            print(f"   Skew-symmetric part: (A - A^T)/2")
            
            # Verify decomposition
            reconstruction = symmetric_part + skew_symmetric_part
            decomp_correct = np.allclose(A, reconstruction)
            print(f"   Decomposition correct? {decomp_correct}")
        
        return {
            'A': A,
            'A_T': A_T,
            'transpose_identity': transpose_identity,
            'is_symmetric': is_symmetric,
            'symmetric_part': 0.5 * (A + A_T) if not is_symmetric else A,
            'skew_symmetric_part': 0.5 * (A - A_T) if not is_symmetric else np.zeros_like(A)
        }
    
    def analyze_symmetric_matrix(self, S):
        """Analyze symmetric matrix properties"""
        print(f"\n⚖️ SYMMETRIC MATRIX ANALYSIS")
        print("=" * 50)
        
        print(f"Symmetric matrix S:")
        if S.shape[0] <= 4:
            print(S)
        else:
            print(f"Shape: {S.shape}")
            print(f"Sample elements: S[0,0]={S[0,0]:.3f}, S[0,1]={S[0,1]:.3f}, S[1,0]={S[1,0]:.3f}")
        
        # Verify symmetry
        is_symmetric = np.allclose(S, S.T)
        print(f"\nSymmetry verification:")
        print(f"   S = S^T? {is_symmetric}")
        
        # Compute eigenvalues and eigenvectors
        eigenvalues, eigenvectors = np.linalg.eigh(S)  # For symmetric matrices
        
        print(f"\nEigenvalue analysis:")
        print(f"   Eigenvalues: {eigenvalues}")
        print(f"   All real? {np.all(np.isreal(eigenvalues))}")
        
        # Check if positive definite, positive semi-definite, etc.
        min_eigenval = np.min(eigenvalues)
        max_eigenval = np.max(eigenvalues)
        
        if min_eigenval > 1e-10:
            definiteness = "Positive definite"
        elif min_eigenval >= -1e-10:
            definiteness = "Positive semi-definite"
        elif max_eigenval < -1e-10:
            definiteness = "Negative definite"
        elif max_eigenval <= 1e-10:
            definiteness = "Negative semi-definite"
        else:
            definiteness = "Indefinite"
        
        print(f"   Definiteness: {definiteness}")
        print(f"   Condition number: {max_eigenval / min_eigenval if abs(min_eigenval) > 1e-10 else 'inf'}")
        
        # Verify eigenvector orthogonality
        V = eigenvectors
        orthogonality_check = np.allclose(V.T @ V, np.eye(S.shape[0]))
        print(f"   Eigenvectors orthogonal? {orthogonality_check}")
        
        # Spectral decomposition: S = V Λ V^T
        Lambda = np.diag(eigenvalues)
        S_reconstructed = V @ Lambda @ V.T
        spectral_correct = np.allclose(S, S_reconstructed)
        print(f"   Spectral decomposition S = VΛV^T correct? {spectral_correct}")
        
        return {
            'S': S,
            'is_symmetric': is_symmetric,
            'eigenvalues': eigenvalues,
            'eigenvectors': eigenvectors,
            'definiteness': definiteness,
            'min_eigenval': min_eigenval,
            'max_eigenval': max_eigenval,
            'orthogonality_check': orthogonality_check,
            'spectral_correct': spectral_correct
        }
    
    def gram_schmidt_process(self, vectors):
        """Perform Gram-Schmidt orthogonalization"""
        print(f"\n🔧 GRAM-SCHMIDT ORTHOGONALIZATION")
        print("=" * 50)
        
        n, num_vecs = vectors.shape
        
        print(f"Input vectors ({num_vecs} vectors in R^{n}):")
        for i in range(num_vecs):
            print(f"   v{i+1} = {vectors[:, i]}")
        
        # Gram-Schmidt process
        orthogonal_vectors = np.zeros_like(vectors)
        
        for i in range(num_vecs):
            # Start with the original vector
            v = vectors[:, i].copy()
            
            # Subtract projections onto all previous orthogonal vectors
            for j in range(i):
                proj_coeff = np.dot(v, orthogonal_vectors[:, j]) / np.dot(orthogonal_vectors[:, j], orthogonal_vectors[:, j])
                v = v - proj_coeff * orthogonal_vectors[:, j]
            
            # Normalize
            norm_v = np.linalg.norm(v)
            if norm_v > 1e-10:  # Avoid division by zero
                orthogonal_vectors[:, i] = v / norm_v
            else:
                print(f"   ⚠️  Vector {i+1} is linearly dependent, skipping...")
                orthogonal_vectors[:, i] = 0
        
        # Remove zero columns (linearly dependent vectors)
        non_zero_cols = [i for i in range(num_vecs) if np.linalg.norm(orthogonal_vectors[:, i]) > 1e-10]
        Q = orthogonal_vectors[:, non_zero_cols]
        
        print(f"\nOrthonormal vectors:")
        for i, col_idx in enumerate(non_zero_cols):
            print(f"   q{i+1} = {Q[:, i]}")
            print(f"   ||q{i+1}|| = {np.linalg.norm(Q[:, i]):.6f}")
        
        # Verify orthogonality
        if Q.shape[1] > 1:
            print(f"\nOrthogonality verification:")
            for i in range(Q.shape[1]):
                for j in range(i+1, Q.shape[1]):
                    dot_product = np.dot(Q[:, i], Q[:, j])
                    print(f"   ⟨q{i+1}, q{j+1}⟩ = {dot_product:.2e}")
        
        # Create square orthogonal matrix if possible
        if Q.shape[1] < n:
            # Extend to full orthogonal matrix using random vectors
            additional_needed = n - Q.shape[1]
            print(f"\n🔄 Extending to full {n}×{n} orthogonal matrix...")
            
            # Generate random vectors and orthogonalize against existing ones
            for _ in range(additional_needed):
                random_vec = np.random.randn(n)
                
                # Orthogonalize against all existing vectors
                for j in range(Q.shape[1]):
                    proj_coeff = np.dot(random_vec, Q[:, j])
                    random_vec = random_vec - proj_coeff * Q[:, j]
                
                # Normalize
                norm_vec = np.linalg.norm(random_vec)
                if norm_vec > 1e-10:
                    random_vec = random_vec / norm_vec
                    Q = np.column_stack([Q, random_vec])
        
        return {
            'input_vectors': vectors,
            'orthogonal_matrix': Q,
            'num_original_vectors': len(non_zero_cols),
            'is_complete_basis': Q.shape[1] == n
        }
    
    def analyze_orthogonal_matrix(self, Q):
        """Analyze properties of orthogonal matrix"""
        print(f"\n🎯 ORTHOGONAL MATRIX ANALYSIS")
        print("=" * 50)
        
        print(f"Orthogonal matrix Q:")
        if Q.shape[0] <= 4:
            print(Q)
        else:
            print(f"Shape: {Q.shape}")
        
        # Check orthogonality: Q^T Q = I
        QTQ = Q.T @ Q
        is_orthogonal = np.allclose(QTQ, np.eye(Q.shape[1]))
        
        print(f"\nOrthogonality check Q^T Q = I:")
        print(f"   Result: {is_orthogonal}")
        if Q.shape[0] <= 4:
            print(f"   Q^T Q =")
            print(QTQ)
        
        # Check if it's also orthonormal (columns have unit length)
        column_norms = [np.linalg.norm(Q[:, i]) for i in range(Q.shape[1])]
        is_orthonormal = all(abs(norm - 1.0) < 1e-10 for norm in column_norms)
        
        print(f"\n   Column norms: {[f'{norm:.6f}' for norm in column_norms]}")
        print(f"   All unit length? {is_orthonormal}")
        
        # Determinant (should be ±1 for square orthogonal matrices)
        if Q.shape[0] == Q.shape[1]:
            det_Q = np.linalg.det(Q)
            print(f"   Determinant: {det_Q:.6f}")
            print(f"   |det(Q)| = 1? {abs(abs(det_Q) - 1.0) < 1e-10}")
            
            if det_Q > 0:
                matrix_type = "Proper rotation"
            else:
                matrix_type = "Improper rotation (includes reflection)"
            print(f"   Type: {matrix_type}")
        
        # Verify that Q^T = Q^(-1) for square matrices
        if Q.shape[0] == Q.shape[1]:
            try:
                Q_inv = np.linalg.inv(Q)
                inverse_equals_transpose = np.allclose(Q.T, Q_inv)
                print(f"   Q^T = Q^(-1)? {inverse_equals_transpose}")
            except:
                print(f"   Matrix not invertible")
        
        return {
            'Q': Q,
            'QTQ': QTQ,
            'is_orthogonal': is_orthogonal,
            'is_orthonormal': is_orthonormal,
            'column_norms': column_norms,
            'determinant': np.linalg.det(Q) if Q.shape[0] == Q.shape[1] else None
        }
    
    def demonstrate_matrix_properties(self, A, S, Q):
        """Demonstrate key properties of different matrix types"""
        print(f"\n🧪 MATRIX PROPERTIES DEMONSTRATION")
        print("=" * 60)
        
        results = {}
        
        # Transpose properties
        print(f"1. TRANSPOSE PROPERTIES:")
        
        # (AB)^T = B^T A^T
        if A.shape[1] == S.shape[0]:  # Can multiply A and S
            AS = A @ S
            AS_T = AS.T
            ST_AT = S.T @ A.T
            transpose_product = np.allclose(AS_T, ST_AT)
            print(f"   (AS)^T = S^T A^T: {transpose_product}")
            results['transpose_product'] = transpose_product
        
        # 2. Symmetric matrix properties
        print(f"\n2. SYMMETRIC MATRIX PROPERTIES:")
        
        # S^2 is symmetric if S is symmetric
        S2 = S @ S
        S2_symmetric = np.allclose(S2, S2.T)
        print(f"   S^2 symmetric when S symmetric: {S2_symmetric}")
        results['S2_symmetric'] = S2_symmetric
        
        # 3. Orthogonal matrix properties
        print(f"\n3. ORTHOGONAL MATRIX PROPERTIES:")
        
        # Length preservation
        test_vector = np.random.randn(Q.shape[1])
        Qx = Q @ test_vector
        original_length = np.linalg.norm(test_vector)
        transformed_length = np.linalg.norm(Qx)
        length_preserved = np.isclose(original_length, transformed_length)
        print(f"   Length preservation ||Qx|| = ||x||: {length_preserved}")
        print(f"     ||x|| = {original_length:.6f}, ||Qx|| = {transformed_length:.6f}")
        results['length_preserved'] = length_preserved
        
        # Angle preservation (if we have room for two vectors)
        if Q.shape[1] >= 2:
            test_vector2 = np.random.randn(Q.shape[1])
            Qy = Q @ test_vector2
            
            # Original angle
            cos_original = np.dot(test_vector, test_vector2) / (np.linalg.norm(test_vector) * np.linalg.norm(test_vector2))
            
            # Transformed angle
            cos_transformed = np.dot(Qx, Qy) / (np.linalg.norm(Qx) * np.linalg.norm(Qy))
            
            angle_preserved = np.isclose(cos_original, cos_transformed)
            print(f"   Angle preservation: {angle_preserved}")
            print(f"     cos(θ_original) = {cos_original:.6f}, cos(θ_transformed) = {cos_transformed:.6f}")
            results['angle_preserved'] = angle_preserved
        
        return results
    
    def visualize_rotation_transformation(self, Q2D):
        """Visualize 2D rotation transformation"""
        print(f"\n🎨 2D ROTATION VISUALIZATION")
        print("=" * 40)
        
        # Create unit circle
        theta = np.linspace(0, 2*np.pi, 100)
        unit_circle = np.array([np.cos(theta), np.sin(theta)])
        
        # Transform unit circle
        transformed_circle = Q2D @ unit_circle
        
        # Create grid of points
        x = np.linspace(-2, 2, 10)
        y = np.linspace(-2, 2, 10)
        X, Y = np.meshgrid(x, y)
        grid_points = np.array([X.ravel(), Y.ravel()])
        transformed_grid = Q2D @ grid_points
        
        # Create visualization
        fig, axes = plt.subplots(1, 2, figsize=(12, 6))
        
        # Original space
        axes[0].plot(unit_circle[0], unit_circle[1], 'b-', linewidth=2, label='Unit circle')
        axes[0].scatter(grid_points[0], grid_points[1], alpha=0.6, s=30, c='blue', label='Grid points')
        
        # Draw coordinate axes
        axes[0].arrow(0, 0, 1, 0, head_width=0.1, head_length=0.1, fc='red', ec='red')
        axes[0].arrow(0, 0, 0, 1, head_width=0.1, head_length=0.1, fc='green', ec='green')
        axes[0].text(1.1, 0, 'e₁', fontsize=12, color='red')
        axes[0].text(0, 1.1, 'e₂', fontsize=12, color='green')
        
        axes[0].set_xlim(-2.5, 2.5)
        axes[0].set_ylim(-2.5, 2.5)
        axes[0].set_aspect('equal')
        axes[0].grid(True, alpha=0.3)
        axes[0].set_title('Original Space')
        axes[0].legend()
        
        # Transformed space
        axes[1].plot(transformed_circle[0], transformed_circle[1], 'r-', linewidth=2, label='Transformed circle')
        axes[1].scatter(transformed_grid[0], transformed_grid[1], alpha=0.6, s=30, c='red', label='Transformed grid')
        
        # Draw transformed coordinate axes
        e1_transformed = Q2D @ np.array([1, 0])
        e2_transformed = Q2D @ np.array([0, 1])
        
        axes[1].arrow(0, 0, e1_transformed[0], e1_transformed[1], 
                     head_width=0.1, head_length=0.1, fc='red', ec='red')
        axes[1].arrow(0, 0, e2_transformed[0], e2_transformed[1], 
                     head_width=0.1, head_length=0.1, fc='green', ec='green')
        axes[1].text(e1_transformed[0]*1.1, e1_transformed[1]*1.1, 'Qe₁', fontsize=12, color='red')
        axes[1].text(e2_transformed[0]*1.1, e2_transformed[1]*1.1, 'Qe₂', fontsize=12, color='green')
        
        axes[1].set_xlim(-2.5, 2.5)
        axes[1].set_ylim(-2.5, 2.5)
        axes[1].set_aspect('equal')
        axes[1].grid(True, alpha=0.3)
        axes[1].set_title('Transformed Space (Q × points)')
        axes[1].legend()
        
        plt.tight_layout()
        plt.show()
        
        # Analyze the transformation
        det_Q = np.linalg.det(Q2D)
        trace_Q = np.trace(Q2D)
        
        # Estimate rotation angle
        rotation_angle = np.arccos(np.clip(trace_Q / 2, -1, 1))
        rotation_degrees = np.degrees(rotation_angle)
        
        print(f"2D Transformation Analysis:")
        print(f"   Matrix Q:")
        print(f"   {Q2D}")
        print(f"   Determinant: {det_Q:.6f}")
        print(f"   Trace: {trace_Q:.6f}")
        print(f"   Rotation angle: {rotation_degrees:.2f}°")
        
        if abs(det_Q - 1) < 1e-10:
            print(f"   Type: Pure rotation")
        elif abs(det_Q + 1) < 1e-10:
            print(f"   Type: Rotation + reflection")
        else:
            print(f"   Type: Not orthogonal (det ≠ ±1)")
        
        return {
            'unit_circle': unit_circle,
            'transformed_circle': transformed_circle,
            'rotation_angle_degrees': rotation_degrees,
            'determinant': det_Q
        }
    
    def create_general_visualizations(self, A, S, Q, orthogonal_results):
        """Create general visualizations for matrices"""
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        
        # Matrix heatmaps
        im1 = axes[0, 0].imshow(A, cmap='RdBu_r', aspect='auto')
        axes[0, 0].set_title('Original Matrix A')
        plt.colorbar(im1, ax=axes[0, 0])
        
        im2 = axes[0, 1].imshow(S, cmap='RdBu_r', aspect='auto')
        axes[0, 1].set_title('Symmetric Matrix S')
        plt.colorbar(im2, ax=axes[0, 1])
        
        im3 = axes[1, 0].imshow(Q, cmap='RdBu_r', aspect='auto')
        axes[1, 0].set_title('Orthogonal Matrix Q')
        plt.colorbar(im3, ax=axes[1, 0])
        
        # Gram-Schmidt visualization
        input_vecs = orthogonal_results['input_vectors']
        if input_vecs.shape[0] == 2:  # 2D case
            axes[1, 1].scatter(input_vecs[0, :], input_vecs[1, :], 
                              c='blue', s=100, alpha=0.7, label='Original vectors')
            
            if Q.shape[0] == 2:
                axes[1, 1].scatter(Q[0, :], Q[1, :], 
                                  c='red', s=100, alpha=0.7, label='Orthogonal vectors')
                
                # Draw vectors from origin
                for i in range(Q.shape[1]):
                    axes[1, 1].arrow(0, 0, Q[0, i], Q[1, i], 
                                    head_width=0.1, head_length=0.1, 
                                    fc='red', ec='red', alpha=0.7)
            
            axes[1, 1].set_aspect('equal')
            axes[1, 1].grid(True, alpha=0.3)
            axes[1, 1].legend()
            axes[1, 1].set_title('Gram-Schmidt Result (2D)')
        else:
            # For higher dimensions, show orthogonality matrix
            if Q.shape[1] > 1:
                orthogonality_matrix = Q.T @ Q
                im4 = axes[1, 1].imshow(orthogonality_matrix, cmap='RdBu_r', aspect='auto')
                axes[1, 1].set_title('Q^T Q (should be identity)')
                plt.colorbar(im4, ax=axes[1, 1])
        
        plt.tight_layout()
        plt.show()
        
        return {'visualization_created': True}
    
    def explain_neural_network_applications(self, Q, S):
        """Explain applications in neural networks"""
        print(f"\n🧠 NEURAL NETWORK APPLICATIONS")
        print("=" * 50)
        
        print(f"🎯 ORTHOGONAL WEIGHT INITIALIZATION:")
        print(f"   - Initialize weight matrices as orthogonal")
        print(f"   - Prevents vanishing/exploding gradients")
        print(f"   - Preserves signal magnitude through layers")
        print(f"   - Example: W = Q where Q^T Q = I")
        
        print(f"\n📊 ATTENTION MECHANISMS:")
        print(f"   - Query-Key computation: Q^T K")
        print(f"   - Transpose operation is fundamental")
        print(f"   - Symmetric attention patterns in self-attention")
        
        print(f"\n🔄 LAYER NORMALIZATION:")
        print(f"   - Involves covariance matrix computation")
        print(f"   - Covariance matrices are symmetric")
        print(f"   - Eigendecomposition for whitening transformations")
        
        print(f"\n⚡ COMPUTATIONAL BENEFITS:")
        print(f"   - Orthogonal matrices: O(n) inversion vs O(n³)")
        print(f"   - Symmetric matrices: store only n(n+1)/2 elements")
        print(f"   - Numerical stability in optimization")
        
        # Example: Orthogonal regularization
        print(f"\n💡 ORTHOGONAL REGULARIZATION EXAMPLE:")
        print(f"   Loss term: λ ||W^T W - I||²_F")
        print(f"   Encourages weights to be orthogonal")
        
        if Q.shape[0] == Q.shape[1]:
            reg_term = np.linalg.norm(Q.T @ Q - np.eye(Q.shape[0]), 'fro')**2
            print(f"   For our Q: ||Q^T Q - I||²_F = {reg_term:.2e}")
    
    def get_result_explanation_question(self, results: Dict[str, Any]) -> str:
        transpose_results = results["transpose_results"]
        symmetric_results = results["symmetric_results"]
        orthogonal_results = results["orthogonal_results"]
        
        return f"""
Analyzing the matrix properties results:

TRANSPOSE ANALYSIS:
- Original matrix was symmetric: {transpose_results['is_symmetric']}

SYMMETRIC MATRIX:
- Definiteness: {symmetric_results['definiteness']}
- All eigenvalues real: {np.all(np.isreal(symmetric_results['eigenvalues']))}
- Eigenvalue range: [{symmetric_results['min_eigenval']:.3f}, {symmetric_results['max_eigenval']:.3f}]

ORTHOGONAL MATRIX:
- Successfully created {orthogonal_results['orthogonal_matrix'].shape[1]} orthonormal vectors
- Complete basis: {orthogonal_results['is_complete_basis']}

QUESTIONS:

1. Why are all eigenvalues of symmetric matrices guaranteed to be real? What does this 
   mean for applications like PCA?

2. How does the Gram-Schmidt process ensure orthogonality? Why is this important for 
   numerical stability?

3. What are the computational advantages of orthogonal matrices:
   - In solving linear systems?
   - In neural network weight initialization?
   - In preserving gradient magnitudes?

4. How do these matrix types appear in Transformers:
   - Transpose operations in attention (Q^T K)?
   - Symmetric patterns in self-attention?
   - Orthogonal initialization for stability?

5. If the symmetric matrix was positive definite, what would this tell us about:
   - The optimization landscape?
   - The covariance structure of data?
   - The stability of computations?

6. How would you use orthogonal regularization (λ ||W^T W - I||²) to improve 
   neural network training?
        """

# Test function for the exercise
def test_exercise_6():
    """Test function for Exercise 6"""
    print("Testing Exercise 6: Transpose, Symmetry, Orthogonal Matrices")
    
    # Mock logging system for testing
    class MockLoggingSystem:
        def set_current_exercise(self, ex_num, step): pass
        def complete_step(self, ex_num, step): pass
        def complete_exercise(self, ex_num): pass
        def log_student_response(self, ex_num, step, question, response): 
            print(f"Logged: {response}")
    
    mock_logger = MockLoggingSystem()
    exercise = Exercise6(mock_logger)
    
    # Test parameters
    test_params = {
        "matrix_size": 3,
        "num_vectors": 2,
        "random_seed": 42,
        "demo_type": "general"
    }
    
    try:
        results = exercise.execute_exercise(test_params)
        print("✓ Exercise 6 test completed successfully!")
        return True
    except Exception as e:
        print(f"❌ Exercise 6 test failed: {e}")
        return False

if __name__ == "__main__":
    test_exercise_6()