# exercises/exercise_3.py
"""
Exercise 3: Norms and Inner Product
Understanding vector magnitudes, angles, and similarity measures
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any
import sys
import os

# Add parent directory to path to import exercise_base
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from exercise_base import ExerciseBase

class Exercise3(ExerciseBase):
    def __init__(self, logging_system):
        super().__init__(logging_system, 3, "Norms and Inner Product")
    
    def define_steps(self) -> list:
        return [
            "concept_explanation",
            "concept_check", 
            "parameters",
            "execution",
            "results"
        ]
    
    def get_concept_explanation(self) -> str:
        return """
📐 NORMS AND INNER PRODUCT

KEY CONCEPTS:

1. INNER PRODUCT (DOT PRODUCT):
   - Definition: ⟨u,v⟩ = Σ uᵢvᵢ = u₁v₁ + u₂v₂ + ... + uₙvₙ
   - Geometric meaning: measures similarity and angle between vectors
   - Properties: symmetric, bilinear, positive definite

2. NORM (MAGNITUDE):
   - Definition: ||v|| = √⟨v,v⟩ = √(v₁² + v₂² + ... + vₙ²)
   - L2 norm (Euclidean): most common in ML
   - Other norms: L1 (Manhattan), L∞ (maximum), Lp
   - Geometric meaning: length of vector

3. ANGLE BETWEEN VECTORS:
   - Cosine similarity: cos θ = ⟨u,v⟩ / (||u|| ||v||)
   - θ = 0°: vectors point same direction (cos θ = 1)
   - θ = 90°: vectors are orthogonal (cos θ = 0)
   - θ = 180°: vectors point opposite directions (cos θ = -1)

4. NORMALIZATION:
   - Unit vector: û = u / ||u|| (magnitude = 1)
   - Preserves direction, standardizes magnitude
   - Essential for stable numerical computations

5. APPLICATIONS IN TRANSFORMERS:
   - Attention scores: similarity between query and key vectors
   - Layer normalization: normalizes activations
   - Cosine similarity: measures semantic similarity
   - Gradient clipping: controls norm of gradients

NUMPY OPERATIONS:
- np.dot(u, v): inner product
- np.linalg.norm(v): L2 norm
- u / np.linalg.norm(u): normalization
        """
    
    def get_concept_question(self) -> str:
        return """
Explain the relationship between inner product, norm, and angle between vectors. 
How does cosine similarity help measure semantic similarity in NLP, and why is 
normalization important in neural networks?
        """
    
    def get_required_parameters(self) -> Dict[str, str]:
        return {
            "vector_dimension": "Enter vector dimension (e.g., 3)",
            "num_vector_pairs": "Enter number of random vector pairs (e.g., 100)",
            "specific_vector1": "Enter first specific vector (comma-separated, e.g., 3,4,0)",
            "specific_vector2": "Enter second specific vector (comma-separated, e.g., 1,2,2)"
        }
    
    def execute_exercise(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the norms and inner product exercise"""
        
        # Extract parameters
        dim = int(params["vector_dimension"])
        num_pairs = int(params["num_vector_pairs"])
        
        # Parse specific vectors
        vec1_str = params["specific_vector1"].strip()
        vec2_str = params["specific_vector2"].strip()
        
        specific_v1 = np.array([float(x.strip()) for x in vec1_str.split(',')])
        specific_v2 = np.array([float(x.strip()) for x in vec2_str.split(',')])
        
        # Ensure specific vectors have correct dimension
        if len(specific_v1) != dim:
            specific_v1 = np.resize(specific_v1, dim)
        if len(specific_v2) != dim:
            specific_v2 = np.resize(specific_v2, dim)
        
        # Generate random vectors
        np.random.seed(42)
        random_vectors_u = np.random.uniform(-5, 5, (num_pairs, dim))
        random_vectors_v = np.random.uniform(-5, 5, (num_pairs, dim))
        
        # Detailed analysis of specific vectors
        specific_results = self.analyze_vector_pair(specific_v1, specific_v2, "Specific")
        
        # Analyze random vector pairs
        random_results = []
        cosine_similarities = []
        norms_u = []
        norms_v = []
        inner_products = []
        angles_degrees = []
        
        for i in range(num_pairs):
            u = random_vectors_u[i]
            v = random_vectors_v[i]
            
            result = self.analyze_vector_pair(u, v, f"Pair {i+1}")
            random_results.append(result)
            
            cosine_similarities.append(result['cosine_similarity'])
            norms_u.append(result['norm_u'])
            norms_v.append(result['norm_v'])
            inner_products.append(result['inner_product'])
            angles_degrees.append(result['angle_degrees'])
        
        # Display detailed results for specific vectors
        self.display_detailed_analysis(specific_results)
        
        # Statistical analysis of random vectors
        self.display_statistical_analysis(cosine_similarities, norms_u, norms_v, 
                                        inner_products, angles_degrees)
        
        # Create visualizations
        self.create_visualizations(specific_results, cosine_similarities, norms_u, norms_v,
                                 inner_products, angles_degrees, dim)
        
        # Demonstrate normalization
        self.demonstrate_normalization(specific_v1, specific_v2)
        
        # Connection to attention mechanisms
        self.explain_attention_connection(specific_v1, specific_v2, specific_results)
        
        results = {
            'specific_vectors': {'v1': specific_v1, 'v2': specific_v2},
            'specific_results': specific_results,
            'random_vectors_u': random_vectors_u,
            'random_vectors_v': random_vectors_v,
            'random_results': random_results,
            'statistics': {
                'cosine_similarities': cosine_similarities,
                'norms_u': norms_u,
                'norms_v': norms_v,
                'inner_products': inner_products,
                'angles_degrees': angles_degrees
            },
            'dimension': dim,
            'num_pairs': num_pairs
        }
        
        return results
    
    def analyze_vector_pair(self, u, v, pair_name):
        """Analyze a single pair of vectors"""
        # Basic computations
        inner_product = np.dot(u, v)
        norm_u = np.linalg.norm(u)
        norm_v = np.linalg.norm(v)
        
        # Avoid division by zero
        if norm_u == 0 or norm_v == 0:
            cosine_similarity = 0
            angle_radians = np.pi / 2
        else:
            cosine_similarity = inner_product / (norm_u * norm_v)
            # Clamp to [-1, 1] to avoid numerical errors
            cosine_similarity = np.clip(cosine_similarity, -1, 1)
            angle_radians = np.arccos(cosine_similarity)
        
        angle_degrees = np.degrees(angle_radians)
        
        # Normalized vectors
        unit_u = u / norm_u if norm_u != 0 else np.zeros_like(u)
        unit_v = v / norm_v if norm_v != 0 else np.zeros_like(v)
        
        # Verify normalization
        norm_unit_u = np.linalg.norm(unit_u)
        norm_unit_v = np.linalg.norm(unit_v)
        
        # Inner product of normalized vectors should equal cosine similarity
        normalized_inner_product = np.dot(unit_u, unit_v)
        
        return {
            'pair_name': pair_name,
            'u': u,
            'v': v,
            'inner_product': inner_product,
            'norm_u': norm_u,
            'norm_v': norm_v,
            'cosine_similarity': cosine_similarity,
            'angle_radians': angle_radians,
            'angle_degrees': angle_degrees,
            'unit_u': unit_u,
            'unit_v': unit_v,
            'norm_unit_u': norm_unit_u,
            'norm_unit_v': norm_unit_v,
            'normalized_inner_product': normalized_inner_product
        }
    
    def display_detailed_analysis(self, results):
        """Display detailed analysis of specific vector pair"""
        print(f"\n📊 DETAILED ANALYSIS: {results['pair_name']}")
        print("=" * 60)
        
        print(f"Vector u: {results['u']}")
        print(f"Vector v: {results['v']}")
        print()
        
        print(f"📏 NORMS:")
        print(f"   ||u|| = {results['norm_u']:.4f}")
        print(f"   ||v|| = {results['norm_v']:.4f}")
        print()
        
        print(f"🔗 INNER PRODUCT:")
        print(f"   ⟨u,v⟩ = {results['inner_product']:.4f}")
        print()
        
        print(f"📐 ANGLE ANALYSIS:")
        print(f"   cos θ = ⟨u,v⟩ / (||u|| ||v||) = {results['cosine_similarity']:.4f}")
        print(f"   θ = {results['angle_degrees']:.2f}°")
        
        # Interpret the angle
        if abs(results['cosine_similarity']) < 0.1:
            interpretation = "nearly orthogonal (perpendicular)"
        elif results['cosine_similarity'] > 0.9:
            interpretation = "very similar direction"
        elif results['cosine_similarity'] < -0.9:
            interpretation = "opposite directions"
        elif results['cosine_similarity'] > 0:
            interpretation = "acute angle (similar direction)"
        else:
            interpretation = "obtuse angle (different direction)"
        
        print(f"   Interpretation: {interpretation}")
        print()
        
        print(f"🎯 NORMALIZATION:")
        print(f"   û = u/||u|| = {results['unit_u']}")
        print(f"   v̂ = v/||v|| = {results['unit_v']}")
        print(f"   ||û|| = {results['norm_unit_u']:.6f} (should be 1.0)")
        print(f"   ||v̂|| = {results['norm_unit_v']:.6f} (should be 1.0)")
        print(f"   ⟨û,v̂⟩ = {results['normalized_inner_product']:.4f} (should equal cos θ)")
        print(f"   Verification: cos θ = {results['cosine_similarity']:.4f}")
    
    def display_statistical_analysis(self, cosine_similarities, norms_u, norms_v,
                                   inner_products, angles_degrees):
        """Display statistical analysis of random vector pairs"""
        print(f"\n📈 STATISTICAL ANALYSIS ({len(cosine_similarities)} random pairs)")
        print("=" * 60)
        
        print(f"COSINE SIMILARITY DISTRIBUTION:")
        print(f"   Mean: {np.mean(cosine_similarities):.4f}")
        print(f"   Std:  {np.std(cosine_similarities):.4f}")
        print(f"   Min:  {np.min(cosine_similarities):.4f}")
        print(f"   Max:  {np.max(cosine_similarities):.4f}")
        print(f"   Range: [{np.min(cosine_similarities):.4f}, {np.max(cosine_similarities):.4f}]")
        print()
        
        print(f"NORM STATISTICS:")
        print(f"   ||u|| - Mean: {np.mean(norms_u):.4f}, Std: {np.std(norms_u):.4f}")
        print(f"   ||v|| - Mean: {np.mean(norms_v):.4f}, Std: {np.std(norms_v):.4f}")
        print()
        
        print(f"ANGLE DISTRIBUTION:")
        print(f"   Mean angle: {np.mean(angles_degrees):.2f}°")
        print(f"   Std angle:  {np.std(angles_degrees):.2f}°")
        
        # Count vectors by angle ranges
        orthogonal_count = sum(1 for angle in angles_degrees if abs(angle - 90) < 10)
        parallel_count = sum(1 for angle in angles_degrees if angle < 30)
        antiparallel_count = sum(1 for angle in angles_degrees if angle > 150)
        
        print(f"   Nearly orthogonal (80°-100°): {orthogonal_count}")
        print(f"   Nearly parallel (0°-30°): {parallel_count}")
        print(f"   Nearly antiparallel (150°-180°): {antiparallel_count}")
    
    def create_visualizations(self, specific_results, cosine_similarities, norms_u, norms_v,
                            inner_products, angles_degrees, dim):
        """Create comprehensive visualizations"""
        
        fig = plt.figure(figsize=(16, 12))
        
        # Plot 1: Cosine similarity histogram
        plt.subplot(2, 3, 1)
        plt.hist(cosine_similarities, bins=30, alpha=0.7, edgecolor='black')
        plt.axvline(specific_results['cosine_similarity'], color='red', linestyle='--', 
                   label=f'Specific pair: {specific_results["cosine_similarity"]:.3f}')
        plt.xlabel('Cosine Similarity')
        plt.ylabel('Frequency')
        plt.title('Distribution of Cosine Similarities')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Plot 2: Angle distribution
        plt.subplot(2, 3, 2)
        plt.hist(angles_degrees, bins=30, alpha=0.7, edgecolor='black', color='orange')
        plt.axvline(specific_results['angle_degrees'], color='red', linestyle='--',
                   label=f'Specific pair: {specific_results["angle_degrees"]:.1f}°')
        plt.xlabel('Angle (degrees)')
        plt.ylabel('Frequency')
        plt.title('Distribution of Angles Between Vectors')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Plot 3: Norm vs norm scatter
        plt.subplot(2, 3, 3)
        plt.scatter(norms_u, norms_v, alpha=0.6, s=20)
        plt.scatter(specific_results['norm_u'], specific_results['norm_v'], 
                   color='red', s=100, label='Specific pair')
        plt.xlabel('||u||')
        plt.ylabel('||v||')
        plt.title('Norm Correlation')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Plot 4: Inner product vs cosine similarity
        plt.subplot(2, 3, 4)
        plt.scatter(inner_products, cosine_similarities, alpha=0.6, s=20)
        plt.scatter(specific_results['inner_product'], specific_results['cosine_similarity'],
                   color='red', s=100, label='Specific pair')
        plt.xlabel('Inner Product ⟨u,v⟩')
        plt.ylabel('Cosine Similarity')
        plt.title('Inner Product vs Cosine Similarity')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Plot 5: Norm distribution
        plt.subplot(2, 3, 5)
        plt.hist(norms_u, bins=20, alpha=0.5, label='||u||', color='blue')
        plt.hist(norms_v, bins=20, alpha=0.5, label='||v||', color='green')
        plt.axvline(specific_results['norm_u'], color='blue', linestyle='--', alpha=0.8)
        plt.axvline(specific_results['norm_v'], color='green', linestyle='--', alpha=0.8)
        plt.xlabel('Norm Value')
        plt.ylabel('Frequency')
        plt.title('Distribution of Vector Norms')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Plot 6: 2D projection if possible
        plt.subplot(2, 3, 6)
        if dim >= 2:
            # Project to first 2 dimensions for visualization
            u_2d = specific_results['u'][:2]
            v_2d = specific_results['v'][:2]
            unit_u_2d = specific_results['unit_u'][:2]
            unit_v_2d = specific_results['unit_v'][:2]
            
            # Draw vectors
            plt.arrow(0, 0, u_2d[0], u_2d[1], head_width=0.2, head_length=0.2, 
                     fc='blue', ec='blue', label='u')
            plt.arrow(0, 0, v_2d[0], v_2d[1], head_width=0.2, head_length=0.2, 
                     fc='red', ec='red', label='v')
            
            # Draw unit vectors
            plt.arrow(0, 0, unit_u_2d[0], unit_u_2d[1], head_width=0.1, head_length=0.1,
                     fc='lightblue', ec='lightblue', alpha=0.7, label='û')
            plt.arrow(0, 0, unit_v_2d[0], unit_v_2d[1], head_width=0.1, head_length=0.1,
                     fc='lightcoral', ec='lightcoral', alpha=0.7, label='v̂')
            
            # Draw angle arc
            angle_arc = np.linspace(0, specific_results['angle_radians'], 50)
            arc_radius = 0.5
            arc_x = arc_radius * np.cos(angle_arc)
            arc_y = arc_radius * np.sin(angle_arc)
            plt.plot(arc_x, arc_y, 'k--', alpha=0.5)
            
            plt.axis('equal')
            plt.grid(True, alpha=0.3)
            plt.legend()
            plt.title(f'Vector Visualization (2D projection)\nAngle: {specific_results["angle_degrees"]:.1f}°')
        else:
            plt.text(0.5, 0.5, 'Visualization not available\nfor 1D vectors', 
                    ha='center', va='center', transform=plt.gca().transAxes)
            plt.title('Vector Visualization')
        
        plt.tight_layout()
        plt.show()
    
    def demonstrate_normalization(self, u, v):
        """Demonstrate normalization process and its properties"""
        print(f"\n🎯 NORMALIZATION DEMONSTRATION")
        print("=" * 50)
        
        # Original vectors
        norm_u = np.linalg.norm(u)
        norm_v = np.linalg.norm(v)
        
        print(f"Original vectors:")
        print(f"   u = {u}, ||u|| = {norm_u:.4f}")
        print(f"   v = {v}, ||v|| = {norm_v:.4f}")
        
        # Normalize
        if norm_u > 0:
            unit_u = u / norm_u
            print(f"\nNormalized u:")
            print(f"   û = u/||u|| = {unit_u}")
            print(f"   ||û|| = {np.linalg.norm(unit_u):.6f}")
        
        if norm_v > 0:
            unit_v = v / norm_v
            print(f"\nNormalized v:")
            print(f"   v̂ = v/||v|| = {unit_v}")
            print(f"   ||v̂|| = {np.linalg.norm(unit_v):.6f}")
        
        # Compare inner products
        if norm_u > 0 and norm_v > 0:
            original_inner = np.dot(u, v)
            normalized_inner = np.dot(unit_u, unit_v)
            cosine_sim = original_inner / (norm_u * norm_v)
            
            print(f"\nInner product comparison:")
            print(f"   ⟨u,v⟩ = {original_inner:.4f}")
            print(f"   ⟨û,v̂⟩ = {normalized_inner:.4f}")
            print(f"   cos θ = ⟨u,v⟩/(||u||·||v||) = {cosine_sim:.4f}")
            print(f"   Normalized inner product equals cosine similarity: {np.isclose(normalized_inner, cosine_sim)}")
        
        print(f"\n💡 WHY NORMALIZATION MATTERS:")
        print(f"   - Removes magnitude bias, focuses on direction")
        print(f"   - Stabilizes numerical computations")
        print(f"   - Essential in attention mechanisms")
        print(f"   - Helps with gradient flow in deep networks")
    
    def explain_attention_connection(self, u, v, results):
        """Explain connection to attention mechanisms"""
        print(f"\n🤖 CONNECTION TO ATTENTION MECHANISMS")
        print("=" * 60)
        
        print(f"🎯 ATTENTION SCORE COMPUTATION:")
        print(f"   - Query vector (Q): {u}")
        print(f"   - Key vector (K): {v}")
        print(f"   - Attention score: Q·K = {results['inner_product']:.4f}")
        print(f"   - Scaled attention: Q·K/√d = {results['inner_product']/np.sqrt(len(u)):.4f}")
        
        print(f"\n📊 SIMILARITY INTERPRETATION:")
        cos_sim = results['cosine_similarity']
        if cos_sim > 0.8:
            interpretation = "High attention - very relevant"
        elif cos_sim > 0.5:
            interpretation = "Moderate attention - somewhat relevant"
        elif cos_sim > 0:
            interpretation = "Low attention - slightly relevant"
        elif cos_sim > -0.5:
            interpretation = "Very low attention - not relevant"
        else:
            interpretation = "Negative attention - opposing concepts"
        
        print(f"   - Cosine similarity: {cos_sim:.4f}")
        print(f"   - Interpretation: {interpretation}")
        
        print(f"\n🔧 NORMALIZATION IN PRACTICE:")
        print(f"   - Layer normalization uses L2 norm")
        print(f"   - Helps prevent exploding/vanishing gradients")
        print(f"   - Cosine similarity used in semantic search")
        
        # Simulate attention with multiple keys
        print(f"\n💡 ATTENTION SIMULATION:")
        np.random.seed(123)
        num_keys = 5
        keys = np.random.randn(num_keys, len(u))
        
        print(f"   Query: {u}")
        print(f"   Keys and attention scores:")
        
        attention_scores = []
        for i, key in enumerate(keys):
            score = np.dot(u, key)
            cosine = score / (np.linalg.norm(u) * np.linalg.norm(key))
            attention_scores.append(score)
            print(f"     Key {i+1}: score={score:.3f}, cosine={cosine:.3f}")
        
        # Apply softmax
        attention_weights = np.exp(attention_scores) / np.sum(np.exp(attention_scores))
        print(f"\n   Softmax weights: {attention_weights}")
        print(f"   Sum of weights: {np.sum(attention_weights):.6f} (should be 1.0)")
    
    def get_result_explanation_question(self, results: Dict[str, Any]) -> str:
        specific_results = results["specific_results"]
        stats = results["statistics"]
        
        return f"""
Analyzing the inner product and norm results:

SPECIFIC VECTORS ANALYSIS:
- Your vectors had cosine similarity: {specific_results['cosine_similarity']:.4f}
- Angle between them: {specific_results['angle_degrees']:.2f}°
- Norms: ||u|| = {specific_results['norm_u']:.3f}, ||v|| = {specific_results['norm_v']:.3f}

STATISTICAL OBSERVATIONS:
- Random pairs cosine similarity mean: {np.mean(stats['cosine_similarities']):.4f}
- Angle distribution centered around: {np.mean(stats['angles_degrees']):.1f}°

QUESTIONS:
1. What does the cosine similarity value tell you about the relationship between your specific vectors?

2. Why might the mean cosine similarity of random vectors be close to 0?

3. How would you interpret these results in the context of:
   - Word embeddings similarity?
   - Attention scores in Transformers?

4. What happens to attention scores when:
   - Vectors are orthogonal (cos θ = 0)?
   - Vectors are parallel (cos θ = 1)?
   - Vectors are antiparallel (cos θ = -1)?

5. Why is normalization crucial in neural networks, and how does it affect the attention mechanism?

6. If these were word embeddings, what would high/low cosine similarity indicate about word relationships?
        """

# Test function for the exercise
def test_exercise_3():
    """Test function for Exercise 3"""
    print("Testing Exercise 3: Norms and Inner Product")
    
    # Mock logging system for testing
    class MockLoggingSystem:
        def set_current_exercise(self, ex_num, step): pass
        def complete_step(self, ex_num, step): pass
        def complete_exercise(self, ex_num): pass
        def log_student_response(self, ex_num, step, question, response): 
            print(f"Logged: {response}")
    
    mock_logger = MockLoggingSystem()
    exercise = Exercise3(mock_logger)
    
    # Test parameters
    test_params = {
        "vector_dimension": 3,
        "num_vector_pairs": 50,
        "specific_vector1": "3,4,0",
        "specific_vector2": "1,2,2"
    }
    
    try:
        results = exercise.execute_exercise(test_params)
        print("✓ Exercise 3 test completed successfully!")
        return True
    except Exception as e:
        print(f"❌ Exercise 3 test failed: {e}")
        return False

if __name__ == "__main__":
    test_exercise_3()