# exercises/exercise_7.py
"""
Exercise 7: Linear Transformations, Image, Kernel
Understanding the fundamental concepts of linear algebra: image and kernel spaces
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any, List
import sys
import os

# Add parent directory to path to import exercise_base
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from exercise_base import ExerciseBase

class Exercise7(ExerciseBase):
    def __init__(self, logging_system):
        super().__init__(logging_system, 7, "Linear Transformations, Image, Kernel")
    
    def define_steps(self) -> list:
        return [
            "concept_explanation",
            "concept_check", 
            "parameters",
            "execution",
            "results"
        ]
    
    def get_concept_explanation(self) -> str:
        return """
🔄 LINEAR TRANSFORMATIONS, IMAGE, KERNEL

KEY CONCEPTS:

1. LINEAR TRANSFORMATION:
   - Function T: R^n → R^m that preserves linear combinations
   - T(αu + βv) = αT(u) + βT(v) for all scalars α, β
   - Represented by matrix multiplication: T(x) = Ax
   - Maps vectors from domain to codomain

2. KERNEL (NULL SPACE):
   - ker(A) = {x ∈ R^n : Ax = 0}
   - All vectors that map to the zero vector
   - Always contains the zero vector
   - Subspace of the domain R^n
   - Dimension = nullity of A

3. IMAGE (COLUMN SPACE):
   - Im(A) = {Ax : x ∈ R^n} = span(columns of A)
   - All possible output vectors of the transformation
   - Subspace of the codomain R^m
   - Dimension = rank of A

4. RANK-NULLITY THEOREM:
   - rank(A) + nullity(A) = n (number of columns)
   - dim(Im(A)) + dim(ker(A)) = n
   - Fundamental relationship in linear algebra

5. GEOMETRIC INTERPRETATION:
   - Kernel: directions that get "collapsed" to zero
   - Image: all reachable destinations
   - Rank: degrees of freedom in the output
   - Nullity: degrees of freedom lost in the mapping

6. APPLICATIONS IN DEEP LEARNING:
   - Neural network layers as linear transformations
   - Kernel: information lost in the transformation
   - Image: representational capacity of the layer
   - Bottleneck layers: low rank (small image)
   - Skip connections: preserve kernel information

NUMPY OPERATIONS:
- np.linalg.matrix_rank(A): rank of matrix
- np.linalg.svd(A): singular value decomposition
- scipy.linalg.null_space(A): basis for kernel
        """
    
    def get_concept_question(self) -> str:
        return """
Explain the relationship between the kernel and image of a linear transformation. 
How does the rank-nullity theorem connect these concepts, and what does this mean 
for information preservation in neural network layers?
        """
    
    def get_required_parameters(self) -> Dict[str, str]:
        return {
            "matrix_rows": "Enter number of rows (output dimension, e.g., 3)",
            "matrix_cols": "Enter number of columns (input dimension, e.g., 5)",
            "target_rank": "Enter desired rank (e.g., 2, must be ≤ min(rows, cols))",
            "num_test_vectors": "Enter number of test vectors (e.g., 10)",
            "random_seed": "Enter random seed (e.g., 42)"
        }
    
    def execute_exercise(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the linear transformations exercise"""
        
        # Extract parameters
        m = int(params["matrix_rows"])
        n = int(params["matrix_cols"])
        target_rank = min(int(params["target_rank"]), min(m, n))
        num_test = int(params["num_test_vectors"])
        seed = int(params["random_seed"])
        
        np.random.seed(seed)
        
        # Create matrix with specified rank
        A = self.create_matrix_with_rank(m, n, target_rank)
        
        # Compute kernel and image
        kernel_analysis = self.analyze_kernel(A)
        image_analysis = self.analyze_image(A)
        
        # Verify rank-nullity theorem
        rank_nullity_check = self.verify_rank_nullity_theorem(A, kernel_analysis, image_analysis)
        
        # Test linear transformation properties
        linearity_tests = self.test_linearity_properties(A, num_test)
        
        # Analyze transformation behavior
        transformation_analysis = self.analyze_transformation_behavior(A, kernel_analysis, image_analysis)
        
        # Geometric visualization (if dimensions allow)
        if m <= 3 and n <= 3:
            geometric_results = self.create_geometric_visualization(A, kernel_analysis, image_analysis)
        else:
            geometric_results = self.create_statistical_visualization(A, kernel_analysis, image_analysis)
        
        # Connection to neural networks
        self.explain_neural_network_connection(A, kernel_analysis, image_analysis)
        
        results = {
            'matrix_A': A,
            'matrix_dimensions': (m, n),
            'target_rank': target_rank,
            'kernel_analysis': kernel_analysis,
            'image_analysis': image_analysis,
            'rank_nullity_check': rank_nullity_check,
            'linearity_tests': linearity_tests,
            'transformation_analysis': transformation_analysis,
            'geometric_results': geometric_results
        }
        
        return results
    
    def create_matrix_with_rank(self, m, n, target_rank):
        """Create a matrix with specified rank"""
        print(f"\n🔧 CREATING MATRIX WITH RANK {target_rank}")
        print("=" * 50)
        
        # Create matrix using SVD: A = U Σ V^T
        U = np.random.randn(m, target_rank)
        V = np.random.randn(n, target_rank)
        
        # Make U and V orthonormal
        U, _ = np.linalg.qr(U)
        V, _ = np.linalg.qr(V)
        
        # Create diagonal matrix with target_rank non-zero values
        sigma = np.random.uniform(0.5, 3.0, target_rank)
        sigma = np.sort(sigma)[::-1]  # Sort in descending order
        
        # Construct A = U Σ V^T
        A = U @ np.diag(sigma) @ V.T
        
        # Verify rank
        actual_rank = np.linalg.matrix_rank(A)
        
        print(f"Target rank: {target_rank}")
        print(f"Actual rank: {actual_rank}")
        print(f"Matrix shape: {A.shape}")
        print(f"Singular values: {sigma}")
        
        if A.shape[0] <= 4 and A.shape[1] <= 4:
            print(f"Matrix A:")
            print(A)
        
        return A
    
    def analyze_kernel(self, A):
        """Analyze the kernel (null space) of the matrix"""
        print(f"\n🕳️ KERNEL ANALYSIS")
        print("=" * 30)
        
        # Compute SVD to find kernel
        U, s, Vt = np.linalg.svd(A, full_matrices=True)
        
        # Find rank and nullity
        tolerance = 1e-10
        rank = np.sum(s > tolerance)
        nullity = A.shape[1] - rank
        
        print(f"Matrix rank: {rank}")
        print(f"Matrix nullity: {nullity}")
        print(f"Kernel dimension: {nullity}")
        
        # Extract kernel basis
        if nullity > 0:
            kernel_basis = Vt[rank:, :].T  # Last (n-rank) rows of V^T, transposed
            print(f"\nKernel basis vectors:")
            for i in range(nullity):
                print(f"   v{i+1} = {kernel_basis[:, i]}")
                
                # Verify it's in the kernel
                Av = A @ kernel_basis[:, i]
                norm_Av = np.linalg.norm(Av)
                print(f"   ||A v{i+1}|| = {norm_Av:.2e} (should be ≈ 0)")
            
            # Check orthogonality of basis vectors
            if nullity > 1:
                print(f"\n   Orthogonality check:")
                for i in range(nullity):
                    for j in range(i+1, nullity):
                        dot_product = np.dot(kernel_basis[:, i], kernel_basis[:, j])
                        print(f"   ⟨v{i+1}, v{j+1}⟩ = {dot_product:.2e}")
        else:
            kernel_basis = np.zeros((A.shape[1], 0))
            print(f"   Kernel contains only the zero vector")
        
        return {
            'rank': rank,
            'nullity': nullity,
            'kernel_basis': kernel_basis,
            'singular_values': s
        }
    
    def analyze_image(self, A):
        """Analyze the image (column space) of the matrix"""
        print(f"\n🎯 IMAGE ANALYSIS")
        print("=" * 30)
        
        # Compute SVD
        U, s, Vt = np.linalg.svd(A, full_matrices=True)
        
        tolerance = 1e-10
        rank = np.sum(s > tolerance)
        
        print(f"Image dimension: {rank}")
        print(f"Codomain dimension: {A.shape[0]}")
        
        # Extract image basis (first rank columns of U)
        image_basis = U[:, :rank]
        
        print(f"\nImage basis vectors:")
        for i in range(rank):
            print(f"   u{i+1} = {image_basis[:, i]}")
        
        # Verify orthonormality
        if rank > 1:
            print(f"\n   Orthonormality check:")
            for i in range(min(rank, 3)):  # Check first few
                norm = np.linalg.norm(image_basis[:, i])
                print(f"   ||u{i+1}|| = {norm:.6f}")
                
                for j in range(i+1, min(rank, 3)):
                    dot_product = np.dot(image_basis[:, i], image_basis[:, j])
                    print(f"   ⟨u{i+1}, u{j+1}⟩ = {dot_product:.2e}")
        
        # Test if random combinations are in the image
        print(f"\n   Testing image membership:")
        test_vector = np.random.randn(A.shape[1])
        Ax = A @ test_vector
        
        # Project onto image basis
        projection = image_basis @ (image_basis.T @ Ax)
        reconstruction_error = np.linalg.norm(Ax - projection)
        
        print(f"   Random Ax projected back: ||Ax - P_Im(Ax)|| = {reconstruction_error:.2e}")
        
        return {
            'dimension': rank,
            'image_basis': image_basis,
            'test_vector': test_vector,
            'Ax': Ax,
            'reconstruction_error': reconstruction_error
        }
    
    def verify_rank_nullity_theorem(self, A, kernel_analysis, image_analysis):
        """Verify the rank-nullity theorem"""
        print(f"\n⚖️ RANK-NULLITY THEOREM VERIFICATION")
        print("=" * 50)
        
        n = A.shape[1]  # Number of columns
        rank = image_analysis['dimension']
        nullity = kernel_analysis['nullity']
        
        print(f"Matrix dimensions: {A.shape[0]} × {A.shape[1]}")
        print(f"Rank: {rank}")
        print(f"Nullity: {nullity}")
        print(f"Sum: rank + nullity = {rank + nullity}")
        print(f"Number of columns: {n}")
        
        theorem_satisfied = (rank + nullity == n)
        print(f"\nRank-nullity theorem satisfied? {theorem_satisfied}")
        
        if not theorem_satisfied:
            print(f"⚠️  Theorem not satisfied! This shouldn't happen with exact arithmetic.")
        
        # Additional insights
        print(f"\nInterpretation:")
        print(f"   - {rank} dimensions preserved in the transformation")
        print(f"   - {nullity} dimensions collapsed to zero")
        print(f"   - Total: {n} input dimensions accounted for")
        
        return {
            'rank': rank,
            'nullity': nullity,
            'n_cols': n,
            'theorem_satisfied': theorem_satisfied
        }
    
    def test_linearity_properties(self, A, num_test):
        """Test that A represents a linear transformation"""
        print(f"\n🧪 LINEARITY PROPERTIES TEST")
        print("=" * 40)
        
        print(f"Testing linearity: T(αu + βv) = αT(u) + βT(v)")
        
        # Generate random test vectors and scalars
        np.random.seed(123)  # For reproducible tests
        test_results = []
        
        for i in range(num_test):
            # Random vectors and scalars
            u = np.random.randn(A.shape[1])
            v = np.random.randn(A.shape[1])
            alpha = np.random.uniform(-3, 3)
            beta = np.random.uniform(-3, 3)
            
            # Test linearity
            left_side = A @ (alpha * u + beta * v)
            right_side = alpha * (A @ u) + beta * (A @ v)
            
            difference = np.linalg.norm(left_side - right_side)
            test_results.append(difference)
        
        max_error = np.max(test_results)
        mean_error = np.mean(test_results)
        
        print(f"Tests performed: {num_test}")
        print(f"Maximum error: {max_error:.2e}")
        print(f"Mean error: {mean_error:.2e}")
        print(f"Linearity satisfied? {max_error < 1e-10}")
        
        # Test additivity: T(u + v) = T(u) + T(v)
        u = np.random.randn(A.shape[1])
        v = np.random.randn(A.shape[1])
        
        additivity_left = A @ (u + v)
        additivity_right = (A @ u) + (A @ v)
        additivity_error = np.linalg.norm(additivity_left - additivity_right)
        
        print(f"\nAdditivity test:")
        print(f"   ||T(u+v) - T(u) - T(v)|| = {additivity_error:.2e}")
        
        # Test homogeneity: T(αu) = αT(u)
        alpha = np.random.uniform(-5, 5)
        homogeneity_left = A @ (alpha * u)
        homogeneity_right = alpha * (A @ u)
        homogeneity_error = np.linalg.norm(homogeneity_left - homogeneity_right)
        
        print(f"\nHomogeneity test:")
        print(f"   ||T(αu) - αT(u)|| = {homogeneity_error:.2e}")
        
        return {
            'linearity_errors': test_results,
            'max_error': max_error,
            'mean_error': mean_error,
            'additivity_error': additivity_error,
            'homogeneity_error': homogeneity_error
        }
    
    def analyze_transformation_behavior(self, A, kernel_analysis, image_analysis):
        """Analyze how the transformation behaves"""
        print(f"\n🔍 TRANSFORMATION BEHAVIOR ANALYSIS")
        print("=" * 50)
        
        # Test what happens to kernel vectors
        print(f"1. KERNEL BEHAVIOR:")
        if kernel_analysis['nullity'] > 0:
            kernel_basis = kernel_analysis['kernel_basis']
            for i in range(kernel_analysis['nullity']):
                v = kernel_basis[:, i]
                Av = A @ v
                print(f"   Kernel vector v{i+1}: ||v|| = {np.linalg.norm(v):.3f} → ||Av|| = {np.linalg.norm(Av):.2e}")
        else:
            print(f"   No non-trivial kernel vectors")
        
        # Test random vectors
        print(f"\n2. RANDOM VECTOR BEHAVIOR:")
        for i in range(5):
            v = np.random.randn(A.shape[1])
            Av = A @ v
            compression_ratio = np.linalg.norm(Av) / np.linalg.norm(v) if np.linalg.norm(v) > 0 else 0
            print(f"   Vector {i+1}: ||v|| = {np.linalg.norm(v):.3f} → ||Av|| = {np.linalg.norm(Av):.3f} (ratio: {compression_ratio:.3f})")
        
        # Analyze singular values for compression understanding
        s = kernel_analysis['singular_values']
        print(f"\n3. SINGULAR VALUE ANALYSIS:")
        print(f"   Singular values: {s}")
        if len(s) > 1:
            condition_number = s[0] / s[-1] if s[-1] > 1e-10 else np.inf
            print(f"   Condition number: {condition_number:.2e}")
            print(f"   Compression range: [{s[-1]:.3f}, {s[0]:.3f}]")
        
        # Test image spanning
        print(f"\n4. IMAGE SPANNING TEST:")
        image_basis = image_analysis['image_basis']
        
        # Generate random vector in the image
        coeffs = np.random.randn(image_analysis['dimension'])
        vector_in_image = image_basis @ coeffs
        
        # Try to find preimage
        # Solve Ax = vector_in_image using least squares
        try:
            preimage, residuals, rank, s_vals = np.linalg.lstsq(A, vector_in_image, rcond=None)
            reconstruction = A @ preimage
            reconstruction_error = np.linalg.norm(vector_in_image - reconstruction)
            
            print(f"   Generated vector in image: ||y|| = {np.linalg.norm(vector_in_image):.3f}")
            print(f"   Found preimage: ||x|| = {np.linalg.norm(preimage):.3f}")
            print(f"   Reconstruction error: ||y - Ax|| = {reconstruction_error:.2e}")
        except:
            print(f"   Could not find preimage (this shouldn't happen)")
        
        return {
            'singular_values': s,
            'condition_number': s[0] / s[-1] if len(s) > 0 and s[-1] > 1e-10 else np.inf,
            'compression_ratios': [np.linalg.norm(A @ np.random.randn(A.shape[1])) / np.linalg.norm(np.random.randn(A.shape[1])) for _ in range(5)]
        }
    
    def create_geometric_visualization(self, A, kernel_analysis, image_analysis):
        """Create geometric visualization for low-dimensional cases"""
        print(f"\n🎨 GEOMETRIC VISUALIZATION")
        print("=" * 40)
        
        m, n = A.shape
        
        if n == 2 and m == 2:
            return self.visualize_2d_to_2d_transformation(A, kernel_analysis, image_analysis)
        elif n == 3 and m == 2:
            return self.visualize_3d_to_2d_transformation(A, kernel_analysis, image_analysis)
        elif n == 2 and m == 3:
            return self.visualize_2d_to_3d_transformation(A, kernel_analysis, image_analysis)
        else:
            return self.create_statistical_visualization(A, kernel_analysis, image_analysis)
    
    def visualize_2d_to_2d_transformation(self, A, kernel_analysis, image_analysis):
        """Visualize 2D to 2D transformation"""
        fig, axes = plt.subplots(1, 2, figsize=(15, 6))
        
        # Create grid of input vectors
        x = np.linspace(-2, 2, 20)
        y = np.linspace(-2, 2, 20)
        X, Y = np.meshgrid(x, y)
        input_points = np.column_stack([X.ravel(), Y.ravel()])
        
        # Transform points
        output_points = (A @ input_points.T).T
        
        # Plot input space
        axes[0].scatter(input_points[:, 0], input_points[:, 1], alpha=0.6, s=20, c='blue')
        
        # Draw kernel if it exists
        if kernel_analysis['nullity'] > 0:
            kernel_vec = kernel_analysis['kernel_basis'][:, 0]
            # Draw line through kernel direction
            t = np.linspace(-3, 3, 100)
            kernel_line = np.outer(t, kernel_vec)
            axes[0].plot(kernel_line[:, 0], kernel_line[:, 1], 'r-', linewidth=3, 
                        label=f'Kernel (maps to 0)')
        
        axes[0].set_aspect('equal')
        axes[0].grid(True, alpha=0.3)
        axes[0].set_title('Input Space (Domain)')
        axes[0].legend()
        
        # Plot output space
        axes[1].scatter(output_points[:, 0], output_points[:, 1], alpha=0.6, s=20, c='red')
        
        # Draw image basis
        image_basis = image_analysis['image_basis']
        for i in range(image_analysis['dimension']):
            basis_vec = image_basis[:, i]
            axes[1].arrow(0, 0, basis_vec[0]*2, basis_vec[1]*2, 
                         head_width=0.1, head_length=0.1, fc='green', ec='green',
                         label=f'Image basis {i+1}' if i == 0 else '')
        
        axes[1].set_aspect('equal')
        axes[1].grid(True, alpha=0.3)
        axes[1].set_title('Output Space (Codomain)')
        axes[1].legend()
        
        plt.tight_layout()
        plt.show()
        
        return {'visualization_type': '2d_to_2d'}
    
    def create_statistical_visualization(self, A, kernel_analysis, image_analysis):
        """Create statistical visualization for higher dimensions"""
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        
        # Singular values
        s = kernel_analysis['singular_values']
        axes[0, 0].bar(range(len(s)), s, alpha=0.7)
        axes[0, 0].set_title('Singular Values')
        axes[0, 0].set_xlabel('Index')
        axes[0, 0].set_ylabel('Value')
        axes[0, 0].grid(True, alpha=0.3)
        
        # Matrix heatmap
        im = axes[0, 1].imshow(A, cmap='RdBu_r', aspect='auto')
        axes[0, 1].set_title('Matrix A')
        plt.colorbar(im, ax=axes[0, 1])
        
        # Kernel basis (if exists)
        if kernel_analysis['nullity'] > 0:
            kernel_basis = kernel_analysis['kernel_basis']
            im2 = axes[1, 0].imshow(kernel_basis, cmap='RdBu_r', aspect='auto')
            axes[1, 0].set_title('Kernel Basis Vectors')
            plt.colorbar(im2, ax=axes[1, 0])
        else:
            axes[1, 0].text(0.5, 0.5, 'No kernel\n(trivial null space)', 
                           ha='center', va='center', transform=axes[1, 0].transAxes)
            axes[1, 0].set_title('Kernel')
        
        # Image basis
        image_basis = image_analysis['image_basis']
        im3 = axes[1, 1].imshow(image_basis, cmap='RdBu_r', aspect='auto')
        axes[1, 1].set_title('Image Basis Vectors')
        plt.colorbar(im3, ax=axes[1, 1])
        
        plt.tight_layout()
        plt.show()
        
        return {'visualization_type': 'statistical'}
    
    def explain_neural_network_connection(self, A, kernel_analysis, image_analysis):
        """Explain connection to neural networks"""
        print(f"\n🧠 NEURAL NETWORK CONNECTION")
        print("=" * 50)
        
        rank = image_analysis['dimension']
        nullity = kernel_analysis['nullity']
        m, n = A.shape
        
        print(f"🔗 LINEAR LAYER INTERPRETATION:")
        print(f"   - Input features: {n}")
        print(f"   - Output features: {m}")
        print(f"   - Effective rank: {rank}")
        print(f"   - Information loss: {nullity} dimensions")
        
        print(f"\n📊 INFORMATION FLOW:")
        print(f"   - Kernel: information that gets lost")
        print(f"   - Image: representational capacity")
        print(f"   - Rank deficiency indicates redundancy")
        
        print(f"\n🎯 PRACTICAL IMPLICATIONS:")
        
        if nullity > 0:
            print(f"   ⚠️  INFORMATION BOTTLENECK:")
            print(f"     - {nullity} input directions are completely lost")
            print(f"     - May indicate overparameterization")
            print(f"     - Could benefit from dimensionality reduction")
        else:
            print(f"   ✓ FULL RANK TRANSFORMATION:")
            print(f"     - All input information is preserved")
            print(f"     - Invertible if square matrix")
        
        compression_ratio = rank / n
        print(f"\n📈 COMPRESSION ANALYSIS:")
        print(f"   - Compression ratio: {compression_ratio:.2f}")
        print(f"   - Information retention: {compression_ratio*100:.1f}%")
        
        if compression_ratio < 0.5:
            print(f"   - High compression layer (bottleneck)")
        elif compression_ratio < 0.8:
            print(f"   - Moderate compression")
        else:
            print(f"   - Low compression (information preserving)")
        
        print(f"\n💡 ARCHITECTURAL INSIGHTS:")
        print(f"   - Skip connections can preserve kernel information")
        print(f"   - Attention mechanisms create adaptive transformations")
        print(f"   - Regularization can control rank and prevent overfitting")
        
        # Example of how this relates to common architectures
        print(f"\n🏗️ COMMON ARCHITECTURES:")
        print(f"   - Autoencoder bottleneck: intentionally low rank")
        print(f"   - Transformer feedforward: rank preservation important")
        print(f"   - CNN filters: local rank analysis")
    
    def get_result_explanation_question(self, results: Dict[str, Any]) -> str:
        kernel_analysis = results["kernel_analysis"]
        image_analysis = results["image_analysis"]
        rank_nullity = results["rank_nullity_check"]
        m, n = results["matrix_dimensions"]
        
        return f"""
Analyzing the linear transformation results:

TRANSFORMATION: R^{n} → R^{m}
RANK: {rank_nullity['rank']}
NULLITY: {rank_nullity['nullity']}

KERNEL (NULL SPACE):
- Dimension: {kernel_analysis['nullity']}
- Contains: {kernel_analysis['nullity']} linearly independent vectors that map to zero

IMAGE (COLUMN SPACE):
- Dimension: {image_analysis['dimension']}
- Spans: {image_analysis['dimension']}-dimensional subspace of R^{m}

QUESTIONS:

1. What does the rank-nullity theorem tell us about this transformation?
   rank + nullity = {rank_nullity['rank']} + {rank_nullity['nullity']} = {rank_nullity['n_cols']}

2. Information perspective:
   - How much information is lost? ({kernel_analysis['nullity']} dimensions)
   - How much is preserved? ({image_analysis['dimension']} dimensions)
   - What does this mean for invertibility?

3. If this were a neural network layer:
   - What would the kernel represent in terms of input features?
   - How would the image dimension affect the layer's expressiveness?
   - Would you consider this a bottleneck layer?

4. Geometric interpretation:
   - What happens to vectors in the kernel?
   - How does the transformation "reshape" the input space?
   - Why can't we recover the original input from the output?

5. Practical implications:
   - How would skip connections help preserve information?
   - When might you want a low-rank transformation?
   - How does this relate to feature extraction vs. compression?

6. If you could modify this transformation, how would you:
   - Reduce information loss?
   - Increase compression while preserving important features?
   - Make it more suitable for a specific task?
        """

# Test function for the exercise
def test_exercise_7():
    """Test function for Exercise 7"""
    print("Testing Exercise 7: Linear Transformations, Image, Kernel")
    
    # Mock logging system for testing
    class MockLoggingSystem:
        def set_current_exercise(self, ex_num, step): pass
        def complete_step(self, ex_num, step): pass
        def complete_exercise(self, ex_num): pass
        def log_student_response(self, ex_num, step, question, response): 
            print(f"Logged: {response}")
    
    mock_logger = MockLoggingSystem()
    exercise = Exercise7(mock_logger)
    
    # Test parameters
    test_params = {
        "matrix_rows": 3,
        "matrix_cols": 4,
        "target_rank": 2,
        "num_test_vectors": 5,
        "random_seed": 42
    }
    
    try:
        results = exercise.execute_exercise(test_params)
        print("✓ Exercise 7 test completed successfully!")
        return True
    except Exception as e:
        print(f"❌ Exercise 7 test failed: {e}")
        return False

if __name__ == "__main__":
    test_exercise_7()