# exercises/exercise_11.py
"""
Exercise 11: Final Integrative Exercise - Transformer Attention
Bringing together all linear algebra concepts in a complete Transformer attention simulation
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any, Tuple, List
import sys
import os

# Add parent directory to path to import exercise_base
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from exercise_base import ExerciseBase

class Exercise11(ExerciseBase):
    def __init__(self, logging_system):
        super().__init__(logging_system, 11, "Final Integrative Exercise - Transformer Attention")
    
    def define_steps(self) -> list:
        return [
            "concept_explanation",
            "concept_check", 
            "parameters",
            "execution",
            "results"
        ]
    
    def get_concept_explanation(self) -> str:
        return """
🎭 TRANSFORMER ATTENTION: INTEGRATING LINEAR ALGEBRA

BRINGING TOGETHER ALL CONCEPTS:

1. ATTENTION MECHANISM OVERVIEW:
   - Input: sequence of embeddings X ∈ R^(seq_len × d_model)
   - Query, Key, Value projections: Q = XW_Q, K = XW_K, V = XW_V
   - Attention scores: S = QK^T / √d_k
   - Attention weights: A = softmax(S)
   - Output: Z = AV

2. LINEAR ALGEBRA CONCEPTS APPLIED:

   📐 VECTORS & SHAPES (Exercise 1):
   - Embeddings as vectors in high-dimensional space
   - Shape consistency: (seq_len, d_model) matrices

   ➕ VECTOR OPERATIONS (Exercise 2):
   - Residual connections: output = input + attention(input)
   - Layer normalization involving vector scaling

   📏 NORMS & INNER PRODUCTS (Exercise 3):
   - QK^T computes similarity between queries and keys
   - Cosine similarity interpretation of attention scores

   ⟂ PROJECTIONS (Exercise 4):
   - Value vectors projected based on attention weights
   - Information filtering through attention mechanism

   🔢 MATRIX MULTIPLICATION (Exercise 5):
   - Core operation: QK^T, then AV
   - Batch processing multiple sequences simultaneously

   🔄 TRANSPOSES (Exercise 6):
   - K^T for query-key attention computation
   - Symmetric attention patterns in self-attention

   🎯 LINEAR TRANSFORMATIONS (Exercise 7):
   - W_Q, W_K, W_V as learned linear transformations
   - Information preservation and kernel analysis

   🎨 LOW-RANK METHODS (Exercise 8):
   - LoRA fine-tuning of attention weights
   - Efficient adaptation of pre-trained models

   🔍 SVD ANALYSIS (Exercise 9):
   - Attention weight matrix decomposition
   - Understanding attention patterns and redundancy

   👑 EIGENANALYSIS (Exercise 10):
   - Stability of attention mechanisms
   - Principal attention directions

3. MATHEMATICAL FORMULATION:
   Attention(Q,K,V) = softmax(QK^T/√d_k)V

4. MULTI-HEAD ATTENTION:
   - Multiple parallel attention computations
   - Concat(head_1, ..., head_h)W_O
   - Different subspaces capture different patterns

5. PRACTICAL CONSIDERATIONS:
   - Numerical stability with scaled dot-product
   - Memory efficiency in implementation
   - Gradient flow and optimization challenges
        """
    
    def get_concept_question(self) -> str:
        return """
Explain how the Transformer attention mechanism integrates multiple linear algebra 
concepts. How do matrix multiplications, norms, projections, and eigenvalues all 
play roles in computing attention? What are the key computational and conceptual 
challenges in implementing efficient attention?
        """
    
    def get_required_parameters(self) -> Dict[str, str]:
        return {
            "sequence_length": "Enter sequence length (e.g., 8)",
            "d_model": "Enter model dimension (e.g., 64)",
            "num_heads": "Enter number of attention heads (e.g., 4)",
            "d_k": "Enter key/query dimension (e.g., 16)",
            "d_v": "Enter value dimension (e.g., 16)",
            "use_lora": "Use LoRA adaptation? (yes/no)",
            "lora_rank": "Enter LoRA rank if using LoRA (e.g., 4)",
            "random_seed": "Enter random seed (e.g., 42)"
        }
    
    def execute_exercise(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the complete Transformer attention analysis"""
        
        # Extract parameters
        seq_len = int(params["sequence_length"])
        d_model = int(params["d_model"])
        num_heads = int(params["num_heads"])
        d_k = int(params["d_k"])
        d_v = int(params["d_v"])
        use_lora = params["use_lora"].lower().strip() == "yes"
        lora_rank = int(params["lora_rank"]) if use_lora else None
        seed = int(params["random_seed"])
        
        np.random.seed(seed)
        
        # Generate sample input sequence
        input_data = self.create_sample_input(seq_len, d_model)
        
        # Initialize attention weights
        attention_weights = self.initialize_attention_weights(d_model, d_k, d_v, num_heads, use_lora, lora_rank)
        
        # Perform complete attention computation
        attention_results = self.compute_attention_mechanism(input_data, attention_weights, num_heads)
        
        # Analyze each linear algebra component
        component_analysis = self.analyze_linear_algebra_components(input_data, attention_weights, attention_results)
        
        # Multi-head attention analysis
        multihead_analysis = self.analyze_multihead_attention(attention_results, num_heads)
        
        # LoRA analysis (if applicable)
        lora_analysis = self.analyze_lora_adaptation(attention_weights, use_lora, lora_rank) if use_lora else None
        
        # Performance and efficiency analysis
        efficiency_analysis = self.analyze_computational_efficiency(seq_len, d_model, num_heads, d_k, d_v)
        
        # Create comprehensive visualizations
        visualization_results = self.create_comprehensive_visualizations(
            input_data, attention_results, component_analysis, multihead_analysis)
        
        # Integration summary
        integration_summary = self.create_integration_summary(component_analysis)
        
        results = {
            'input_data': input_data,
            'attention_weights': attention_weights,
            'attention_results': attention_results,
            'component_analysis': component_analysis,
            'multihead_analysis': multihead_analysis,
            'lora_analysis': lora_analysis,
            'efficiency_analysis': efficiency_analysis,
            'visualization_results': visualization_results,
            'integration_summary': integration_summary,
            'parameters': {
                'seq_len': seq_len,
                'd_model': d_model,
                'num_heads': num_heads,
                'd_k': d_k,
                'd_v': d_v,
                'use_lora': use_lora,
                'lora_rank': lora_rank
            }
        }
        
        return results
    
    def create_sample_input(self, seq_len, d_model):
        """Create sample input embeddings"""
        print(f"\n🎯 CREATING SAMPLE INPUT SEQUENCE")
        print("=" * 50)
        
        # Create structured input that represents meaningful tokens
        X = np.zeros((seq_len, d_model))
        
        # Add some structure to make attention patterns meaningful
        for i in range(seq_len):
            # Base embedding
            X[i, :] = np.random.randn(d_model) * 0.1
            
            # Add position-dependent patterns
            X[i, :d_model//4] += np.sin(2 * np.pi * i / seq_len)  # Position encoding like
            X[i, d_model//4:d_model//2] += i / seq_len  # Linear position
            
            # Add token-type patterns
            if i < seq_len // 2:
                X[i, d_model//2:3*d_model//4] += 1.0  # "Type A" tokens
            else:
                X[i, 3*d_model//4:] += 1.0  # "Type B" tokens
        
        # Normalize
        X = X / np.linalg.norm(X, axis=1, keepdims=True)
        
        print(f"Input sequence shape: {X.shape}")
        print(f"Sequence length: {seq_len}")
        print(f"Model dimension: {d_model}")
        print(f"Input statistics: mean={np.mean(X):.4f}, std={np.std(X):.4f}")
        
        # Analyze input properties
        input_norms = np.linalg.norm(X, axis=1)
        pairwise_similarities = X @ X.T
        
        print(f"Token norms: min={np.min(input_norms):.4f}, max={np.max(input_norms):.4f}")
        print(f"Pairwise similarities: min={np.min(pairwise_similarities):.4f}, max={np.max(pairwise_similarities):.4f}")
        
        return {
            'embeddings': X,
            'token_norms': input_norms,
            'pairwise_similarities': pairwise_similarities
        }
    
    def initialize_attention_weights(self, d_model, d_k, d_v, num_heads, use_lora, lora_rank):
        """Initialize attention weight matrices"""
        print(f"\n⚙️ INITIALIZING ATTENTION WEIGHTS")
        print("=" * 50)
        
        # Standard weight initialization (Xavier/Glorot)
        def xavier_init(shape):
            fan_in, fan_out = shape[0], shape[1]
            limit = np.sqrt(6.0 / (fan_in + fan_out))
            return np.random.uniform(-limit, limit, shape)
        
        weights = {}
        
        # Query, Key, Value projection matrices for all heads
        total_d_k = d_k * num_heads
        total_d_v = d_v * num_heads
        
        W_Q = xavier_init((d_model, total_d_k))
        W_K = xavier_init((d_model, total_d_k))
        W_V = xavier_init((d_model, total_d_v))
        W_O = xavier_init((total_d_v, d_model))  # Output projection
        
        weights.update({
            'W_Q': W_Q,
            'W_K': W_K, 
            'W_V': W_V,
            'W_O': W_O
        })
        
        print(f"Weight matrix shapes:")
        print(f"   W_Q: {W_Q.shape} (input -> queries)")
        print(f"   W_K: {W_K.shape} (input -> keys)")
        print(f"   W_V: {W_V.shape} (input -> values)")
        print(f"   W_O: {W_O.shape} (concat heads -> output)")
        
        # LoRA adaptation if requested
        if use_lora and lora_rank:
            print(f"\n🎨 ADDING LoRA ADAPTATION (rank {lora_rank})")
            
            # LoRA matrices for each weight matrix
            for name, W in [('W_Q', W_Q), ('W_K', W_K), ('W_V', W_V), ('W_O', W_O)]:
                A = np.random.randn(W.shape[0], lora_rank) * 0.01
                B = np.random.randn(lora_rank, W.shape[1]) * 0.01
                
                weights[f'{name}_lora_A'] = A
                weights[f'{name}_lora_B'] = B
                
                # Updated weight: W_new = W + A @ B
                weights[f'{name}_adapted'] = W + A @ B
                
                print(f"   {name} LoRA: A{A.shape} @ B{B.shape}")
        
        # Analyze weight properties
        self.analyze_weight_properties(weights)
        
        return weights
    
    def analyze_weight_properties(self, weights):
        """Analyze properties of weight matrices"""
        print(f"\n📊 WEIGHT MATRIX ANALYSIS:")
        
        for name, W in weights.items():
            if not name.endswith('_lora_A') and not name.endswith('_lora_B'):
                # Compute basic statistics
                norm_frobenius = np.linalg.norm(W, 'fro')
                spectral_norm = np.linalg.norm(W, 2)
                condition_number = np.linalg.cond(W)
                
                print(f"   {name}: ||W||_F={norm_frobenius:.3f}, ||W||_2={spectral_norm:.3f}, κ(W)={condition_number:.2e}")
    
    def compute_attention_mechanism(self, input_data, weights, num_heads):
        """Compute the complete attention mechanism"""
        print(f"\n🧠 COMPUTING ATTENTION MECHANISM")
        print("=" * 50)
        
        X = input_data['embeddings']
        seq_len, d_model = X.shape
        
        # Choose whether to use LoRA adapted weights or original
        W_Q = weights.get('W_Q_adapted', weights['W_Q'])
        W_K = weights.get('W_K_adapted', weights['W_K'])
        W_V = weights.get('W_V_adapted', weights['W_V'])
        W_O = weights.get('W_O_adapted', weights['W_O'])
        
        # Compute Q, K, V
        Q = X @ W_Q  # (seq_len, num_heads * d_k)
        K = X @ W_K  # (seq_len, num_heads * d_k)
        V = X @ W_V  # (seq_len, num_heads * d_v)
        
        print(f"Projection shapes:")
        print(f"   Q: {Q.shape}")
        print(f"   K: {K.shape}")
        print(f"   V: {V.shape}")
        
        # Reshape for multi-head attention
        d_k = Q.shape[1] // num_heads
        d_v = V.shape[1] // num_heads
        
        Q_heads = Q.reshape(seq_len, num_heads, d_k)
        K_heads = K.reshape(seq_len, num_heads, d_k)
        V_heads = V.reshape(seq_len, num_heads, d_v)
        
        # Compute attention for each head
        attention_scores = []
        attention_weights_list = []
        attention_outputs = []
        
        for h in range(num_heads):
            Q_h = Q_heads[:, h, :]  # (seq_len, d_k)
            K_h = K_heads[:, h, :]  # (seq_len, d_k)
            V_h = V_heads[:, h, :]  # (seq_len, d_v)
            
            # Compute attention scores: Q_h @ K_h^T / sqrt(d_k)
            scores = (Q_h @ K_h.T) / np.sqrt(d_k)
            attention_scores.append(scores)
            
            # Apply softmax to get attention weights
            exp_scores = np.exp(scores - np.max(scores, axis=1, keepdims=True))  # Numerical stability
            attention_weights = exp_scores / np.sum(exp_scores, axis=1, keepdims=True)
            attention_weights_list.append(attention_weights)
            
            # Compute weighted combination of values
            output_h = attention_weights @ V_h
            attention_outputs.append(output_h)
        
        # Concatenate outputs from all heads
        concatenated_output = np.concatenate(attention_outputs, axis=1)  # (seq_len, num_heads * d_v)
        
        # Final output projection
        final_output = concatenated_output @ W_O
        
        print(f"\nAttention computation completed:")
        print(f"   Concatenated output: {concatenated_output.shape}")
        print(f"   Final output: {final_output.shape}")
        
        return {
            'Q': Q,
            'K': K,
            'V': V,
            'Q_heads': Q_heads,
            'K_heads': K_heads,
            'V_heads': V_heads,
            'attention_scores': attention_scores,
            'attention_weights': attention_weights_list,
            'attention_outputs': attention_outputs,
            'concatenated_output': concatenated_output,
            'final_output': final_output
        }
    
    def analyze_linear_algebra_components(self, input_data, weights, attention_results):
        """Analyze how each linear algebra concept applies"""
        print(f"\n🔍 LINEAR ALGEBRA COMPONENT ANALYSIS")
        print("=" * 60)
        
        X = input_data['embeddings']
        analysis = {}
        
        # 1. Vector Operations (Exercise 1 & 2)
        print(f"1. VECTOR OPERATIONS:")
        Q = attention_results['Q']
        K = attention_results['K']
        V = attention_results['V']
        
        # Analyze vector norms
        q_norms = np.linalg.norm(Q, axis=1)
        k_norms = np.linalg.norm(K, axis=1)
        v_norms = np.linalg.norm(V, axis=1)
        
        print(f"   Query norms: mean={np.mean(q_norms):.4f}, std={np.std(q_norms):.4f}")
        print(f"   Key norms: mean={np.mean(k_norms):.4f}, std={np.std(k_norms):.4f}")
        print(f"   Value norms: mean={np.mean(v_norms):.4f}, std={np.std(v_norms):.4f}")
        
        analysis['vector_norms'] = {
            'q_norms': q_norms,
            'k_norms': k_norms,
            'v_norms': v_norms
        }
        
        # 2. Inner Products and Similarity (Exercise 3)
        print(f"\n2. INNER PRODUCTS & SIMILARITY:")
        
        # Analyze attention scores (before softmax)
        scores = attention_results['attention_scores'][0]  # First head
        print(f"   Attention scores shape: {scores.shape}")
        print(f"   Score statistics: min={np.min(scores):.4f}, max={np.max(scores):.4f}, mean={np.mean(scores):.4f}")
        
        # Cosine similarities
        Q_normalized = Q / np.linalg.norm(Q, axis=1, keepdims=True)
        K_normalized = K / np.linalg.norm(K, axis=1, keepdims=True)
        cosine_similarities = Q_normalized @ K_normalized.T
        
        print(f"   Cosine similarities: min={np.min(cosine_similarities):.4f}, max={np.max(cosine_similarities):.4f}")
        
        analysis['similarities'] = {
            'attention_scores': scores,
            'cosine_similarities': cosine_similarities
        }
        
        # 3. Matrix Multiplication Chain (Exercise 5)
        print(f"\n3. MATRIX MULTIPLICATION CHAIN:")
        
        # Count operations
        seq_len, d_model = X.shape
        num_heads = len(attention_results['attention_scores'])
        d_k = Q.shape[1] // num_heads
        
        # X @ W_Q, X @ W_K, X @ W_V
        projection_ops = 3 * seq_len * d_model * d_k * num_heads
        
        # Q @ K^T for each head
        attention_ops = num_heads * seq_len * seq_len * d_k
        
        # A @ V for each head
        value_ops = num_heads * seq_len * seq_len * (attention_results['V'].shape[1] // num_heads)
        
        total_ops = projection_ops + attention_ops + value_ops
        
        print(f"   Projection operations: {projection_ops:,}")
        print(f"   Attention score operations: {attention_ops:,}")
        print(f"   Value combination operations: {value_ops:,}")
        print(f"   Total operations: {total_ops:,}")
        
        analysis['operations'] = {
            'projection_ops': projection_ops,
            'attention_ops': attention_ops,
            'value_ops': value_ops,
            'total_ops': total_ops
        }
        
        # 4. Orthogonality Analysis (Exercise 6)
        print(f"\n4. ORTHOGONALITY ANALYSIS:")
        
        # Check if weight matrices have orthogonal properties
        W_Q = weights['W_Q']
        orthogonality_Q = np.linalg.norm(W_Q.T @ W_Q - np.eye(W_Q.shape[1]), 'fro')
        
        print(f"   W_Q orthogonality deviation: {orthogonality_Q:.4f}")
        
        # Analyze attention weight distributions
        attention_weights = attention_results['attention_weights'][0]
        row_sums = np.sum(attention_weights, axis=1)
        print(f"   Attention weight row sums (should be 1): min={np.min(row_sums):.6f}, max={np.max(row_sums):.6f}")
        
        analysis['orthogonality'] = {
            'weight_orthogonality': orthogonality_Q,
            'attention_row_sums': row_sums
        }
        
        # 5. Rank Analysis (Exercise 7 & 8)
        print(f"\n5. RANK ANALYSIS:")
        
        ranks = {}
        for name in ['Q', 'K', 'V']:
            matrix = attention_results[name]
            rank = np.linalg.matrix_rank(matrix)
            ranks[name] = rank
            print(f"   rank({name}) = {rank} / {min(matrix.shape)}")
        
        # Attention weight matrix rank
        attention_rank = np.linalg.matrix_rank(attention_weights)
        print(f"   rank(Attention) = {attention_rank} / {min(attention_weights.shape)}")
        
        analysis['ranks'] = ranks
        analysis['attention_rank'] = attention_rank
        
        # 6. SVD Analysis (Exercise 9)
        print(f"\n6. SVD ANALYSIS:")
        
        # SVD of attention weights
        U, s, Vt = np.linalg.svd(attention_weights)
        energy_90 = np.sum(s**2) * 0.9
        cumulative_energy = np.cumsum(s**2)
        components_90 = np.sum(cumulative_energy < energy_90) + 1
        
        print(f"   Attention singular values: {s[:5]}")
        print(f"   Components for 90% energy: {components_90} / {len(s)}")
        
        analysis['svd'] = {
            'singular_values': s,
            'components_90': components_90
        }
        
        return analysis
    
    def analyze_multihead_attention(self, attention_results, num_heads):
        """Analyze multi-head attention patterns"""
        print(f"\n👥 MULTI-HEAD ATTENTION ANALYSIS")
        print("=" * 50)
        
        attention_weights_list = attention_results['attention_weights']
        
        # Analyze diversity between heads
        head_similarities = np.zeros((num_heads, num_heads))
        
        for i in range(num_heads):
            for j in range(num_heads):
                # Flatten attention matrices and compute correlation
                attn_i = attention_weights_list[i].flatten()
                attn_j = attention_weights_list[j].flatten()
                
                correlation = np.corrcoef(attn_i, attn_j)[0, 1]
                head_similarities[i, j] = correlation
        
        print(f"Head similarity matrix:")
        print(head_similarities)
        
        # Analyze attention pattern statistics for each head
        head_stats = []
        for h in range(num_heads):
            attn = attention_weights_list[h]
            
            # Entropy (measure of attention spread)
            entropy = -np.sum(attn * np.log(attn + 1e-10), axis=1)
            
            # Max attention (measure of focus)
            max_attention = np.max(attn, axis=1)
            
            # Self-attention (diagonal values)
            self_attention = np.diag(attn)
            
            head_stats.append({
                'entropy': entropy,
                'max_attention': max_attention,
                'self_attention': self_attention,
                'mean_entropy': np.mean(entropy),
                'mean_max_attention': np.mean(max_attention),
                'mean_self_attention': np.mean(self_attention)
            })
            
            print(f"\nHead {h+1}:")
            print(f"   Mean entropy: {np.mean(entropy):.4f}")
            print(f"   Mean max attention: {np.mean(max_attention):.4f}")
            print(f"   Mean self-attention: {np.mean(self_attention):.4f}")
        
        # Analyze head specialization
        head_diversity = np.mean(1 - head_similarities[np.triu_indices_from(head_similarities, k=1)])
        print(f"\nOverall head diversity: {head_diversity:.4f}")
        
        return {
            'head_similarities': head_similarities,
            'head_stats': head_stats,
            'head_diversity': head_diversity
        }
    
    def analyze_lora_adaptation(self, weights, use_lora, lora_rank):
        """Analyze LoRA adaptation effects"""
        if not use_lora:
            return None
            
        print(f"\n🎨 LoRA ADAPTATION ANALYSIS")
        print("=" * 50)
        
        analysis = {}
        
        for base_name in ['W_Q', 'W_K', 'W_V', 'W_O']:
            W_original = weights[base_name]
            W_adapted = weights[f'{base_name}_adapted']
            A = weights[f'{base_name}_lora_A']
            B = weights[f'{base_name}_lora_B']
            
            # Compute LoRA update
            delta_W = A @ B
            
            # Analyze update magnitude
            original_norm = np.linalg.norm(W_original, 'fro')
            update_norm = np.linalg.norm(delta_W, 'fro')
            relative_update = update_norm / original_norm
            
            # Compute rank
            delta_rank = np.linalg.matrix_rank(delta_W)
            
            print(f"{base_name} LoRA analysis:")
            print(f"   Original norm: {original_norm:.4f}")
            print(f"   Update norm: {update_norm:.4f}")
            print(f"   Relative update: {relative_update:.4f}")
            print(f"   Update rank: {delta_rank} (target: {lora_rank})")
            
            # Parameter efficiency
            original_params = W_original.size
            lora_params = A.size + B.size
            efficiency = lora_params / original_params
            
            print(f"   Parameter efficiency: {efficiency:.4f} ({lora_params:,} / {original_params:,})")
            
            analysis[base_name] = {
                'original_norm': original_norm,
                'update_norm': update_norm,
                'relative_update': relative_update,
                'delta_rank': delta_rank,
                'parameter_efficiency': efficiency
            }
        
        return analysis
    
    def analyze_computational_efficiency(self, seq_len, d_model, num_heads, d_k, d_v):
        """Analyze computational efficiency of attention"""
        print(f"\n⚡ COMPUTATIONAL EFFICIENCY ANALYSIS")
        print("=" * 60)
        
        # Memory analysis
        input_memory = seq_len * d_model * 4  # 4 bytes per float32
        
        # QKV projections
        qkv_memory = seq_len * (d_k + d_k + d_v) * num_heads * 4
        
        # Attention scores
        attention_scores_memory = seq_len * seq_len * num_heads * 4
        
        # Total memory
        total_memory = input_memory + qkv_memory + attention_scores_memory
        
        print(f"Memory analysis (bytes):")
        print(f"   Input embeddings: {input_memory:,}")
        print(f"   QKV projections: {qkv_memory:,}")
        print(f"   Attention scores: {attention_scores_memory:,}")
        print(f"   Total: {total_memory:,} ({total_memory/1024/1024:.2f} MB)")
        
        # Computational complexity
        # O(seq_len^2 * d_model) for attention computation
        attention_complexity = seq_len**2 * d_model * num_heads
        projection_complexity = seq_len * d_model * (d_k + d_k + d_v) * num_heads
        total_complexity = attention_complexity + projection_complexity
        
        print(f"\nComputational complexity:")
        print(f"   Attention: O({seq_len}² × {d_model}) = {attention_complexity:,} ops")
        print(f"   Projections: O({seq_len} × {d_model}²) = {projection_complexity:,} ops")
        print(f"   Total: {total_complexity:,} ops")
        
        # Scalability analysis
        print(f"\nScalability analysis:")
        for scale in [2, 4, 8]:
            scaled_seq = seq_len * scale
            scaled_complexity = scaled_seq**2 * d_model * num_heads
            scaling_factor = scaled_complexity / attention_complexity
            
            print(f"   {scale}× sequence length: {scaling_factor:.1f}× computational cost")
        
        return {
            'memory': {
                'input': input_memory,
                'qkv': qkv_memory,
                'attention': attention_scores_memory,
                'total': total_memory
            },
            'complexity': {
                'attention': attention_complexity,
                'projection': projection_complexity,
                'total': total_complexity
            }
        }
    
    def create_comprehensive_visualizations(self, input_data, attention_results, component_analysis, multihead_analysis):
        """Create comprehensive visualizations of the attention mechanism"""
        fig = plt.figure(figsize=(20, 16))
        
        # 1. Input embeddings heatmap
        plt.subplot(4, 4, 1)
        plt.imshow(input_data['embeddings'].T, cmap='viridis', aspect='auto')
        plt.title('Input Embeddings')
        plt.xlabel('Sequence Position')
        plt.ylabel('Embedding Dimension')
        plt.colorbar()
        
        # 2. Query matrix
        plt.subplot(4, 4, 2)
        plt.imshow(attention_results['Q'].T, cmap='viridis', aspect='auto')
        plt.title('Query Matrix Q')
        plt.xlabel('Sequence Position')
        plt.ylabel('Query Dimension')
        plt.colorbar()
        
        # 3. Key matrix
        plt.subplot(4, 4, 3)
        plt.imshow(attention_results['K'].T, cmap='viridis', aspect='auto')
        plt.title('Key Matrix K')
        plt.xlabel('Sequence Position')
        plt.ylabel('Key Dimension')
        plt.colorbar()
        
        # 4. Value matrix
        plt.subplot(4, 4, 4)
        plt.imshow(attention_results['V'].T, cmap='viridis', aspect='auto')
        plt.title('Value Matrix V')
        plt.xlabel('Sequence Position')
        plt.ylabel('Value Dimension')
        plt.colorbar()
        
        # 5-8. Attention weights for first 4 heads
        for head in range(min(4, len(attention_results['attention_weights']))):
            plt.subplot(4, 4, 5 + head)
            attn = attention_results['attention_weights'][head]
            plt.imshow(attn, cmap='Blues', aspect='auto')
            plt.title(f'Attention Head {head+1}')
            plt.xlabel('Key Position')
            plt.ylabel('Query Position')
            plt.colorbar()
        
        # 9. Attention scores (before softmax) for head 1
        plt.subplot(4, 4, 9)
        scores = attention_results['attention_scores'][0]
        plt.imshow(scores, cmap='RdBu_r', aspect='auto')
        plt.title('Attention Scores (Head 1)')
        plt.xlabel('Key Position')
        plt.ylabel('Query Position')
        plt.colorbar()
        
        # 10. Final output
        plt.subplot(4, 4, 10)
        plt.imshow(attention_results['final_output'].T, cmap='viridis', aspect='auto')
        plt.title('Final Output')
        plt.xlabel('Sequence Position')
        plt.ylabel('Output Dimension')
        plt.colorbar()
        
        # 11. Singular values of attention weights (head 1)
        plt.subplot(4, 4, 11)
        svd_data = component_analysis['svd']
        plt.semilogy(svd_data['singular_values'], 'bo-', alpha=0.7)
        plt.title('Attention SVD Spectrum')
        plt.xlabel('Component')
        plt.ylabel('Singular Value (log)')
        plt.grid(True, alpha=0.3)
        
        # 12. Head similarity matrix
        plt.subplot(4, 4, 12)
        head_sim = multihead_analysis['head_similarities']
        plt.imshow(head_sim, cmap='RdBu_r', aspect='auto')
        plt.title('Head Similarity Matrix')
        plt.xlabel('Head')
        plt.ylabel('Head')
        plt.colorbar()
        
        # 13. Attention entropy by head
        plt.subplot(4, 4, 13)
        head_stats = multihead_analysis['head_stats']
        entropies = [stats['mean_entropy'] for stats in head_stats]
        plt.bar(range(len(entropies)), entropies, alpha=0.7)
        plt.title('Mean Attention Entropy by Head')
        plt.xlabel('Head')
        plt.ylabel('Entropy')
        plt.grid(True, alpha=0.3)
        
        # 14. Vector norms distribution
        plt.subplot(4, 4, 14)
        norms = component_analysis['vector_norms']
        plt.hist(norms['q_norms'], alpha=0.5, label='Query', bins=10)
        plt.hist(norms['k_norms'], alpha=0.5, label='Key', bins=10)
        plt.hist(norms['v_norms'], alpha=0.5, label='Value', bins=10)
        plt.title('Vector Norms Distribution')
        plt.xlabel('Norm')
        plt.ylabel('Frequency')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # 15. Attention score distribution
        plt.subplot(4, 4, 15)
        scores_flat = attention_results['attention_scores'][0].flatten()
        plt.hist(scores_flat, bins=20, alpha=0.7, edgecolor='black')
        plt.title('Attention Scores Distribution')
        plt.xlabel('Score Value')
        plt.ylabel('Frequency')
        plt.grid(True, alpha=0.3)
        
        # 16. Cosine similarity matrix
        plt.subplot(4, 4, 16)
        cosine_sim = component_analysis['similarities']['cosine_similarities']
        plt.imshow(cosine_sim, cmap='RdBu_r', aspect='auto')
        plt.title('Input Cosine Similarities')
        plt.xlabel('Token')
        plt.ylabel('Token')
        plt.colorbar()
        
        plt.tight_layout()
        plt.show()
        
        return {'comprehensive_visualization_created': True}
    
    def create_integration_summary(self, component_analysis):
        """Create summary of how all linear algebra concepts integrate"""
        print(f"\n🎭 INTEGRATION SUMMARY")
        print("=" * 60)
        
        print(f"LINEAR ALGEBRA CONCEPTS IN TRANSFORMER ATTENTION:")
        print(f"="*60)
        
        print(f"\n1. 📐 VECTORS & SHAPES:")
        print(f"   ✓ Input embeddings represent tokens as high-dimensional vectors")
        print(f"   ✓ Shape consistency ensures matrix multiplications are valid")
        print(f"   ✓ Broadcasting enables efficient batch processing")
        
        print(f"\n2. ➕ VECTOR OPERATIONS:")
        norms = component_analysis['vector_norms']
        print(f"   ✓ Linear projections transform embeddings to Q, K, V spaces")
        print(f"   ✓ Query norms: {np.mean(norms['q_norms']):.3f} ± {np.std(norms['q_norms']):.3f}")
        print(f"   ✓ Key norms: {np.mean(norms['k_norms']):.3f} ± {np.std(norms['k_norms']):.3f}")
        
        print(f"\n3. 📏 INNER PRODUCTS & SIMILARITY:")
        similarities = component_analysis['similarities']
        print(f"   ✓ QK^T computes attention scores via inner products")
        print(f"   ✓ Attention score range: [{np.min(similarities['attention_scores']):.3f}, {np.max(similarities['attention_scores']):.3f}]")
        print(f"   ✓ Cosine similarity interpretation reveals semantic relationships")
        
        print(f"\n4. ⟂ PROJECTIONS & ORTHOGONALITY:")
        ortho = component_analysis['orthogonality']
        print(f"   ✓ Value vectors projected via attention weights")
        print(f"   ✓ Attention weights are stochastic (rows sum to 1)")
        print(f"   ✓ Weight orthogonality deviation: {ortho['weight_orthogonality']:.4f}")
        
        print(f"\n5. 🔢 MATRIX MULTIPLICATIONS:")
        ops = component_analysis['operations']
        print(f"   ✓ Chain of matrix multiplications: X→Q,K,V→Scores→Weights→Output")
        print(f"   ✓ Total operations: {ops['total_ops']:,}")
        print(f"   ✓ Quadratic complexity in sequence length")
        
        print(f"\n6. 🔄 TRANSPOSES:")
        print(f"   ✓ K^T enables query-key similarity computation")
        print(f"   ✓ Symmetric attention patterns in self-attention")
        print(f"   ✓ Efficient implementation via transposed operations")
        
        print(f"\n7. 🎯 RANK & INFORMATION:")
        ranks = component_analysis['ranks']
        print(f"   ✓ Query rank: {ranks['Q']}, Key rank: {ranks['K']}, Value rank: {ranks['V']}")
        print(f"   ✓ Attention rank: {component_analysis['attention_rank']}")
        print(f"   ✓ Low-rank structure enables efficient approximations")
        
        print(f"\n8. 🎨 LOW-RANK ADAPTATION:")
        print(f"   ✓ LoRA enables efficient fine-tuning")
        print(f"   ✓ Rank constraints preserve most information while reducing parameters")
        print(f"   ✓ Modular adaptation for different tasks")
        
        print(f"\n9. 🔍 SVD DECOMPOSITION:")
        svd = component_analysis['svd']
        print(f"   ✓ Attention weights have {svd['components_90']} dominant components (90% energy)")
        print(f"   ✓ SVD reveals attention pattern structure")
        print(f"   ✓ Compression potential via top singular vectors")
        
        print(f"\n10. 👑 EIGENVALUE INSIGHTS:")
        print(f"   ✓ Attention weight eigenvalues determine convergence properties")
        print(f"   ✓ Spectral analysis reveals stability and mixing")
        print(f"   ✓ Principal attention directions capture dominant patterns")
        
        return {
            'concepts_demonstrated': 10,
            'integration_complete': True,
            'key_insights': [
                'Attention mechanisms are fundamentally built on linear algebra',
                'Each concept plays a crucial role in computation and understanding',
                'Efficiency and interpretability come from mathematical structure',
                'Modern deep learning leverages classical linear algebra principles'
            ]
        }
    
    def get_result_explanation_question(self, results: Dict[str, Any]) -> str:
        params = results["parameters"]
        component_analysis = results["component_analysis"]
        multihead_analysis = results["multihead_analysis"]
        efficiency_analysis = results["efficiency_analysis"]
        
        return f"""
Analyzing the complete Transformer attention mechanism:

CONFIGURATION:
- Sequence length: {params['seq_len']}
- Model dimension: {params['d_model']}
- Number of heads: {params['num_heads']}
- Key/Query dimension: {params['d_k']}
- Value dimension: {params['d_v']}
- LoRA enabled: {params['use_lora']}

COMPUTATIONAL ANALYSIS:
- Total operations: {component_analysis['operations']['total_ops']:,}
- Memory usage: {efficiency_analysis['memory']['total']/1024/1024:.2f} MB
- Head diversity: {multihead_analysis['head_diversity']:.3f}

QUESTIONS:

1. Linear Algebra Integration:
   - How do you see each of the 10 exercises contributing to attention computation?
   - Which linear algebra concepts are most critical for understanding attention?
   - How do matrix multiplications create the "attention" effect?

2. Multi-Head Analysis:
   - What does the head diversity score {multihead_analysis['head_diversity']:.3f} tell you?
   - How do different heads capture different types of relationships?
   - Why is having diverse attention heads beneficial?

3. Computational Efficiency:
   - What makes attention computationally expensive?
   - How does the O(sequence²) complexity affect scalability?
   - What optimization strategies could reduce computational cost?

4. Attention Patterns:
   - What do the attention weight distributions reveal about the model?
   - How do the singular values indicate information compression?
   - What patterns do you observe in the attention visualizations?

5. LoRA Integration (if used):
   - How does LoRA adaptation affect the attention computation?
   - What are the trade-offs between parameter efficiency and expressiveness?
   - How could you extend LoRA to other parts of the attention mechanism?

6. Practical Implementation:
   - What numerical stability concerns arise in attention computation?
   - How would you implement this efficiently for large sequences?
   - What are the memory vs. computation trade-offs?

7. Theoretical Understanding:
   - Why does the scaled dot-product attention formula work well?
   - How do residual connections interact with attention outputs?
   - What role does layer normalization play in the complete mechanism?

8. Extensions and Improvements:
   - How could you modify attention for better efficiency or performance?
   - What linear algebra insights suggest new attention variants?
   - How might sparse attention patterns affect the mathematical properties?

This exercise demonstrates how fundamental linear algebra concepts combine to create 
powerful machine learning mechanisms. Every matrix multiplication, projection, and 
decomposition serves a specific purpose in the attention computation!
        """

# Test function for the exercise
def test_exercise_11():
    """Test function for Exercise 11"""
    print("Testing Exercise 11: Final Integrative Exercise - Transformer Attention")
    
    # Mock logging system for testing
    class MockLoggingSystem:
        def set_current_exercise(self, ex_num, step): pass
        def complete_step(self, ex_num, step): pass
        def complete_exercise(self, ex_num): pass
        def log_student_response(self, ex_num, step, question, response): 
            print(f"Logged: {response}")
    
    mock_logger = MockLoggingSystem()
    exercise = Exercise11(mock_logger)
    
    # Test parameters
    test_params = {
        "sequence_length": 6,
        "d_model": 32,
        "num_heads": 2,
        "d_k": 16,
        "d_v": 16,
        "use_lora": "yes",
        "lora_rank": 4,
        "random_seed": 42
    }
    
    try:
        results = exercise.execute_exercise(test_params)
        print("✓ Exercise 11 test completed successfully!")
        return True
    except Exception as e:
        print(f"❌ Exercise 11 test failed: {e}")
        return False

if __name__ == "__main__":
    test_exercise_11()