# exercises/exercise_1.py
"""
Exercise 1: Scalars, Vectors, and Shapes
Introduction to basic linear algebra concepts with practical implementation
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any
import sys
import os

# Add parent directory to path to import exercise_base
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from exercise_base import ExerciseBase

class Exercise1(ExerciseBase):
    def __init__(self, logging_system):
        super().__init__(logging_system, 1, "Scalars, Vectors, and Shapes")
    
    def define_steps(self) -> list:
        return [
            "concept_explanation",
            "concept_check", 
            "parameters",
            "execution",
            "results"
        ]
    
    def get_concept_explanation(self) -> str:
        return """
🔢 SCALARS, VECTORS, AND SHAPES

KEY CONCEPTS:

1. SCALAR:
   - A scalar is a single number (e.g., 5, 3.14, -2)
   - Has magnitude but no direction
   - Examples: temperature, mass, speed

2. VECTOR:
   - An ordered list of scalars [a₁, a₂, ..., aₙ]
   - Has both magnitude and direction
   - Can be row vector: [1, 2, 3] or column vector: [[1], [2], [3]]

3. SHAPE:
   - Describes the dimensions of an array
   - Row vector shape: (1, n) - 1 row, n columns
   - Column vector shape: (n, 1) - n rows, 1 column
   - Vector shape: (n,) - one-dimensional array with n elements

4. APPLICATIONS IN DEEP LEARNING:
   - Word embeddings: Each word is represented as a vector
   - Hidden states: Neural network layers use vector representations
   - Attention mechanisms: Operate on vectors of different dimensions

NUMPY OPERATIONS:
- np.array([1, 2, 3]) creates a vector
- .shape gives dimensions
- .T transposes (row ↔ column)
- .dtype shows data type
        """
    
    def get_concept_question(self) -> str:
        return """
What is the difference between a scalar and a vector, and why are shapes important 
when working with neural networks? Give an example of each.
        """
    
    def get_required_parameters(self) -> Dict[str, str]:
        return {
            "vector1_size": "Enter size for first vector (e.g., 5)",
            "vector2_size": "Enter size for second vector (e.g., 3)", 
            "scalar_value": "Enter a scalar value for demonstration (e.g., 2.5)"
        }
    
    def execute_exercise(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the scalars, vectors, and shapes exercise"""
        
        # Extract parameters
        size1 = int(params["vector1_size"])
        size2 = int(params["vector2_size"])
        scalar = float(params["scalar_value"])
        
        # Create vectors
        vector1 = np.random.randint(1, 10, size=size1)
        vector2 = np.random.randint(1, 10, size=size2)
        
        # Create different vector shapes
        row_vector = vector1.reshape(1, -1)  # Row vector
        column_vector = vector1.reshape(-1, 1)  # Column vector
        
        # Calculate properties
        properties = {
            "Vector 1": {
                "values": vector1,
                "shape": vector1.shape,
                "dtype": str(vector1.dtype),
                "sum": np.sum(vector1),
                "mean": np.mean(vector1),
                "length": len(vector1)
            },
            "Vector 2": {
                "values": vector2, 
                "shape": vector2.shape,
                "dtype": str(vector2.dtype),
                "sum": np.sum(vector2),
                "mean": np.mean(vector2),
                "length": len(vector2)
            },
            "Row Vector": {
                "values": row_vector,
                "shape": row_vector.shape,
                "description": "1 row, multiple columns"
            },
            "Column Vector": {
                "values": column_vector,
                "shape": column_vector.shape,
                "description": "Multiple rows, 1 column"
            }
        }
        
        # Display properties table
        self.print_table(properties, "Vector Properties")
        
        # Create visualizations
        self.create_visualizations(vector1, vector2, scalar, properties)
        
        # Demonstrate shape transformations
        print(f"\n🔄 SHAPE TRANSFORMATIONS:")
        print(f"Original vector shape: {vector1.shape}")
        print(f"Row vector shape: {row_vector.shape}")
        print(f"Column vector shape: {column_vector.shape}")
        print(f"Transpose of row vector: {row_vector.T.shape}")
        
        # Connection to deep learning
        self.explain_deep_learning_connection(vector1, scalar)
        
        results = {
            "vector1": vector1,
            "vector2": vector2,
            "scalar": scalar,
            "properties": properties,
            "row_vector": row_vector,
            "column_vector": column_vector
        }
        
        return results
    
    def create_visualizations(self, vector1, vector2, scalar, properties):
        """Create bar charts and visualizations"""
        
        # Create subplots
        fig, axes = plt.subplots(2, 2, figsize=(12, 8))
        fig.suptitle('Scalars, Vectors, and Shapes Visualization', fontsize=16)
        
        # Plot 1: Vector 1 bar chart
        axes[0, 0].bar(range(len(vector1)), vector1, color='blue', alpha=0.7)
        axes[0, 0].set_title(f'Vector 1 (Shape: {vector1.shape})')
        axes[0, 0].set_xlabel('Index')
        axes[0, 0].set_ylabel('Value')
        axes[0, 0].grid(True, alpha=0.3)
        
        # Plot 2: Vector 2 bar chart
        axes[0, 1].bar(range(len(vector2)), vector2, color='red', alpha=0.7)
        axes[0, 1].set_title(f'Vector 2 (Shape: {vector2.shape})')
        axes[0, 1].set_xlabel('Index')
        axes[0, 1].set_ylabel('Value')
        axes[0, 1].grid(True, alpha=0.3)
        
        # Plot 3: Shape comparison
        shapes_data = [len(vector1), len(vector2)]
        shape_labels = [f'Vector 1\n{vector1.shape}', f'Vector 2\n{vector2.shape}']
        axes[1, 0].bar(shape_labels, shapes_data, color=['blue', 'red'], alpha=0.7)
        axes[1, 0].set_title('Vector Dimensions Comparison')
        axes[1, 0].set_ylabel('Size')
        
        # Plot 4: Scalar demonstration
        scaled_vector = vector1 * scalar
        x_pos = range(len(vector1))
        axes[1, 1].bar([x - 0.2 for x in x_pos], vector1, width=0.4, 
                      label='Original', color='blue', alpha=0.7)
        axes[1, 1].bar([x + 0.2 for x in x_pos], scaled_vector, width=0.4, 
                      label=f'× {scalar}', color='orange', alpha=0.7)
        axes[1, 1].set_title(f'Scalar Multiplication by {scalar}')
        axes[1, 1].set_xlabel('Index')
        axes[1, 1].set_ylabel('Value')
        axes[1, 1].legend()
        axes[1, 1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.show()
        
        # Show shape transformation visualization
        self.visualize_shape_transformations(vector1)
    
    def visualize_shape_transformations(self, vector):
        """Visualize different vector shape representations"""
        
        fig, axes = plt.subplots(1, 3, figsize=(15, 4))
        fig.suptitle('Vector Shape Transformations', fontsize=16)
        
        # Original vector
        axes[0].bar(range(len(vector)), vector, color='blue', alpha=0.7)
        axes[0].set_title(f'Original Vector\nShape: {vector.shape}')
        axes[0].set_xlabel('Index')
        axes[0].set_ylabel('Value')
        
        # Row vector visualization
        row_vec = vector.reshape(1, -1)
        im1 = axes[1].imshow(row_vec, cmap='Blues', aspect='auto')
        axes[1].set_title(f'Row Vector\nShape: {row_vec.shape}')
        axes[1].set_xlabel('Column')
        axes[1].set_ylabel('Row')
        plt.colorbar(im1, ax=axes[1])
        
        # Column vector visualization  
        col_vec = vector.reshape(-1, 1)
        im2 = axes[2].imshow(col_vec, cmap='Blues', aspect='auto')
        axes[2].set_title(f'Column Vector\nShape: {col_vec.shape}')
        axes[2].set_xlabel('Column')
        axes[2].set_ylabel('Row')
        plt.colorbar(im2, ax=axes[2])
        
        plt.tight_layout()
        plt.show()
    
    def explain_deep_learning_connection(self, vector, scalar):
        """Explain the connection to deep learning concepts"""
        
        print(f"\n🧠 CONNECTION TO DEEP LEARNING:")
        print("=" * 50)
        
        # Word embedding example
        print(f"📝 WORD EMBEDDINGS:")
        print(f"   - Your vector {vector} could represent a word embedding")
        print(f"   - Shape {vector.shape} means this word has {len(vector)} features")
        print(f"   - Each dimension captures semantic properties")
        
        # Neural network layer example
        print(f"\n🔗 NEURAL NETWORK LAYERS:")
        print(f"   - Hidden layer output: vector of activations")
        print(f"   - Batch processing: multiple vectors stacked together")
        print(f"   - Shape consistency is crucial for matrix operations")
        
        # Attention mechanism example
        embedding_dim = len(vector)
        print(f"\n🎯 TRANSFORMER ATTENTION:")
        print(f"   - Query/Key/Value vectors each have dimension {embedding_dim}")
        print(f"   - Attention scores computed between vector pairs")
        print(f"   - Shape mismatches cause runtime errors!")
        
        # Demonstrate common mistake
        print(f"\n⚠️  COMMON SHAPE ERRORS:")
        try:
            wrong_shape = np.array([[1, 2], [3, 4]])  # 2x2 matrix
            # This would fail: vector + wrong_shape
            print(f"   - Cannot add vector {vector.shape} + matrix {wrong_shape.shape}")
            print(f"   - Broadcasting rules determine compatibility")
        except:
            pass
    
    def get_result_explanation_question(self, results: Dict[str, Any]) -> str:
        vector1 = results["vector1"]
        vector2 = results["vector2"]
        scalar = results["scalar"]
        
        return f"""
Looking at the results:
- Vector 1 has shape {vector1.shape} with values {vector1}
- Vector 2 has shape {vector2.shape} with values {vector2}
- Scalar multiplication by {scalar} changed the values

Questions:
1. Why do Vector 1 and Vector 2 have different shapes?
2. How does scalar multiplication affect the vector?
3. In what scenarios would you use row vs column vectors in neural networks?
4. What would happen if you tried to add Vector 1 and Vector 2 directly?
        """

# Test function for the exercise
def test_exercise_1():
    """Test function for Exercise 1"""
    print("Testing Exercise 1: Scalars, Vectors, and Shapes")
    
    # Mock logging system for testing
    class MockLoggingSystem:
        def set_current_exercise(self, ex_num, step): pass
        def complete_step(self, ex_num, step): pass
        def complete_exercise(self, ex_num): pass
        def log_student_response(self, ex_num, step, question, response): 
            print(f"Logged: {response}")
    
    mock_logger = MockLoggingSystem()
    exercise = Exercise1(mock_logger)
    
    # Test parameters
    test_params = {
        "vector1_size": 5,
        "vector2_size": 3,
        "scalar_value": 2.5
    }
    
    try:
        results = exercise.execute_exercise(test_params)
        print("✓ Exercise 1 test completed successfully!")
        return True
    except Exception as e:
        print(f"❌ Exercise 1 test failed: {e}")
        return False

if __name__ == "__main__":
    test_exercise_1()