# exercises/exercise_4.py
"""
Exercise 4: Orthogonality and Projection
Understanding orthogonal vectors, projections, and their applications
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any
import sys
import os

# Add parent directory to path to import exercise_base
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from exercise_base import ExerciseBase

class Exercise4(ExerciseBase):
    def __init__(self, logging_system):
        super().__init__(logging_system, 4, "Orthogonality and Projection")
    
    def define_steps(self) -> list:
        return [
            "concept_explanation",
            "concept_check", 
            "parameters",
            "execution",
            "results"
        ]
    
    def get_concept_explanation(self) -> str:
        return """
⟂ ORTHOGONALITY AND PROJECTION

KEY CONCEPTS:

1. ORTHOGONALITY:
   - Vectors u and v are orthogonal if ⟨u,v⟩ = 0
   - Geometric meaning: perpendicular (90° angle)
   - Orthogonal vectors are linearly independent
   - Important in basis construction and decomposition

2. ORTHOGONAL PROJECTION:
   - proj_u(x) = (⟨x,u⟩/⟨u,u⟩) × u = (⟨x,u⟩/||u||²) × u
   - Projects vector x onto direction of vector u
   - Result is closest point on line through u to point x
   - Minimizes distance between x and its projection

3. PROJECTION PROPERTIES:
   - Projection is linear transformation
   - proj_u(x) lies on line through u
   - x - proj_u(x) is orthogonal to u (residual)
   - ||proj_u(x)|| ≤ ||x|| (projection can only shrink)

4. RESIDUAL VECTOR:
   - residual = x - proj_u(x)
   - Orthogonal to u: ⟨residual, u⟩ = 0
   - Represents component of x perpendicular to u
   - Minimizes squared distance

5. APPLICATIONS:
   - Principal Component Analysis (PCA)
   - Least squares regression
   - Gram-Schmidt orthogonalization
   - QR decomposition
   - Dimensionality reduction
   - Error correction in signal processing

6. CONNECTION TO TRANSFORMERS:
   - Multi-head attention: different heads learn orthogonal patterns
   - Residual connections: preserve orthogonal components
   - Layer normalization: removes projection onto mean direction

NUMPY OPERATIONS:
- np.dot(x, u) / np.dot(u, u): projection coefficient
- projection = coeff * u: projection vector
- residual = x - projection: orthogonal component
        """
    
    def get_concept_question(self) -> str:
        return """
Explain what it means for two vectors to be orthogonal and describe the geometric 
interpretation of vector projection. How does orthogonal projection relate to 
dimensionality reduction techniques like PCA?
        """
    
    def get_required_parameters(self) -> Dict[str, str]:
        return {
            "vector_to_project": "Enter vector to project (comma-separated, e.g., 5,3,1)",
            "projection_direction": "Enter direction vector for projection (e.g., 1,1,0)",
            "dimension": "Enter dimension for random vector analysis (e.g., 3)",
            "num_random_vectors": "Enter number of random vectors to analyze (e.g., 20)"
        }
    
    def execute_exercise(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the orthogonality and projection exercise"""
        
        # Extract parameters
        vector_str = params["vector_to_project"].strip()
        direction_str = params["projection_direction"].strip()
        dim = int(params["dimension"])
        num_random = int(params["num_random_vectors"])
        
        # Parse input vectors
        x = np.array([float(val.strip()) for val in vector_str.split(',')])
        u = np.array([float(val.strip()) for val in direction_str.split(',')])
        
        # Ensure vectors have correct dimension
        if len(x) != dim:
            x = np.resize(x, dim)
        if len(u) != dim:
            u = np.resize(u, dim)
        
        # Perform detailed projection analysis
        projection_results = self.compute_projection(x, u)
        self.display_projection_analysis(projection_results)
        
        # Generate random vectors for statistical analysis
        np.random.seed(42)
        random_vectors = np.random.uniform(-5, 5, (num_random, dim))
        
        # Analyze projections of random vectors
        random_projections = []
        projection_lengths = []
        residual_lengths = []
        projection_ratios = []
        
        for i, vec in enumerate(random_vectors):
            proj_result = self.compute_projection(vec, u)
            random_projections.append(proj_result)
            projection_lengths.append(proj_result['projection_length'])
            residual_lengths.append(proj_result['residual_length'])
            projection_ratios.append(proj_result['projection_ratio'])
        
        # Statistical analysis
        self.display_statistical_analysis(projection_lengths, residual_lengths, projection_ratios)
        
        # Create visualizations
        if dim <= 3:
            self.create_projection_visualizations(projection_results, random_projections[:5], dim)
        else:
            self.create_statistical_visualizations(projection_lengths, residual_lengths, projection_ratios)
        
        # Demonstrate orthogonality properties
        self.demonstrate_orthogonality_properties(x, u, projection_results)
        
        # Generate orthogonal vectors
        orthogonal_vectors = self.generate_orthogonal_vectors(u, dim)
        self.demonstrate_orthogonal_basis(u, orthogonal_vectors)
        
        # Connection to PCA and dimensionality reduction
        self.explain_pca_connection(random_vectors, u)
        
        results = {
            'input_vector': x,
            'direction_vector': u,
            'projection_results': projection_results,
            'random_vectors': random_vectors,
            'random_projections': random_projections,
            'orthogonal_vectors': orthogonal_vectors,
            'statistics': {
                'projection_lengths': projection_lengths,
                'residual_lengths': residual_lengths,
                'projection_ratios': projection_ratios
            },
            'dimension': dim
        }
        
        return results
    
    def compute_projection(self, x, u):
        """Compute orthogonal projection of x onto u"""
        # Handle zero vector case
        if np.allclose(u, 0):
            return {
                'x': x,
                'u': u,
                'projection': np.zeros_like(x),
                'residual': x,
                'projection_coefficient': 0,
                'projection_length': 0,
                'residual_length': np.linalg.norm(x),
                'original_length': np.linalg.norm(x),
                'projection_ratio': 0,
                'is_orthogonal_verified': True
            }
        
        # Compute projection coefficient
        u_dot_u = np.dot(u, u)
        x_dot_u = np.dot(x, u)
        projection_coefficient = x_dot_u / u_dot_u
        
        # Compute projection
        projection = projection_coefficient * u
        
        # Compute residual
        residual = x - projection
        
        # Compute lengths
        projection_length = np.linalg.norm(projection)
        residual_length = np.linalg.norm(residual)
        original_length = np.linalg.norm(x)
        
        # Projection ratio (how much of x is in direction of u)
        projection_ratio = projection_length / original_length if original_length > 0 else 0
        
        # Verify orthogonality (residual should be orthogonal to u)
        orthogonality_check = np.dot(residual, u)
        is_orthogonal_verified = np.abs(orthogonality_check) < 1e-10
        
        return {
            'x': x,
            'u': u,
            'projection': projection,
            'residual': residual,
            'projection_coefficient': projection_coefficient,
            'projection_length': projection_length,
            'residual_length': residual_length,
            'original_length': original_length,
            'projection_ratio': projection_ratio,
            'orthogonality_check': orthogonality_check,
            'is_orthogonal_verified': is_orthogonal_verified
        }
    
    def display_projection_analysis(self, results):
        """Display detailed projection analysis"""
        print(f"\n📐 ORTHOGONAL PROJECTION ANALYSIS")
        print("=" * 60)
        
        print(f"INPUT VECTORS:")
        print(f"   x = {results['x']}")
        print(f"   u = {results['u']}")
        print()
        
        print(f"PROJECTION COMPUTATION:")
        print(f"   Coefficient: ⟨x,u⟩/⟨u,u⟩ = {results['projection_coefficient']:.6f}")
        print(f"   proj_u(x) = {results['projection']}")
        print(f"   residual = x - proj_u(x) = {results['residual']}")
        print()
        
        print(f"LENGTH ANALYSIS:")
        print(f"   ||x|| = {results['original_length']:.6f}")
        print(f"   ||proj_u(x)|| = {results['projection_length']:.6f}")
        print(f"   ||residual|| = {results['residual_length']:.6f}")
        print(f"   Projection ratio = ||proj_u(x)|| / ||x|| = {results['projection_ratio']:.6f}")
        print()
        
        print(f"ORTHOGONALITY VERIFICATION:")
        print(f"   ⟨residual, u⟩ = {results['orthogonality_check']:.10f}")
        print(f"   Is orthogonal? {results['is_orthogonal_verified']} (should be True)")
        print()
        
        print(f"PYTHAGOREAN THEOREM CHECK:")
        sum_of_squares = results['projection_length']**2 + results['residual_length']**2
        original_squared = results['original_length']**2
        print(f"   ||proj_u(x)||² + ||residual||² = {sum_of_squares:.10f}")
        print(f"   ||x||² = {original_squared:.10f}")
        print(f"   Difference: {abs(sum_of_squares - original_squared):.2e}")
        print(f"   Pythagorean theorem satisfied? {np.isclose(sum_of_squares, original_squared)}")
    
    def display_statistical_analysis(self, projection_lengths, residual_lengths, projection_ratios):
        """Display statistical analysis of random projections"""
        print(f"\n📊 STATISTICAL ANALYSIS ({len(projection_lengths)} random vectors)")
        print("=" * 60)
        
        print(f"PROJECTION LENGTH STATISTICS:")
        print(f"   Mean: {np.mean(projection_lengths):.4f}")
        print(f"   Std:  {np.std(projection_lengths):.4f}")
        print(f"   Min:  {np.min(projection_lengths):.4f}")
        print(f"   Max:  {np.max(projection_lengths):.4f}")
        print()
        
        print(f"RESIDUAL LENGTH STATISTICS:")
        print(f"   Mean: {np.mean(residual_lengths):.4f}")
        print(f"   Std:  {np.std(residual_lengths):.4f}")
        print(f"   Min:  {np.min(residual_lengths):.4f}")
        print(f"   Max:  {np.max(residual_lengths):.4f}")
        print()
        
        print(f"PROJECTION RATIO STATISTICS:")
        print(f"   Mean: {np.mean(projection_ratios):.4f}")
        print(f"   Std:  {np.std(projection_ratios):.4f}")
        print(f"   Min:  {np.min(projection_ratios):.4f}")
        print(f"   Max:  {np.max(projection_ratios):.4f}")
        
        # Count extreme cases
        high_projection_count = sum(1 for ratio in projection_ratios if ratio > 0.8)
        low_projection_count = sum(1 for ratio in projection_ratios if ratio < 0.2)
        
        print(f"   High projection (>80%): {high_projection_count} vectors")
        print(f"   Low projection (<20%): {low_projection_count} vectors")
    
    def create_projection_visualizations(self, main_result, sample_results, dim):
        """Create projection visualizations for 2D/3D cases"""
        if dim == 2:
            self.create_2d_projection_plot(main_result, sample_results)
        elif dim == 3:
            self.create_3d_projection_plot(main_result)
    
    def create_2d_projection_plot(self, main_result, sample_results):
        """Create 2D projection visualization"""
        fig, axes = plt.subplots(1, 2, figsize=(15, 6))
        
        # Main projection plot
        ax1 = axes[0]
        x = main_result['x']
        u = main_result['u']
        proj = main_result['projection']
        residual = main_result['residual']
        
        # Draw vectors
        ax1.arrow(0, 0, x[0], x[1], head_width=0.3, head_length=0.3, 
                 fc='blue', ec='blue', linewidth=2, label='x (original)')
        ax1.arrow(0, 0, u[0], u[1], head_width=0.2, head_length=0.2, 
                 fc='red', ec='red', linewidth=2, label='u (direction)')
        ax1.arrow(0, 0, proj[0], proj[1], head_width=0.2, head_length=0.2, 
                 fc='green', ec='green', linewidth=2, label='proj_u(x)')
        ax1.arrow(proj[0], proj[1], residual[0], residual[1], 
                 head_width=0.2, head_length=0.2, fc='orange', ec='orange', 
                 linewidth=2, label='residual')
        
        # Draw perpendicular line indicator
        if not np.allclose(residual, 0):
            # Draw small square to indicate right angle
            perp_size = 0.3
            perp_point = proj
            res_unit = residual / np.linalg.norm(residual) if np.linalg.norm(residual) > 0 else residual
            u_unit = u / np.linalg.norm(u) if np.linalg.norm(u) > 0 else u
            
            corner1 = perp_point + perp_size * res_unit
            corner2 = corner1 + perp_size * u_unit
            corner3 = perp_point + perp_size * u_unit
            
            square_x = [perp_point[0], corner1[0], corner2[0], corner3[0], perp_point[0]]
            square_y = [perp_point[1], corner1[1], corner2[1], corner3[1], perp_point[1]]
            ax1.plot(square_x, square_y, 'k-', alpha=0.5, linewidth=1)
        
        ax1.set_aspect('equal')
        ax1.grid(True, alpha=0.3)
        ax1.legend()
        ax1.set_title('Orthogonal Projection (Main Example)')
        ax1.set_xlabel('X')
        ax1.set_ylabel('Y')
        
        # Multiple projections plot
        ax2 = axes[1]
        
        # Draw direction vector
        ax2.arrow(0, 0, u[0], u[1], head_width=0.2, head_length=0.2, 
                 fc='red', ec='red', linewidth=3, alpha=0.8, label='u (direction)')
        
        colors = ['blue', 'green', 'purple', 'orange', 'brown']
        for i, result in enumerate(sample_results):
            if i < len(colors):
                color = colors[i]
                x_i = result['x']
                proj_i = result['projection']
                
                # Draw original vector
                ax2.arrow(0, 0, x_i[0], x_i[1], head_width=0.15, head_length=0.15,
                         fc=color, ec=color, alpha=0.7, linewidth=1.5)
                
                # Draw projection
                ax2.arrow(0, 0, proj_i[0], proj_i[1], head_width=0.1, head_length=0.1,
                         fc=color, ec=color, alpha=0.5, linewidth=1, linestyle='--')
                
                # Draw perpendicular line
                ax2.plot([proj_i[0], x_i[0]], [proj_i[1], x_i[1]], 
                        color=color, alpha=0.3, linewidth=1)
        
        ax2.set_aspect('equal')
        ax2.grid(True, alpha=0.3)
        ax2.legend()
        ax2.set_title('Multiple Vector Projections')
        ax2.set_xlabel('X')
        ax2.set_ylabel('Y')
        
        plt.tight_layout()
        plt.show()
    
    def create_3d_projection_plot(self, main_result):
        """Create 3D projection visualization"""
        fig = plt.figure(figsize=(12, 8))
        ax = fig.add_subplot(111, projection='3d')
        
        x = main_result['x']
        u = main_result['u']
        proj = main_result['projection']
        residual = main_result['residual']
        
        # Draw vectors
        ax.quiver(0, 0, 0, x[0], x[1], x[2], color='blue', arrow_length_ratio=0.1, 
                 linewidth=3, label='x (original)')
        ax.quiver(0, 0, 0, u[0], u[1], u[2], color='red', arrow_length_ratio=0.1, 
                 linewidth=3, label='u (direction)')
        ax.quiver(0, 0, 0, proj[0], proj[1], proj[2], color='green', arrow_length_ratio=0.1, 
                 linewidth=3, label='proj_u(x)')
        ax.quiver(proj[0], proj[1], proj[2], residual[0], residual[1], residual[2], 
                 color='orange', arrow_length_ratio=0.1, linewidth=3, label='residual')
        
        # Draw projection plane (span of u)
        t = np.linspace(-2, 2, 10)
        plane_points = np.outer(t, u)
        ax.plot(plane_points[:, 0], plane_points[:, 1], plane_points[:, 2], 
               'r--', alpha=0.5, linewidth=1)
        
        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        ax.legend()
        ax.set_title('3D Orthogonal Projection')
        
        plt.show()
    
    def create_statistical_visualizations(self, projection_lengths, residual_lengths, projection_ratios):
        """Create statistical visualizations for higher dimensions"""
        fig, axes = plt.subplots(2, 2, figsize=(12, 10))
        
        # Projection length histogram
        axes[0, 0].hist(projection_lengths, bins=15, alpha=0.7, edgecolor='black', color='green')
        axes[0, 0].set_title('Distribution of Projection Lengths')
        axes[0, 0].set_xlabel('||proj_u(x)||')
        axes[0, 0].set_ylabel('Frequency')
        axes[0, 0].grid(True, alpha=0.3)
        
        # Residual length histogram
        axes[0, 1].hist(residual_lengths, bins=15, alpha=0.7, edgecolor='black', color='orange')
        axes[0, 1].set_title('Distribution of Residual Lengths')
        axes[0, 1].set_xlabel('||residual||')
        axes[0, 1].set_ylabel('Frequency')
        axes[0, 1].grid(True, alpha=0.3)
        
        # Projection ratio histogram
        axes[1, 0].hist(projection_ratios, bins=15, alpha=0.7, edgecolor='black', color='purple')
        axes[1, 0].set_title('Distribution of Projection Ratios')
        axes[1, 0].set_xlabel('||proj_u(x)|| / ||x||')
        axes[1, 0].set_ylabel('Frequency')
        axes[1, 0].grid(True, alpha=0.3)
        
        # Scatter plot: projection vs residual lengths
        axes[1, 1].scatter(projection_lengths, residual_lengths, alpha=0.6)
        axes[1, 1].set_title('Projection vs Residual Lengths')
        axes[1, 1].set_xlabel('||proj_u(x)||')
        axes[1, 1].set_ylabel('||residual||')
        axes[1, 1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.show()
    
    def demonstrate_orthogonality_properties(self, x, u, projection_results):
        """Demonstrate key orthogonality properties"""
        print(f"\n🔍 ORTHOGONALITY PROPERTIES DEMONSTRATION")
        print("=" * 60)
        
        proj = projection_results['projection']
        residual = projection_results['residual']
        
        print(f"1. RESIDUAL ORTHOGONALITY:")
        orthogonal_check = np.dot(residual, u)
        print(f"   ⟨residual, u⟩ = {orthogonal_check:.2e} (should be ≈ 0)")
        print(f"   Orthogonal? {np.abs(orthogonal_check) < 1e-10}")
        
        print(f"\n2. PYTHAGOREAN THEOREM:")
        print(f"   ||x||² = {np.linalg.norm(x)**2:.6f}")
        print(f"   ||proj||² + ||residual||² = {np.linalg.norm(proj)**2 + np.linalg.norm(residual)**2:.6f}")
        print(f"   Theorem satisfied? {np.isclose(np.linalg.norm(x)**2, np.linalg.norm(proj)**2 + np.linalg.norm(residual)**2)}")
        
        print(f"\n3. PROJECTION PROPERTIES:")
        print(f"   proj_u(proj_u(x)) = proj_u(x)? (idempotent)")
        double_proj = self.compute_projection(proj, u)['projection']
        print(f"   Result: {np.allclose(proj, double_proj)}")
        
        print(f"\n4. LINEARITY:")
        # Test proj_u(ax + by) = a*proj_u(x) + b*proj_u(y)
        y = np.random.randn(len(x))
        a, b = 2.5, -1.3
        
        combined = a * x + b * y
        proj_combined = self.compute_projection(combined, u)['projection']
        
        proj_x = projection_results['projection']
        proj_y = self.compute_projection(y, u)['projection']
        linear_combination = a * proj_x + b * proj_y
        
        print(f"   Testing: proj_u({a}x + {b}y) = {a}*proj_u(x) + {b}*proj_u(y)")
        print(f"   Equal? {np.allclose(proj_combined, linear_combination)}")
    
    def generate_orthogonal_vectors(self, u, dim):
        """Generate vectors orthogonal to u using Gram-Schmidt"""
        if np.allclose(u, 0):
            return []
        
        orthogonal_vectors = []
        
        # Start with random vectors and orthogonalize against u
        np.random.seed(123)
        for i in range(min(3, dim-1)):  # Generate up to 3 orthogonal vectors
            # Generate random vector
            v = np.random.randn(dim)
            
            # Make it orthogonal to u
            proj_v_onto_u = self.compute_projection(v, u)['projection']
            orthogonal_v = v - proj_v_onto_u
            
            # Normalize
            if not np.allclose(orthogonal_v, 0):
                orthogonal_v = orthogonal_v / np.linalg.norm(orthogonal_v)
                orthogonal_vectors.append(orthogonal_v)
        
        return orthogonal_vectors
    
    def demonstrate_orthogonal_basis(self, u, orthogonal_vectors):
        """Demonstrate orthogonal basis construction"""
        print(f"\n🎯 ORTHOGONAL BASIS CONSTRUCTION")
        print("=" * 50)
        
        if not orthogonal_vectors:
            print("No orthogonal vectors generated")
            return
        
        # Normalize u
        u_normalized = u / np.linalg.norm(u) if not np.allclose(u, 0) else u
        
        print(f"Starting direction: u = {u}")
        print(f"Normalized u: û = {u_normalized}")
        print()
        
        print(f"Generated orthogonal vectors:")
        all_vectors = [u_normalized] + orthogonal_vectors
        
        for i, vec in enumerate(orthogonal_vectors):
            print(f"   v{i+1} = {vec}")
            print(f"   ||v{i+1}|| = {np.linalg.norm(vec):.6f}")
            print(f"   ⟨û, v{i+1}⟩ = {np.dot(u_normalized, vec):.2e}")
            print()
        
        print(f"PAIRWISE ORTHOGONALITY CHECK:")
        for i in range(len(all_vectors)):
            for j in range(i+1, len(all_vectors)):
                dot_product = np.dot(all_vectors[i], all_vectors[j])
                print(f"   ⟨v{i}, v{j}⟩ = {dot_product:.2e}")
        
        # Test if vectors form orthogonal basis for their span
        if len(all_vectors) >= 2:
            print(f"\n📐 BASIS PROPERTIES:")
            print(f"   Number of orthogonal vectors: {len(all_vectors)}")
            print(f"   Can span {len(all_vectors)}-dimensional subspace")
    
    def explain_pca_connection(self, random_vectors, direction_vector):
        """Explain connection to PCA and dimensionality reduction"""
        print(f"\n🧮 CONNECTION TO PCA AND DIMENSIONALITY REDUCTION")
        print("=" * 60)
        
        print(f"🎯 PRINCIPAL COMPONENT ANALYSIS:")
        print(f"   - PCA finds directions of maximum variance")
        print(f"   - Each principal component is orthogonal to others")
        print(f"   - Projection onto PC1 captures most information")
        
        # Compute variance in direction of u
        projections = []
        for vec in random_vectors:
            proj_result = self.compute_projection(vec, direction_vector)
            projections.append(proj_result['projection_coefficient'])
        
        projection_variance = np.var(projections)
        
        print(f"\n📊 VARIANCE ANALYSIS:")
        print(f"   Direction vector: {direction_vector}")
        print(f"   Variance in this direction: {projection_variance:.4f}")
        print(f"   Standard deviation: {np.sqrt(projection_variance):.4f}")
        
        # Compare with original variance
        original_variances = np.var(random_vectors, axis=0)
        total_variance = np.sum(original_variances)
        explained_variance_ratio = projection_variance / total_variance
        
        print(f"   Total variance in data: {total_variance:.4f}")
        print(f"   Explained variance ratio: {explained_variance_ratio:.4f} ({explained_variance_ratio*100:.1f}%)")
        
        print(f"\n🔧 DIMENSIONALITY REDUCTION:")
        print(f"   - Project high-dimensional data onto lower-dimensional space")
        print(f"   - Preserve most important information (highest variance)")
        print(f"   - Reduce noise and computational complexity")
        print(f"   - Enable visualization of high-dimensional data")
        
        print(f"\n💡 APPLICATIONS:")
        print(f"   - Image compression: project onto principal components")
        print(f"   - Feature reduction: remove redundant dimensions")
        print(f"   - Noise reduction: project onto signal subspace")
        print(f"   - Data visualization: project to 2D/3D")
    
    def get_result_explanation_question(self, results: Dict[str, Any]) -> str:
        proj_results = results["projection_results"]
        stats = results["statistics"]
        
        return f"""
Analyzing the orthogonal projection results:

MAIN PROJECTION:
- Original vector: {proj_results['x']}
- Direction vector: {proj_results['u']}
- Projection: {proj_results['projection']}
- Residual: {proj_results['residual']}
- Projection ratio: {proj_results['projection_ratio']:.3f}

STATISTICAL SUMMARY:
- Average projection ratio: {np.mean(stats['projection_ratios']):.3f}
- Projection length range: [{np.min(stats['projection_lengths']):.2f}, {np.max(stats['projection_lengths']):.2f}]

QUESTIONS:
1. What does the projection ratio tell you about how much of the original vector 
   lies in the direction of the projection vector?

2. Why is the residual always orthogonal to the direction vector? What does this mean geometrically?

3. How does the Pythagorean theorem (||x||² = ||proj||² + ||residual||²) relate to 
   the decomposition of vectors?

4. In PCA, how would you choose the direction vector to maximize information retention?

5. How do these projections relate to:
   - Dimensionality reduction techniques?
   - Least squares regression?
   - The concept of "signal" vs "noise" in data?

6. If this were applied to word embeddings, what would projecting onto different 
   directions reveal about semantic relationships?
        """

# Test function for the exercise
def test_exercise_4():
    """Test function for Exercise 4"""
    print("Testing Exercise 4: Orthogonality and Projection")
    
    # Mock logging system for testing
    class MockLoggingSystem:
        def set_current_exercise(self, ex_num, step): pass
        def complete_step(self, ex_num, step): pass
        def complete_exercise(self, ex_num): pass
        def log_student_response(self, ex_num, step, question, response): 
            print(f"Logged: {response}")
    
    mock_logger = MockLoggingSystem()
    exercise = Exercise4(mock_logger)
    
    # Test parameters
    test_params = {
        "vector_to_project": "5,3,1",
        "projection_direction": "1,1,0",
        "dimension": 3,
        "num_random_vectors": 10
    }
    
    try:
        results = exercise.execute_exercise(test_params)
        print("✓ Exercise 4 test completed successfully!")
        return True
    except Exception as e:
        print(f"❌ Exercise 4 test failed: {e}")
        return False

if __name__ == "__main__":
    test_exercise_4()