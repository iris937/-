# exercises/exercise_5.py
"""
Exercise 5: Matrix Multiplication
Understanding matrix operations and linear transformations
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any
import sys
import os

# Add parent directory to path to import exercise_base
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from exercise_base import ExerciseBase

class Exercise5(ExerciseBase):
    def __init__(self, logging_system):
        super().__init__(logging_system, 5, "Matrix Multiplication")
    
    def define_steps(self) -> list:
        return [
            "concept_explanation",
            "concept_check", 
            "parameters",
            "execution",
            "results"
        ]
    
    def get_concept_explanation(self) -> str:
        return """
🔢 MATRIX MULTIPLICATION

KEY CONCEPTS:

1. MATRIX MULTIPLICATION DEFINITION:
   - (AB)ᵢⱼ = Σₖ AᵢₖBₖⱼ
   - Element (i,j) of AB = dot product of row i of A with column j of B
   - Only possible when: A is (m×n) and B is (n×p) → AB is (m×p)
   - Inner dimensions must match: A(m×n) × B(n×p) ✓

2. GEOMETRIC INTERPRETATION:
   - Matrix multiplication composes linear transformations
   - Each column of B is transformed by matrix A
   - Result shows how A transforms the column space of B

3. PROPERTIES:
   - Associative: (AB)C = A(BC)
   - Distributive: A(B+C) = AB + AC
   - NOT commutative: AB ≠ BA (in general)
   - Identity: AI = IA = A (when dimensions allow)

4. SPECIAL CASES:
   - Matrix-vector multiplication: Ax (transforms vector x)
   - Scalar multiplication: αA (scales all elements)
   - Square matrices: can be multiplied in both orders

5. COMPUTATIONAL COMPLEXITY:
   - Standard algorithm: O(mnp) for (m×n) × (n×p)
   - Optimizations: Strassen's algorithm, GPU parallelization
   - Memory access patterns matter for performance

6. APPLICATIONS IN DEEP LEARNING:
   - Linear layers: y = Wx + b
   - Attention mechanism: QK^T, then multiply by V
   - Weight matrices transform input representations
   - Batch processing: matrix ops on multiple samples
   - Backpropagation: involves many matrix multiplications

NUMPY OPERATIONS:
- np.dot(A, B) or A @ B: matrix multiplication
- A * B: element-wise multiplication (different!)
- np.linalg.matrix_power(A, n): A^n
        """
    
    def get_concept_question(self) -> str:
        return """
Explain why matrix multiplication is not commutative (AB ≠ BA) and what this means 
geometrically. How is matrix multiplication used in neural networks, particularly 
in transforming data through linear layers?
        """
    
    def get_required_parameters(self) -> Dict[str, str]:
        return {
            "matrix_A_rows": "Enter number of rows for matrix A (e.g., 3)",
            "matrix_A_cols": "Enter number of columns for matrix A (e.g., 4)",
            "matrix_B_cols": "Enter number of columns for matrix B (A_cols will be B_rows, e.g., 2)",
            "random_seed": "Enter random seed for reproducibility (e.g., 42)",
            "visualization_type": "Enter '2d' for 2D transformation visualization or 'general' for general analysis"
        }
    
    def execute_exercise(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the matrix multiplication exercise"""
        
        # Extract parameters
        m = int(params["matrix_A_rows"])  # A is m×n
        n = int(params["matrix_A_cols"])  # A is m×n, B is n×p
        p = int(params["matrix_B_cols"])  # B is n×p
        seed = int(params["random_seed"])
        viz_type = params["visualization_type"].lower().strip()
        
        np.random.seed(seed)
        
        # Generate matrices
        A = np.random.uniform(-3, 3, (m, n))
        B = np.random.uniform(-3, 3, (n, p))
        
        # Perform matrix multiplication
        AB = np.dot(A, B)  # Result is m×p
        
        # Display matrix information
        self.display_matrix_info(A, B, AB)
        
        # Demonstrate non-commutativity (if possible)
        commutativity_results = self.test_commutativity(A, B, m, n, p)
        
        # Analyze computational aspects
        self.analyze_computation(A, B, AB)
        
        # Visualize transformations
        if viz_type == '2d' and m == 2 and n == 2:
            transformation_results = self.visualize_2d_transformation(A)
        else:
            transformation_results = self.analyze_general_transformation(A, B)
        
        # Demonstrate properties
        properties_results = self.demonstrate_matrix_properties(A, B)
        
        # Connection to neural networks
        self.explain_neural_network_connection(A, B, AB)
        
        # Performance analysis
        performance_results = self.analyze_performance(m, n, p)
        
        results = {
            'matrix_A': A,
            'matrix_B': B,
            'matrix_AB': AB,
            'dimensions': {'m': m, 'n': n, 'p': p},
            'commutativity_results': commutativity_results,
            'transformation_results': transformation_results,
            'properties_results': properties_results,
            'performance_results': performance_results,
            'visualization_type': viz_type
        }
        
        return results
    
    def display_matrix_info(self, A, B, AB):
        """Display detailed matrix information"""
        print(f"\n📊 MATRIX MULTIPLICATION ANALYSIS")
        print("=" * 60)
        
        print(f"MATRIX DIMENSIONS:")
        print(f"   A: {A.shape[0]}×{A.shape[1]} = {A.shape}")
        print(f"   B: {B.shape[0]}×{B.shape[1]} = {B.shape}")
        print(f"   AB: {AB.shape[0]}×{AB.shape[1]} = {AB.shape}")
        print(f"   Compatibility: {A.shape[1]} = {B.shape[0]} ✓")
        print()
        
        print(f"MATRIX A:")
        if A.shape[0] <= 4 and A.shape[1] <= 4:
            print(A)
        else:
            print(f"   Shape: {A.shape}")
            print(f"   Sample elements: A[0,0]={A[0,0]:.3f}, A[0,-1]={A[0,-1]:.3f}")
        print()
        
        print(f"MATRIX B:")
        if B.shape[0] <= 4 and B.shape[1] <= 4:
            print(B)
        else:
            print(f"   Shape: {B.shape}")
            print(f"   Sample elements: B[0,0]={B[0,0]:.3f}, B[-1,0]={B[-1,0]:.3f}")
        print()
        
        print(f"RESULT AB:")
        if AB.shape[0] <= 4 and AB.shape[1] <= 4:
            print(AB)
        else:
            print(f"   Shape: {AB.shape}")
            print(f"   Sample elements: AB[0,0]={AB[0,0]:.3f}, AB[-1,-1]={AB[-1,-1]:.3f}")
        print()
        
        # Basic statistics
        print(f"MATRIX STATISTICS:")
        print(f"   A: mean={np.mean(A):.3f}, std={np.std(A):.3f}, ||A||_F={np.linalg.norm(A, 'fro'):.3f}")
        print(f"   B: mean={np.mean(B):.3f}, std={np.std(B):.3f}, ||B||_F={np.linalg.norm(B, 'fro'):.3f}")
        print(f"   AB: mean={np.mean(AB):.3f}, std={np.std(AB):.3f}, ||AB||_F={np.linalg.norm(AB, 'fro'):.3f}")
    
    def test_commutativity(self, A, B, m, n, p):
        """Test commutativity of matrix multiplication"""
        print(f"\n🔄 COMMUTATIVITY TEST")
        print("=" * 40)
        
        results = {}
        
        # Test if BA is possible
        can_multiply_BA = (p == m)
        
        if can_multiply_BA:
            BA = np.dot(B, A)  # p×n if possible
            results['BA'] = BA
            results['can_multiply_BA'] = True
            
            print(f"AB possible: {A.shape} × {B.shape} → {AB.shape}")
            print(f"BA possible: {B.shape} × {A.shape} → {BA.shape}")
            
            # Check if shapes are the same
            same_shape = AB.shape == BA.shape
            results['same_shape'] = same_shape
            
            if same_shape:
                # Check if matrices are equal
                are_equal = np.allclose(AB, BA)
                results['are_equal'] = are_equal
                
                print(f"Same output shape? {same_shape}")
                print(f"AB = BA? {are_equal}")
                
                if not are_equal:
                    difference_norm = np.linalg.norm(AB - BA, 'fro')
                    results['difference_norm'] = difference_norm
                    print(f"||AB - BA||_F = {difference_norm:.6f}")
                    
                    # Show a few differing elements
                    if AB.size <= 16:
                        print(f"AB - BA =")
                        print(AB - BA)
            else:
                print(f"Different output shapes: AB{AB.shape} vs BA{BA.shape}")
                results['are_equal'] = False
        else:
            print(f"AB possible: {A.shape} × {B.shape} → {(m, p)}")
            print(f"BA NOT possible: {B.shape} × {A.shape} (inner dimensions don't match)")
            results['can_multiply_BA'] = False
            results['same_shape'] = False
            results['are_equal'] = False
        
        return results
    
    def analyze_computation(self, A, B, AB):
        """Analyze computational aspects of matrix multiplication"""
        print(f"\n💻 COMPUTATIONAL ANALYSIS")
        print("=" * 50)
        
        m, n = A.shape
        n2, p = B.shape
        
        # Operation count
        multiplications = m * n * p
        additions = m * (n - 1) * p
        total_ops = multiplications + additions
        
        print(f"OPERATION COUNT:")
        print(f"   Scalar multiplications: {multiplications:,}")
        print(f"   Scalar additions: {additions:,}")
        print(f"   Total operations: {total_ops:,}")
        print(f"   Complexity: O({m} × {n} × {p}) = O({m*n*p})")
        
        # Memory usage
        memory_A = A.nbytes
        memory_B = B.nbytes
        memory_AB = AB.nbytes
        total_memory = memory_A + memory_B + memory_AB
        
        print(f"\nMEMORY USAGE:")
        print(f"   Matrix A: {memory_A:,} bytes")
        print(f"   Matrix B: {memory_B:,} bytes")
        print(f"   Result AB: {memory_AB:,} bytes")
        print(f"   Total: {total_memory:,} bytes ({total_memory/1024:.1f} KB)")
        
        # Verify computation by checking specific elements
        print(f"\nVERIFICATION (checking AB[0,0]):")
        if AB.size > 0:
            manual_calc = np.dot(A[0, :], B[:, 0])
            numpy_result = AB[0, 0]
            print(f"   Manual calculation: {manual_calc:.6f}")
            print(f"   NumPy result: {numpy_result:.6f}")
            print(f"   Match? {np.isclose(manual_calc, numpy_result)}")
    
    def visualize_2d_transformation(self, A):
        """Visualize 2D linear transformation"""
        print(f"\n🎨 2D LINEAR TRANSFORMATION VISUALIZATION")
        print("=" * 50)
        
        # Create a grid of points
        x = np.linspace(-2, 2, 10)
        y = np.linspace(-2, 2, 10)
        X, Y = np.meshgrid(x, y)
        
        # Original grid points
        original_points = np.column_stack([X.ravel(), Y.ravel()])
        
        # Transform points
        transformed_points = (A @ original_points.T).T
        
        # Create visualization
        fig, axes = plt.subplots(1, 2, figsize=(15, 6))
        
        # Original grid
        axes[0].scatter(original_points[:, 0], original_points[:, 1], 
                       alpha=0.6, s=30, c='blue')
        axes[0].grid(True, alpha=0.3)
        axes[0].set_aspect('equal')
        axes[0].set_title('Original Grid')
        axes[0].set_xlabel('X')
        axes[0].set_ylabel('Y')
        
        # Unit vectors
        origin = np.array([[0, 0], [0, 0]])
        e1 = np.array([[0, 1], [0, 0]])  # [x_start, x_end], [y_start, y_end]
        e2 = np.array([[0, 0], [0, 1]])
        
        axes[0].quiver(origin[0], origin[1], e1[1], e2[1], 
                      color=['red', 'green'], scale=1, scale_units='xy', 
                      angles='xy', width=0.005, label=['e₁', 'e₂'])
        
        # Transformed grid
        axes[1].scatter(transformed_points[:, 0], transformed_points[:, 1], 
                       alpha=0.6, s=30, c='red')
        axes[1].grid(True, alpha=0.3)
        axes[1].set_aspect('equal')
        axes[1].set_title(f'Transformed Grid (A × points)')
        axes[1].set_xlabel('X')
        axes[1].set_ylabel('Y')
        
        # Transformed unit vectors
        transformed_e1 = A @ np.array([1, 0])
        transformed_e2 = A @ np.array([0, 1])
        
        axes[1].quiver(0, 0, transformed_e1[0], transformed_e1[1], 
                      color='red', scale=1, scale_units='xy', angles='xy', 
                      width=0.005, label='Ae₁')
        axes[1].quiver(0, 0, transformed_e2[0], transformed_e2[1], 
                      color='green', scale=1, scale_units='xy', angles='xy', 
                      width=0.005, label='Ae₂')
        
        axes[0].legend()
        axes[1].legend()
        
        plt.tight_layout()
        plt.show()
        
        # Analyze transformation properties
        det_A = np.linalg.det(A)
        trace_A = np.trace(A)
        
        print(f"TRANSFORMATION PROPERTIES:")
        print(f"   Matrix A:")
        print(f"   {A}")
        print(f"   Determinant: {det_A:.4f}")
        print(f"   Trace: {trace_A:.4f}")
        print(f"   e₁ → {transformed_e1}")
        print(f"   e₂ → {transformed_e2}")
        
        if abs(det_A) < 1e-10:
            print(f"   ⚠️  Singular matrix (det ≈ 0): transformation collapses dimension")
        elif det_A < 0:
            print(f"   🔄 Orientation-reversing transformation")
        else:
            print(f"   ✓ Orientation-preserving transformation")
        
        return {
            'original_points': original_points,
            'transformed_points': transformed_points,
            'determinant': det_A,
            'trace': trace_A,
            'transformed_e1': transformed_e1,
            'transformed_e2': transformed_e2
        }
    
    def analyze_general_transformation(self, A, B):
        """Analyze transformation for general matrices"""
        print(f"\n🔍 GENERAL TRANSFORMATION ANALYSIS")
        print("=" * 50)
        
        print(f"MATRIX A (transformation):")
        print(f"   Shape: {A.shape}")
        print(f"   Rank: {np.linalg.matrix_rank(A)}")
        if A.shape[0] == A.shape[1]:  # Square matrix
            print(f"   Determinant: {np.linalg.det(A):.6f}")
            print(f"   Trace: {np.trace(A):.6f}")
        
        print(f"\nMATRIX B (input):")
        print(f"   Shape: {B.shape}")
        print(f"   Rank: {np.linalg.matrix_rank(B)}")
        
        # Analyze how A transforms B's columns
        print(f"\nCOLUMN TRANSFORMATION ANALYSIS:")
        for j in range(min(B.shape[1], 3)):  # Show first 3 columns
            b_j = B[:, j]
            Ab_j = A @ b_j
            
            print(f"   Column {j}: ||b_{j}|| = {np.linalg.norm(b_j):.3f} → ||Ab_{j}|| = {np.linalg.norm(Ab_j):.3f}")
            if np.linalg.norm(b_j) > 0:
                scale_factor = np.linalg.norm(Ab_j) / np.linalg.norm(b_j)
                print(f"              Scale factor: {scale_factor:.3f}")
        
        return {
            'A_rank': np.linalg.matrix_rank(A),
            'B_rank': np.linalg.matrix_rank(B),
            'AB_rank': np.linalg.matrix_rank(A @ B)
        }
    
    def demonstrate_matrix_properties(self, A, B):
        """Demonstrate key matrix multiplication properties"""
        print(f"\n🧮 MATRIX MULTIPLICATION PROPERTIES")
        print("=" * 50)
        
        results = {}
        
        # Create a third matrix C for associativity test
        if B.shape[1] >= 2:
            C = np.random.uniform(-2, 2, (B.shape[1], 2))
        else:
            C = np.random.uniform(-2, 2, (B.shape[1], 1))
        
        # Test associativity: (AB)C = A(BC)
        AB = A @ B
        BC = B @ C
        AB_C = AB @ C
        A_BC = A @ BC
        
        associative = np.allclose(AB_C, A_BC)
        results['associative'] = associative
        
        print(f"1. ASSOCIATIVITY: (AB)C = A(BC)")
        print(f"   Result: {associative}")
        if not associative:
            diff_norm = np.linalg.norm(AB_C - A_BC, 'fro')
            print(f"   Difference norm: {diff_norm:.2e}")
        
        # Test distributivity: A(B + B) = AB + AB
        B_plus_B = B + B
        A_sum = A @ B_plus_B
        sum_AB = (A @ B) + (A @ B)
        
        distributive = np.allclose(A_sum, sum_AB)
        results['distributive'] = distributive
        
        print(f"\n2. DISTRIBUTIVITY: A(B + B) = AB + AB")
        print(f"   Result: {distributive}")
        
        # Test with identity matrix (if A is square)
        if A.shape[0] == A.shape[1]:
            I = np.eye(A.shape[0])
            AI = A @ I
            IA = I @ A
            
            left_identity = np.allclose(AI, A)
            right_identity = np.allclose(IA, A)
            results['left_identity'] = left_identity
            results['right_identity'] = right_identity
            
            print(f"\n3. IDENTITY PROPERTY:")
            print(f"   AI = A: {left_identity}")
            print(f"   IA = A: {right_identity}")
        
        # Test scalar multiplication
        alpha = 2.5
        alpha_AB = alpha * (A @ B)
        alpha_A_B = (alpha * A) @ B
        A_alpha_B = A @ (alpha * B)
        
        scalar_left = np.allclose(alpha_AB, alpha_A_B)
        scalar_right = np.allclose(alpha_AB, A_alpha_B)
        results['scalar_left'] = scalar_left
        results['scalar_right'] = scalar_right
        
        print(f"\n4. SCALAR MULTIPLICATION:")
        print(f"   α(AB) = (αA)B: {scalar_left}")
        print(f"   α(AB) = A(αB): {scalar_right}")
        
        return results
    
    def explain_neural_network_connection(self, A, B, AB):
        """Explain connection to neural networks"""
        print(f"\n🧠 NEURAL NETWORK CONNECTION")
        print("=" * 50)
        
        print(f"🔗 LINEAR LAYERS:")
        print(f"   - Weight matrix W: shape {A.shape}")
        print(f"   - Input batch X: shape {B.shape}")
        print(f"   - Output Y = WX: shape {AB.shape}")
        print(f"   - Each column of X is one sample")
        print(f"   - Each column of Y is transformed sample")
        
        print(f"\n🎯 ATTENTION MECHANISM:")
        print(f"   - Query Q, Key K matrices: shapes like A, B")
        print(f"   - Attention scores: S = QK^T")
        print(f"   - After softmax: A = softmax(S)")
        print(f"   - Output: O = AV (another matrix multiplication)")
        
        print(f"\n📊 BATCH PROCESSING:")
        batch_size = B.shape[1] if len(B.shape) > 1 else 1
        print(f"   - Processing {batch_size} samples simultaneously")
        print(f"   - More efficient than processing one by one")
        print(f"   - Utilizes vectorized operations")
        
        print(f"\n💡 PRACTICAL EXAMPLES:")
        if A.shape == (3, 4) and B.shape == (4, 2):
            print(f"   - A could be: 3 output neurons, 4 input features")
            print(f"   - B could be: 4 features, 2 samples in batch")
            print(f"   - AB gives: 3 outputs for each of 2 samples")
        
        # Simulate a simple neural network layer
        if A.shape[1] == B.shape[0]:
            print(f"\n🔬 SIMULATION: Linear Layer")
            print(f"   Input features: {B.shape[0]}")
            print(f"   Output features: {A.shape[0]}")
            print(f"   Batch size: {B.shape[1] if len(B.shape) > 1 else 1}")
            
            # Add bias term simulation
            bias = np.random.uniform(-1, 1, A.shape[0])
            Y_with_bias = AB + bias.reshape(-1, 1)
            
            print(f"   With bias: Y = WX + b")
            print(f"   Bias shape: {bias.shape}")
            print(f"   Final output shape: {Y_with_bias.shape}")
    
    def analyze_performance(self, m, n, p):
        """Analyze performance characteristics"""
        print(f"\n⚡ PERFORMANCE ANALYSIS")
        print("=" * 40)
        
        # Operation count
        ops = m * n * p
        print(f"COMPUTATIONAL COMPLEXITY:")
        print(f"   Matrix sizes: ({m}×{n}) × ({n}×{p})")
        print(f"   Operations: {ops:,}")
        print(f"   Complexity: O(mnp) = O({m}·{n}·{p})")
        
        # Memory requirements
        memory_input = (m * n + n * p) * 8  # 8 bytes per float64
        memory_output = m * p * 8
        memory_total = memory_input + memory_output
        
        print(f"\nMEMORY REQUIREMENTS:")
        print(f"   Input matrices: {memory_input:,} bytes")
        print(f"   Output matrix: {memory_output:,} bytes")
        print(f"   Total: {memory_total:,} bytes ({memory_total/1024/1024:.2f} MB)")
        
        # Scalability analysis
        print(f"\nSCALABILITY:")
        scales = [2, 5, 10]
        for scale in scales:
            scaled_ops = (m * scale) * (n * scale) * (p * scale)
            ratio = scaled_ops / ops
            print(f"   {scale}× larger matrices: {ratio:.0f}× more operations")
        
        # Performance recommendations
        print(f"\nOPTIMIZATION OPPORTUNITIES:")
        if m > 1000 or n > 1000 or p > 1000:
            print(f"   - Consider block matrix multiplication")
            print(f"   - Use optimized BLAS libraries (MKL, OpenBLAS)")
            print(f"   - GPU acceleration for large matrices")
        
        if m == n == p:
            print(f"   - Square matrices: consider Strassen's algorithm for very large sizes")
        
        return {
            'operations': ops,
            'memory_bytes': memory_total,
            'memory_mb': memory_total / (1024 * 1024)
        }
    
    def get_result_explanation_question(self, results: Dict[str, Any]) -> str:
        A = results["matrix_A"]
        B = results["matrix_B"]
        AB = results["matrix_AB"]
        comm_results = results["commutativity_results"]
        
        return f"""
Analyzing the matrix multiplication results:

MATRICES:
- A: {A.shape} matrix
- B: {B.shape} matrix  
- AB: {AB.shape} matrix

COMMUTATIVITY TEST:
- Can compute BA? {comm_results.get('can_multiply_BA', 'N/A')}
- AB = BA? {comm_results.get('are_equal', 'N/A')}

QUESTIONS:

1. Why do the inner dimensions of the matrices need to match for multiplication?

2. Looking at the commutativity results, explain why AB ≠ BA in general. What does this 
   tell us about the order of operations in linear transformations?

3. How does matrix multiplication relate to:
   - Linear transformations in geometry?
   - Neural network forward passes?
   - Composition of functions?

4. If A represents a linear layer's weights and B represents a batch of input data, 
   what does AB represent? Why is this more efficient than processing samples individually?

5. In the context of Transformer attention:
   - What would Q×K^T compute?
   - Why do we need the scaling factor 1/√d?
   - How does the subsequent multiplication with V work?

6. What would happen to computational complexity if we doubled all matrix dimensions?
   How does this relate to the scalability challenges in training large neural networks?
        """

# Test function for the exercise
def test_exercise_5():
    """Test function for Exercise 5"""
    print("Testing Exercise 5: Matrix Multiplication")
    
    # Mock logging system for testing
    class MockLoggingSystem:
        def set_current_exercise(self, ex_num, step): pass
        def complete_step(self, ex_num, step): pass
        def complete_exercise(self, ex_num): pass
        def log_student_response(self, ex_num, step, question, response): 
            print(f"Logged: {response}")
    
    mock_logger = MockLoggingSystem()
    exercise = Exercise5(mock_logger)
    
    # Test parameters
    test_params = {
        "matrix_A_rows": 3,
        "matrix_A_cols": 4,
        "matrix_B_cols": 2,
        "random_seed": 42,
        "visualization_type": "general"
    }
    
    try:
        results = exercise.execute_exercise(test_params)
        print("✓ Exercise 5 test completed successfully!")
        return True
    except Exception as e:
        print(f"❌ Exercise 5 test failed: {e}")
        return False

if __name__ == "__main__":
    test_exercise_5()