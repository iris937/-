# exercises/exercise_8.py
"""
Exercise 8: Rank, Low-Rank Factorizations, LoRA
Understanding rank, matrix factorizations, and Low-Rank Adaptation techniques
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any, Tuple
import sys
import os

# Add parent directory to path to import exercise_base
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from exercise_base import ExerciseBase

class Exercise8(ExerciseBase):
    def __init__(self, logging_system):
        super().__init__(logging_system, 8, "Rank, Low-Rank Factorizations, LoRA")
    
    def define_steps(self) -> list:
        return [
            "concept_explanation",
            "concept_check", 
            "parameters",
            "execution",
            "results"
        ]
    
    def get_concept_explanation(self) -> str:
        return """
🎯 RANK, LOW-RANK FACTORIZATIONS, LoRA

KEY CONCEPTS:

1. MATRIX RANK:
   - Number of linearly independent columns (or rows)
   - rank(A) ≤ min(m, n) for A ∈ R^(m×n)
   - Full rank: rank(A) = min(m, n)
   - Rank deficient: rank(A) < min(m, n)

2. LOW-RANK FACTORIZATION:
   - A ≈ CR where C ∈ R^(m×k), R ∈ R^(k×n), k << min(m,n)
   - Reduces storage: mn → k(m+n) parameters
   - Captures dominant patterns in data
   - Foundation for dimensionality reduction

3. LOW-RANK ADAPTATION (LoRA):
   - Fine-tuning technique for large language models
   - W_new = W_pretrained + ΔW
   - ΔW = AB where A ∈ R^(d×r), B ∈ R^(r×d), r << d
   - Only train A and B, freeze W_pretrained
   - Dramatically reduces trainable parameters

4. APPLICATIONS:
   - Matrix completion: collaborative filtering
   - Data compression: image/signal processing
   - Neural network compression: reduce model size
   - Transfer learning: LoRA fine-tuning
   - Regularization: low-rank constraints

5. FACTORIZATION METHODS:
   - SVD: A = UΣV^T (optimal low-rank approximation)
   - QR decomposition: A = QR
   - LU decomposition: A = LU
   - Non-negative matrix factorization (NMF)

6. LoRA IN PRACTICE:
   - Fine-tune large models (GPT, BERT) efficiently
   - Adapter modules in Transformers
   - Task-specific adaptations
   - Multi-task learning with different LoRA modules

NUMPY OPERATIONS:
- np.linalg.matrix_rank(A): compute rank
- np.linalg.svd(A): singular value decomposition
- A[:, :k] @ A[:k, :]: rank-k approximation
        """
    
    def get_concept_question(self) -> str:
        return """
Explain how low-rank factorizations reduce computational and memory costs. 
How does LoRA (Low-Rank Adaptation) enable efficient fine-tuning of large 
language models, and what are the trade-offs between rank and model expressiveness?
        """
    
    def get_required_parameters(self) -> Dict[str, str]:
        return {
            "original_rows": "Enter number of rows for original matrix (e.g., 100)",
            "original_cols": "Enter number of columns for original matrix (e.g., 80)",
            "true_rank": "Enter true rank of matrix (e.g., 10)",
            "lora_ranks": "Enter LoRA ranks to test (comma-separated, e.g., 2,5,8)",
            "noise_level": "Enter noise level (0-1, e.g., 0.1)",
            "random_seed": "Enter random seed (e.g., 42)"
        }
    
    def execute_exercise(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the rank and LoRA exercise"""
        
        # Extract parameters
        m = int(params["original_rows"])
        n = int(params["original_cols"])
        true_rank = int(params["true_rank"])
        lora_ranks_str = params["lora_ranks"].strip()
        lora_ranks = [int(x.strip()) for x in lora_ranks_str.split(',')]
        noise_level = float(params["noise_level"])
        seed = int(params["random_seed"])
        
        np.random.seed(seed)
        
        # Create original low-rank matrix with noise
        original_matrix, ground_truth_factors = self.create_low_rank_matrix(m, n, true_rank, noise_level)
        
        # Analyze rank properties
        rank_analysis = self.analyze_rank_properties(original_matrix, true_rank)
        
        # Perform low-rank factorizations
        factorization_results = self.perform_factorizations(original_matrix, lora_ranks)
        
        # Simulate LoRA fine-tuning scenario
        lora_simulation = self.simulate_lora_fine_tuning(original_matrix, lora_ranks)
        
        # Compare approximation quality
        quality_analysis = self.analyze_approximation_quality(original_matrix, factorization_results)
        
        # Computational efficiency analysis
        efficiency_analysis = self.analyze_computational_efficiency(m, n, lora_ranks)
        
        # Create visualizations
        visualization_results = self.create_visualizations(original_matrix, factorization_results, quality_analysis)
        
        # Connection to modern deep learning
        self.explain_modern_applications(m, n, lora_ranks, efficiency_analysis)
        
        results = {
            'original_matrix': original_matrix,
            'ground_truth_factors': ground_truth_factors,
            'matrix_dimensions': (m, n),
            'true_rank': true_rank,
            'lora_ranks': lora_ranks,
            'rank_analysis': rank_analysis,
            'factorization_results': factorization_results,
            'lora_simulation': lora_simulation,
            'quality_analysis': quality_analysis,
            'efficiency_analysis': efficiency_analysis,
            'visualization_results': visualization_results
        }
        
        return results
    
    def create_low_rank_matrix(self, m, n, true_rank, noise_level):
        """Create a low-rank matrix with optional noise"""
        print(f"\n🏗️ CREATING LOW-RANK MATRIX")
        print("=" * 40)
        
        # Create ground truth low-rank factors
        C_true = np.random.randn(m, true_rank)
        R_true = np.random.randn(true_rank, n)
        
        # Create clean low-rank matrix
        A_clean = C_true @ R_true
        
        # Add noise
        noise = np.random.randn(m, n) * noise_level * np.std(A_clean)
        A_noisy = A_clean + noise
        
        print(f"Matrix dimensions: {m} × {n}")
        print(f"True rank: {true_rank}")
        print(f"Noise level: {noise_level}")
        print(f"Clean matrix ||A||_F: {np.linalg.norm(A_clean, 'fro'):.3f}")
        print(f"Noise ||N||_F: {np.linalg.norm(noise, 'fro'):.3f}")
        print(f"SNR: {np.linalg.norm(A_clean, 'fro') / np.linalg.norm(noise, 'fro'):.2f}")
        
        return A_noisy, {'C_true': C_true, 'R_true': R_true, 'A_clean': A_clean, 'noise': noise}
    
    def analyze_rank_properties(self, A, true_rank):
        """Analyze rank properties of the matrix"""
        print(f"\n📊 RANK ANALYSIS")
        print("=" * 30)
        
        # Compute SVD
        U, s, Vt = np.linalg.svd(A, full_matrices=False)
        
        # Estimate rank using different criteria
        estimated_ranks = {}
        
        # Hard threshold
        tolerance = 1e-10
        estimated_ranks['hard_threshold'] = np.sum(s > tolerance)
        
        # Relative threshold
        rel_threshold = 0.01 * s[0]  # 1% of largest singular value
        estimated_ranks['relative_threshold'] = np.sum(s > rel_threshold)
        
        # Energy threshold (95% of energy)
        cumulative_energy = np.cumsum(s**2) / np.sum(s**2)
        estimated_ranks['energy_95'] = np.sum(cumulative_energy < 0.95) + 1
        
        print(f"Singular values (first 10): {s[:10]}")
        print(f"True rank: {true_rank}")
        print(f"Estimated ranks:")
        for method, rank in estimated_ranks.items():
            print(f"   {method}: {rank}")
        
        # Plot singular values
        plt.figure(figsize=(10, 6))
        plt.semilogy(s, 'bo-', alpha=0.7)
        plt.axhline(y=rel_threshold, color='r', linestyle='--', label=f'1% threshold')
        plt.axvline(x=true_rank-0.5, color='g', linestyle='--', label=f'True rank: {true_rank}')
        plt.xlabel('Index')
        plt.ylabel('Singular Value (log scale)')
        plt.title('Singular Value Spectrum')
        plt.legend()
        plt.grid(True, alpha=0.3)
        plt.show()
        
        return {
            'singular_values': s,
            'estimated_ranks': estimated_ranks,
            'U': U,
            'Vt': Vt
        }
    
    def perform_factorizations(self, A, lora_ranks):
        """Perform low-rank factorizations for different ranks"""
        print(f"\n⚡ LOW-RANK FACTORIZATIONS")
        print("=" * 40)
        
        m, n = A.shape
        factorizations = {}
        
        # Get SVD once
        U, s, Vt = np.linalg.svd(A, full_matrices=False)
        
        for rank in lora_ranks:
            if rank > min(m, n):
                print(f"⚠️  Rank {rank} exceeds matrix dimensions, skipping")
                continue
                
            print(f"\nRank-{rank} factorization:")
            
            # SVD-based factorization
            U_k = U[:, :rank]
            s_k = s[:rank]
            Vt_k = Vt[:rank, :]
            
            # Low-rank approximation
            A_k = U_k @ np.diag(s_k) @ Vt_k
            
            # Create LoRA-style factorization: A ≈ AB
            # Distribute singular values
            sqrt_s = np.sqrt(s_k)
            A_factor = U_k @ np.diag(sqrt_s)  # m × rank
            B_factor = np.diag(sqrt_s) @ Vt_k  # rank × n
            
            # Compute approximation error
            error_frobenius = np.linalg.norm(A - A_k, 'fro')
            error_relative = error_frobenius / np.linalg.norm(A, 'fro')
            
            # Parameter count
            original_params = m * n
            factored_params = rank * (m + n)
            compression_ratio = factored_params / original_params
            
            print(f"   Approximation error (Frobenius): {error_frobenius:.4f}")
            print(f"   Relative error: {error_relative:.4f} ({error_relative*100:.2f}%)")
            print(f"   Parameters: {original_params:,} → {factored_params:,}")
            print(f"   Compression ratio: {compression_ratio:.4f}")
            print(f"   Space savings: {(1-compression_ratio)*100:.1f}%")
            
            factorizations[rank] = {
                'A_factor': A_factor,
                'B_factor': B_factor,
                'approximation': A_k,
                'error_frobenius': error_frobenius,
                'error_relative': error_relative,
                'original_params': original_params,
                'factored_params': factored_params,
                'compression_ratio': compression_ratio,
                'singular_values_used': s_k
            }
        
        return factorizations
    
    def simulate_lora_fine_tuning(self, W_pretrained, lora_ranks):
        """Simulate LoRA fine-tuning scenario"""
        print(f"\n🎯 LoRA FINE-TUNING SIMULATION")
        print("=" * 50)
        
        m, n = W_pretrained.shape
        lora_results = {}
        
        print(f"Pretrained weight matrix: {m} × {n}")
        print(f"Simulating task-specific adaptations...")
        
        for rank in lora_ranks:
            if rank > min(m, n):
                continue
                
            print(f"\n--- LoRA with rank {rank} ---")
            
            # Initialize LoRA matrices
            # A: m × rank, B: rank × n
            # ΔW = A @ B
            A_lora = np.random.randn(m, rank) * 0.1  # Small initialization
            B_lora = np.random.randn(rank, n) * 0.1
            
            # Simulate adaptation (random "task-specific" update)
            target_update = np.random.randn(m, n) * 0.05  # Small targeted change
            
            # Optimize A and B to approximate the target update
            # This would normally be done through gradient descent
            # Here we use least squares for demonstration
            
            # Flatten matrices for least squares
            target_flat = target_update.flatten()
            
            # Create design matrix for LoRA factorization
            # We need to solve: vec(AB) ≈ vec(target_update)
            # This is complex, so we'll use SVD approximation instead
            U_target, s_target, Vt_target = np.linalg.svd(target_update, full_matrices=False)
            
            # Take rank-k approximation of target
            if rank <= len(s_target):
                sqrt_s = np.sqrt(s_target[:rank])
                A_optimal = U_target[:, :rank] @ np.diag(sqrt_s)
                B_optimal = np.diag(sqrt_s) @ Vt_target[:rank, :]
                
                # Simulated adapted weight matrix
                W_adapted = W_pretrained + A_optimal @ B_optimal
                
                # Measure adaptation quality
                delta_W_actual = A_optimal @ B_optimal
                adaptation_error = np.linalg.norm(target_update - delta_W_actual, 'fro')
                adaptation_quality = 1 - (adaptation_error / np.linalg.norm(target_update, 'fro'))
                
                # Count trainable parameters
                lora_params = rank * (m + n)
                full_params = m * n
                param_efficiency = lora_params / full_params
                
                print(f"   LoRA parameters: {lora_params:,} / {full_params:,} ({param_efficiency*100:.2f}%)")
                print(f"   Adaptation quality: {adaptation_quality:.4f}")
                print(f"   Memory savings: {(1-param_efficiency)*100:.1f}%")
                
                lora_results[rank] = {
                    'A_lora': A_optimal,
                    'B_lora': B_optimal,
                    'W_adapted': W_adapted,
                    'delta_W': delta_W_actual,
                    'target_update': target_update,
                    'adaptation_error': adaptation_error,
                    'adaptation_quality': adaptation_quality,
                    'lora_params': lora_params,
                    'param_efficiency': param_efficiency
                }
        
        return lora_results
    
    def analyze_approximation_quality(self, original, factorizations):
        """Analyze quality of different rank approximations"""
        print(f"\n📈 APPROXIMATION QUALITY ANALYSIS")
        print("=" * 50)
        
        ranks = sorted(factorizations.keys())
        errors = [factorizations[r]['error_relative'] for r in ranks]
        compressions = [factorizations[r]['compression_ratio'] for r in ranks]
        
        print(f"Rank vs. Quality Trade-off:")
        print(f"{'Rank':<6} {'Rel. Error':<12} {'Compression':<12} {'Quality':<8}")
        print("-" * 40)
        
        for i, rank in enumerate(ranks):
            quality_score = 1 - errors[i]
            print(f"{rank:<6} {errors[i]:<12.4f} {compressions[i]:<12.4f} {quality_score:<8.4f}")
        
        # Find optimal rank (elbow method)
        if len(ranks) > 2:
            # Simple elbow detection: second derivative
            error_diffs = np.diff(errors)
            if len(error_diffs) > 1:
                error_diffs2 = np.diff(error_diffs)
                optimal_idx = np.argmax(error_diffs2) + 1
                optimal_rank = ranks[optimal_idx] if optimal_idx < len(ranks) else ranks[-1]
                print(f"\nSuggested optimal rank (elbow method): {optimal_rank}")
        
        # Plot trade-off curve
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # Error vs rank
        ax1.semilogy(ranks, errors, 'bo-', linewidth=2, markersize=8)
        ax1.set_xlabel('Rank')
        ax1.set_ylabel('Relative Error (log scale)')
        ax1.set_title('Approximation Error vs. Rank')
        ax1.grid(True, alpha=0.3)
        
        # Compression vs error
        ax2.loglog(compressions, errors, 'ro-', linewidth=2, markersize=8)
        for i, rank in enumerate(ranks):
            ax2.annotate(f'r={rank}', (compressions[i], errors[i]), 
                        xytext=(5, 5), textcoords='offset points')
        ax2.set_xlabel('Compression Ratio (log scale)')
        ax2.set_ylabel('Relative Error (log scale)')
        ax2.set_title('Error vs. Compression Trade-off')
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.show()
        
        return {
            'ranks': ranks,
            'errors': errors,
            'compressions': compressions,
            'optimal_rank': optimal_rank if len(ranks) > 2 else ranks[len(ranks)//2]
        }
    
    def analyze_computational_efficiency(self, m, n, lora_ranks):
        """Analyze computational efficiency of low-rank operations"""
        print(f"\n⚡ COMPUTATIONAL EFFICIENCY ANALYSIS")
        print("=" * 50)
        
        # Original matrix operations
        original_storage = m * n
        original_matvec_ops = m * n  # For matrix-vector multiplication
        original_matmat_ops = lambda k: m * n * k  # For matrix-matrix multiplication
        
        print(f"Original matrix ({m} × {n}):")
        print(f"   Storage: {original_storage:,} parameters")
        print(f"   Matrix-vector multiply: {original_matvec_ops:,} ops")
        print(f"   Matrix-matrix multiply (k=10): {original_matmat_ops(10):,} ops")
        
        print(f"\nLow-rank factorization efficiency:")
        print(f"{'Rank':<6} {'Storage':<12} {'Savings':<10} {'MatVec Ops':<12} {'Speedup':<8}")
        print("-" * 60)
        
        for rank in lora_ranks:
            if rank > min(m, n):
                continue
                
            # Storage for factored form
            factored_storage = rank * (m + n)
            storage_savings = 1 - (factored_storage / original_storage)
            
            # Operations for matrix-vector multiply: (A @ B) @ v = A @ (B @ v)
            factored_matvec_ops = rank * n + rank * m  # B@v + A@(B@v)
            matvec_speedup = original_matvec_ops / factored_matvec_ops
            
            print(f"{rank:<6} {factored_storage:<12,} {storage_savings:<10.2%} "
                  f"{factored_matvec_ops:<12,} {matvec_speedup:<8.2f}x")
        
        # Memory hierarchy considerations
        print(f"\n💾 MEMORY HIERARCHY BENEFITS:")
        print(f"   - Better cache locality for small factors")
        print(f"   - Reduced memory bandwidth requirements")
        print(f"   - GPU memory efficiency for large models")
        
        return {
            'original_storage': original_storage,
            'factored_storage': {r: r * (m + n) for r in lora_ranks if r <= min(m, n)},
            'storage_savings': {r: 1 - (r * (m + n) / original_storage) for r in lora_ranks if r <= min(m, n)},
            'speedup_matvec': {r: original_matvec_ops / (r * n + r * m) for r in lora_ranks if r <= min(m, n)}
        }
    
    def create_visualizations(self, original, factorizations, quality_analysis):
        """Create comprehensive visualizations"""
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        
        # Original matrix
        im1 = axes[0, 0].imshow(original, cmap='RdBu_r', aspect='auto')
        axes[0, 0].set_title('Original Matrix')
        plt.colorbar(im1, ax=axes[0, 0])
        
        # Best low-rank approximation
        best_rank = quality_analysis['optimal_rank']
        if best_rank in factorizations:
            best_approx = factorizations[best_rank]['approximation']
            im2 = axes[0, 1].imshow(best_approx, cmap='RdBu_r', aspect='auto')
            axes[0, 1].set_title(f'Rank-{best_rank} Approximation')
            plt.colorbar(im2, ax=axes[0, 1])
            
            # Error matrix
            error_matrix = original - best_approx
            im3 = axes[0, 2].imshow(error_matrix, cmap='RdBu_r', aspect='auto')
            axes[0, 2].set_title(f'Approximation Error')
            plt.colorbar(im3, ax=axes[0, 2])
        
        # Factor matrices for best rank
        if best_rank in factorizations:
            A_factor = factorizations[best_rank]['A_factor']
            B_factor = factorizations[best_rank]['B_factor']
            
            im4 = axes[1, 0].imshow(A_factor, cmap='RdBu_r', aspect='auto')
            axes[1, 0].set_title(f'Factor A ({A_factor.shape})')
            plt.colorbar(im4, ax=axes[1, 0])
            
            im5 = axes[1, 1].imshow(B_factor, cmap='RdBu_r', aspect='auto')
            axes[1, 1].set_title(f'Factor B ({B_factor.shape})')
            plt.colorbar(im5, ax=axes[1, 1])
        
        # Singular values comparison
        if best_rank in factorizations:
            all_svd = np.linalg.svd(original, compute_uv=False)
            used_svs = factorizations[best_rank]['singular_values_used']
            
            axes[1, 2].semilogy(all_svd, 'b-', alpha=0.7, label='All singular values')
            axes[1, 2].semilogy(range(len(used_svs)), used_svs, 'ro', 
                               markersize=8, label=f'Used (rank {best_rank})')
            axes[1, 2].set_xlabel('Index')
            axes[1, 2].set_ylabel('Singular Value (log scale)')
            axes[1, 2].set_title('Singular Value Selection')
            axes[1, 2].legend()
            axes[1, 2].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.show()
        
        return {'visualization_completed': True}
    
    def explain_modern_applications(self, m, n, lora_ranks, efficiency_analysis):
        """Explain modern applications in deep learning"""
        print(f"\n🚀 MODERN DEEP LEARNING APPLICATIONS")
        print("=" * 60)
        
        print(f"🎯 LoRA IN LARGE LANGUAGE MODELS:")
        print(f"   - GPT-3 has ~175B parameters")
        print(f"   - Full fine-tuning requires enormous compute")
        print(f"   - LoRA enables efficient task adaptation")
        
        # Simulate LLM scale
        gpt_scale_params = 175_000_000_000
        example_layer_size = 4096  # Typical transformer layer
        
        for rank in lora_ranks[:3]:  # Show first few ranks
            if rank <= min(m, n):
                # Scale up to LLM size
                layers_in_model = gpt_scale_params // (example_layer_size * example_layer_size)
                lora_params_per_layer = rank * (example_layer_size + example_layer_size)
                total_lora_params = lora_params_per_layer * layers_in_model
                
                efficiency = total_lora_params / gpt_scale_params
                
                print(f"   Rank-{rank} LoRA on LLM-scale:")
                print(f"     Trainable params: ~{total_lora_params/1_000_000:.1f}M vs {gpt_scale_params/1_000_000_000:.0f}B")
                print(f"     Efficiency: {efficiency:.4%} of original parameters")
        
        print(f"\n🔧 PRACTICAL BENEFITS:")
        print(f"   ✓ Faster training: fewer parameters to update")
        print(f"   ✓ Lower memory: don't need gradients for all weights")
        print(f"   ✓ Modular: swap LoRA modules for different tasks")
        print(f"   ✓ Storage: multiple task adaptations in small files")
        
        print(f"\n📊 COMPRESSION APPLICATIONS:")
        print(f"   - Model compression for mobile deployment")
        print(f"   - Federated learning: communicate low-rank updates")
        print(f"   - Neural architecture search: efficient exploration")
        
        print(f"\n🎨 CREATIVE APPLICATIONS:")
        print(f"   - Style transfer: low-rank artistic adaptations")
        print(f"   - Personalization: user-specific model variants")
        print(f"   - Multi-task learning: shared base + task LoRA")
        
        # Calculate real-world savings
        savings = efficiency_analysis['storage_savings']
        if lora_ranks:
            best_rank = min(rank for rank in lora_ranks if rank <= min(m, n))
            if best_rank in savings:
                print(f"\n💰 COST SAVINGS (rank {best_rank}):")
                print(f"   Storage: {savings[best_rank]:.1%} reduction")
                print(f"   Training time: ~{savings[best_rank]*0.8:.1%} reduction")
                print(f"   Memory usage: ~{savings[best_rank]*0.6:.1%} reduction")
    
    def get_result_explanation_question(self, results: Dict[str, Any]) -> str:
        true_rank = results["true_rank"]
        lora_ranks = results["lora_ranks"]
        quality_analysis = results["quality_analysis"]
        efficiency_analysis = results["efficiency_analysis"]
        
        # Get best performing rank
        best_rank = quality_analysis["optimal_rank"]
        best_error = None
        best_compression = None
        
        if best_rank in results["factorization_results"]:
            best_error = results["factorization_results"][best_rank]["error_relative"]
            best_compression = results["factorization_results"][best_rank]["compression_ratio"]
        
        return f"""
Analyzing the low-rank factorization and LoRA results:

ORIGINAL MATRIX:
- Dimensions: {results["matrix_dimensions"][0]} × {results["matrix_dimensions"][1]}
- True rank: {true_rank}

FACTORIZATION PERFORMANCE:
- Tested ranks: {lora_ranks}
- Optimal rank: {best_rank}
- Best relative error: {best_error:.3f if best_error else 'N/A'}
- Compression ratio: {best_compression:.3f if best_compression else 'N/A'}

QUESTIONS:

1. Rank vs. Quality Trade-off:
   - Why does approximation error decrease as rank increases?
   - At what point do diminishing returns set in?
   - How would you choose the optimal rank for a real application?

2. LoRA Efficiency:
   - How does parameter efficiency change with rank?
   - What are the practical implications for fine-tuning large models?
   - Why is LoRA particularly effective for Transformer architectures?

3. Computational Benefits:
   - How do matrix-vector multiplications become more efficient?
   - What are the memory hierarchy advantages of low-rank factorizations?
   - Why might low-rank be faster even if total operations increase?

4. Real-world Applications:
   - How would you apply LoRA to fine-tune a language model for a specific domain?
   - What rank would you choose for different types of adaptations?
   - How does this relate to transfer learning and few-shot learning?

5. Trade-offs and Limitations:
   - What information is lost in low-rank approximations?
   - When might full-rank updates be necessary?
   - How does the choice of rank affect model expressiveness?

6. Modern Deep Learning:
   - How does LoRA enable efficient multi-task learning?
   - What role does low-rank play in model compression?
   - How might this technique evolve for future architectures?
        """

# Test function for the exercise
def test_exercise_8():
    """Test function for Exercise 8"""
    print("Testing Exercise 8: Rank, Low-Rank Factorizations, LoRA")
    
    # Mock logging system for testing
    class MockLoggingSystem:
        def set_current_exercise(self, ex_num, step): pass
        def complete_step(self, ex_num, step): pass
        def complete_exercise(self, ex_num): pass
        def log_student_response(self, ex_num, step, question, response): 
            print(f"Logged: {response}")
    
    mock_logger = MockLoggingSystem()
    exercise = Exercise8(mock_logger)
    
    # Test parameters
    test_params = {
        "original_rows": 50,
        "original_cols": 40,
        "true_rank": 5,
        "lora_ranks": "2,3,5,8",
        "noise_level": 0.1,
        "random_seed": 42
    }
    
    try:
        results = exercise.execute_exercise(test_params)
        print("✓ Exercise 8 test completed successfully!")
        return True
    except Exception as e:
        print(f"❌ Exercise 8 test failed: {e}")
        return False

if __name__ == "__main__":
    test_exercise_8()