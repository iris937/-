# exercises/exercise_9.py
"""
Exercise 9: Singular Value Decomposition (SVD)
Understanding SVD and its applications in data analysis and machine learning
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any, Tuple
import sys
import os

# Add parent directory to path to import exercise_base
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from exercise_base import ExerciseBase

class Exercise9(ExerciseBase):
    def __init__(self, logging_system):
        super().__init__(logging_system, 9, "Singular Value Decomposition (SVD)")
    
    def define_steps(self) -> list:
        return [
            "concept_explanation",
            "concept_check", 
            "parameters",
            "execution",
            "results"
        ]
    
    def get_concept_explanation(self) -> str:
        return """
🔍 SINGULAR VALUE DECOMPOSITION (SVD)

KEY CONCEPTS:

1. SVD DECOMPOSITION:
   - Any matrix A ∈ R^(m×n) can be written as A = UΣV^T
   - U ∈ R^(m×m): left singular vectors (orthogonal)
   - Σ ∈ R^(m×n): diagonal matrix of singular values
   - V^T ∈ R^(n×n): right singular vectors (orthogonal)
   - σ₁ ≥ σ₂ ≥ ... ≥ σᵣ ≥ 0 (singular values in descending order)

2. GEOMETRIC INTERPRETATION:
   - Any linear transformation can be decomposed into:
     1. Rotation (V^T)
     2. Scaling along coordinate axes (Σ)
     3. Rotation (U)
   - Reveals the "natural axes" of the transformation

3. MATHEMATICAL PROPERTIES:
   - rank(A) = number of non-zero singular values
   - ||A||₂ = σ₁ (largest singular value)
   - ||A||_F = √(σ₁² + σ₂² + ... + σᵣ²)
   - Condition number: κ(A) = σ₁/σᵣ

4. LOW-RANK APPROXIMATION:
   - Best rank-k approximation: A_k = Σᵢ₌₁ᵏ σᵢ uᵢ vᵢ^T
   - Minimizes Frobenius norm: ||A - A_k||_F
   - Eckart-Young theorem: SVD gives optimal approximation

5. APPLICATIONS:
   - Principal Component Analysis (PCA)
   - Image compression and denoising
   - Collaborative filtering (recommender systems)
   - Data visualization and dimensionality reduction
   - Pseudoinverse computation: A⁺ = VΣ⁺U^T
   - Noise reduction and signal processing

6. CONNECTION TO TRANSFORMERS:
   - Attention weight analysis
   - Model compression and pruning
   - Understanding representational capacity
   - Gradient analysis and optimization landscapes

NUMPY OPERATIONS:
- U, s, Vt = np.linalg.svd(A): full SVD
- A_k = U[:,:k] @ np.diag(s[:k]) @ Vt[:k,:]: rank-k approximation
- np.linalg.pinv(A): pseudoinverse using SVD
        """
    
    def get_concept_question(self) -> str:
        return """
Explain how SVD decomposes any matrix into rotations and scaling operations. 
How does the rank-k approximation property make SVD useful for data compression 
and noise reduction? Give examples of SVD applications in machine learning.
        """
    
    def get_required_parameters(self) -> Dict[str, str]:
        return {
            "data_type": "Enter data type ('image', 'random', or 'synthetic')",
            "matrix_rows": "Enter number of rows (e.g., 100)",
            "matrix_cols": "Enter number of columns (e.g., 80)", 
            "noise_level": "Enter noise level for synthetic data (0-1, e.g., 0.2)",
            "compression_ranks": "Enter ranks for compression analysis (comma-separated, e.g., 5,10,20,50)",
            "random_seed": "Enter random seed (e.g., 42)"
        }
    
    def execute_exercise(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the SVD exercise"""
        
        # Extract parameters
        data_type = params["data_type"].lower().strip()
        m = int(params["matrix_rows"])
        n = int(params["matrix_cols"])
        noise_level = float(params["noise_level"])
        compression_ranks_str = params["compression_ranks"].strip()
        compression_ranks = [int(x.strip()) for x in compression_ranks_str.split(',')]
        seed = int(params["random_seed"])
        
        np.random.seed(seed)
        
        # Create or load data matrix
        data_matrix, data_info = self.create_data_matrix(data_type, m, n, noise_level)
        
        # Perform SVD analysis
        svd_results = self.perform_svd_analysis(data_matrix)
        
        # Analyze singular values
        singular_value_analysis = self.analyze_singular_values(svd_results)
        
        # Compression analysis
        compression_results = self.analyze_compression(data_matrix, svd_results, compression_ranks)
        
        # Noise reduction demonstration
        noise_reduction_results = self.demonstrate_noise_reduction(data_matrix, svd_results, data_info)
        
        # Principal Component Analysis connection
        pca_results = self.demonstrate_pca_connection(data_matrix, svd_results)
        
        # Create visualizations
        visualization_results = self.create_comprehensive_visualizations(
            data_matrix, svd_results, compression_results, data_type)
        
        # Applications in deep learning
        self.explain_deep_learning_applications(svd_results, compression_results)
        
        results = {
            'data_matrix': data_matrix,
            'data_info': data_info,
            'data_type': data_type,
            'svd_results': svd_results,
            'singular_value_analysis': singular_value_analysis,
            'compression_results': compression_results,
            'noise_reduction_results': noise_reduction_results,
            'pca_results': pca_results,
            'visualization_results': visualization_results,
            'compression_ranks': compression_ranks
        }
        
        return results
    
    def create_data_matrix(self, data_type, m, n, noise_level):
        """Create different types of data matrices for SVD analysis"""
        print(f"\n🎯 CREATING DATA MATRIX ({data_type.upper()})")
        print("=" * 50)
        
        if data_type == 'image':
            # Create a synthetic image-like matrix
            x = np.linspace(-2, 2, n)
            y = np.linspace(-2, 2, m)
            X, Y = np.meshgrid(x, y)
            
            # Combine different patterns
            pattern1 = np.exp(-(X**2 + Y**2))  # Gaussian
            pattern2 = np.sin(3*X) * np.cos(2*Y)  # Sinusoidal
            pattern3 = (X**2 - Y**2) * np.exp(-(X**2 + Y**2)/2)  # Quadratic
            
            # Combine patterns with different weights
            clean_image = 2*pattern1 + 0.5*pattern2 + 0.3*pattern3
            
            # Add noise
            noise = np.random.randn(m, n) * noise_level * np.std(clean_image)
            data_matrix = clean_image + noise
            
            data_info = {
                'type': 'synthetic_image',
                'clean_data': clean_image,
                'noise': noise,
                'snr': np.std(clean_image) / np.std(noise) if np.std(noise) > 0 else np.inf
            }
            
        elif data_type == 'synthetic':
            # Create structured synthetic data
            # Simulate data with known low-rank structure
            true_rank = min(5, min(m, n) // 2)
            
            # Create factor matrices
            U_true = np.random.randn(m, true_rank)
            V_true = np.random.randn(n, true_rank)
            
            # Make them more structured
            U_true[:, 0] = np.linspace(1, 0, m)  # Linear trend
            if true_rank > 1:
                U_true[:, 1] = np.sin(np.linspace(0, 2*np.pi, m))  # Sinusoidal
            if true_rank > 2:
                U_true[:, 2] = np.random.randn(m)  # Random component
            
            V_true[:, 0] = np.ones(n)  # Constant
            if true_rank > 1:
                V_true[:, 1] = np.linspace(-1, 1, n)  # Linear trend
            if true_rank > 2:
                V_true[:, 2] = np.cos(np.linspace(0, np.pi, n))  # Cosine
            
            # Create clean data
            clean_data = U_true @ V_true.T
            
            # Add noise
            noise = np.random.randn(m, n) * noise_level * np.std(clean_data)
            data_matrix = clean_data + noise
            
            data_info = {
                'type': 'synthetic_structured',
                'true_rank': true_rank,
                'U_true': U_true,
                'V_true': V_true,
                'clean_data': clean_data,
                'noise': noise,
                'snr': np.std(clean_data) / np.std(noise) if np.std(noise) > 0 else np.inf
            }
            
        else:  # random
            # Create random matrix
            data_matrix = np.random.randn(m, n)
            
            data_info = {
                'type': 'random',
                'expected_rank': min(m, n)
            }
        
        print(f"Matrix shape: {data_matrix.shape}")
        print(f"Data type: {data_info['type']}")
        if 'snr' in data_info:
            print(f"Signal-to-noise ratio: {data_info['snr']:.2f}")
        print(f"Matrix statistics: mean={np.mean(data_matrix):.3f}, std={np.std(data_matrix):.3f}")
        
        return data_matrix, data_info
    
    def perform_svd_analysis(self, A):
        """Perform comprehensive SVD analysis"""
        print(f"\n🔬 SVD ANALYSIS")
        print("=" * 30)
        
        m, n = A.shape
        
        # Compute full SVD
        U, s, Vt = np.linalg.svd(A, full_matrices=True)
        
        # Compute reduced SVD for efficiency
        k = min(m, n)
        U_reduced, s_reduced, Vt_reduced = np.linalg.svd(A, full_matrices=False)
        
        print(f"Matrix dimensions: {m} × {n}")
        print(f"Number of singular values: {len(s)}")
        print(f"Rank: {np.sum(s > 1e-10)}")
        
        print(f"\nSingular values (first 10):")
        for i, sigma in enumerate(s[:10]):
            print(f"   σ_{i+1} = {sigma:.6f}")
        
        # Matrix norms
        frobenius_norm = np.linalg.norm(A, 'fro')
        spectral_norm = s[0]  # Largest singular value
        nuclear_norm = np.sum(s)  # Sum of singular values
        
        print(f"\nMatrix norms:")
        print(f"   Frobenius norm: ||A||_F = {frobenius_norm:.6f}")
        print(f"   Spectral norm: ||A||_2 = {spectral_norm:.6f}")
        print(f"   Nuclear norm: ||A||_* = {nuclear_norm:.6f}")
        
        # Condition number
        if len(s) > 0 and s[-1] > 1e-15:
            condition_number = s[0] / s[-1]
            print(f"   Condition number: κ(A) = {condition_number:.2e}")
        else:
            condition_number = np.inf
            print(f"   Condition number: κ(A) = ∞ (singular matrix)")
        
        # Verify SVD reconstruction
        A_reconstructed = U_reduced @ np.diag(s_reduced) @ Vt_reduced
        reconstruction_error = np.linalg.norm(A - A_reconstructed, 'fro')
        print(f"\nSVD verification:")
        print(f"   Reconstruction error: {reconstruction_error:.2e}")
        
        return {
            'U': U,
            's': s,
            'Vt': Vt,
            'U_reduced': U_reduced,
            'Vt_reduced': Vt_reduced,
            'frobenius_norm': frobenius_norm,
            'spectral_norm': spectral_norm,
            'nuclear_norm': nuclear_norm,
            'condition_number': condition_number,
            'rank': np.sum(s > 1e-10)
        }
    
    def analyze_singular_values(self, svd_results):
        """Analyze the distribution and properties of singular values"""
        print(f"\n📊 SINGULAR VALUE ANALYSIS")
        print("=" * 40)
        
        s = svd_results['s']
        
        # Energy analysis
        energy = s**2
        total_energy = np.sum(energy)
        cumulative_energy = np.cumsum(energy) / total_energy
        
        print(f"Energy distribution:")
        for threshold in [0.5, 0.8, 0.9, 0.95, 0.99]:
            components_needed = np.sum(cumulative_energy < threshold) + 1
            print(f"   {threshold*100:4.0f}% energy: {components_needed:3d} components ({components_needed/len(s)*100:.1f}%)")
        
        # Decay analysis
        if len(s) > 1:
            # Fit exponential decay
            log_s = np.log(s[s > 1e-15])
            if len(log_s) > 2:
                decay_rate = (log_s[0] - log_s[-1]) / (len(log_s) - 1)
                print(f"\nSingular value decay:")
                print(f"   Average decay rate: {decay_rate:.4f} per component")
        
        # Effective rank estimation
        effective_ranks = {}
        
        # Hard threshold
        tolerance = 1e-10
        effective_ranks['hard_threshold'] = np.sum(s > tolerance)
        
        # Relative threshold
        rel_threshold = 0.01 * s[0]
        effective_ranks['relative_1pct'] = np.sum(s > rel_threshold)
        
        # Energy threshold
        effective_ranks['energy_90pct'] = np.sum(cumulative_energy < 0.9) + 1
        effective_ranks['energy_95pct'] = np.sum(cumulative_energy < 0.95) + 1
        
        print(f"\nEffective rank estimates:")
        for method, rank in effective_ranks.items():
            print(f"   {method}: {rank}")
        
        return {
            'energy': energy,
            'cumulative_energy': cumulative_energy,
            'effective_ranks': effective_ranks,
            'decay_analysis': {'log_s': log_s if 'log_s' in locals() else None}
        }
    
    def analyze_compression(self, A, svd_results, compression_ranks):
        """Analyze compression performance for different ranks"""
        print(f"\n📦 COMPRESSION ANALYSIS")
        print("=" * 40)
        
        m, n = A.shape
        U_reduced = svd_results['U_reduced']
        s = svd_results['s']
        Vt_reduced = svd_results['Vt_reduced']
        
        compression_results = {}
        
        print(f"Original matrix: {m} × {n} = {m*n:,} elements")
        print(f"\nCompression analysis:")
        print(f"{'Rank':<6} {'Error':<12} {'Compression':<12} {'Ratio':<8} {'Quality':<8}")
        print("-" * 50)
        
        for k in compression_ranks:
            if k > min(m, n):
                continue
                
            # Rank-k approximation
            A_k = U_reduced[:, :k] @ np.diag(s[:k]) @ Vt_reduced[:k, :]
            
            # Compression metrics
            error_frobenius = np.linalg.norm(A - A_k, 'fro')
            error_relative = error_frobenius / svd_results['frobenius_norm']
            
            # Storage requirements
            original_storage = m * n
            compressed_storage = k * (m + n + 1)  # U_k + s_k + Vt_k
            compression_ratio = compressed_storage / original_storage
            quality_score = 1 - error_relative
            
            print(f"{k:<6} {error_relative:<12.4f} {compression_ratio:<12.4f} "
                  f"{1/compression_ratio:<8.2f}x {quality_score:<8.4f}")
            
            compression_results[k] = {
                'approximation': A_k,
                'error_frobenius': error_frobenius,
                'error_relative': error_relative,
                'compression_ratio': compression_ratio,
                'quality_score': quality_score,
                'storage_original': original_storage,
                'storage_compressed': compressed_storage
            }
        
        # Find optimal compression rank (elbow method)
        if len(compression_results) > 2:
            ranks = sorted(compression_results.keys())
            errors = [compression_results[r]['error_relative'] for r in ranks]
            
            # Simple elbow detection
            if len(errors) > 2:
                error_diffs = np.diff(errors)
                if len(error_diffs) > 1:
                    error_diffs2 = np.diff(error_diffs)
                    optimal_idx = np.argmax(error_diffs2) + 1
                    optimal_rank = ranks[optimal_idx] if optimal_idx < len(ranks) else ranks[-1]
                    print(f"\nSuggested optimal rank (elbow method): {optimal_rank}")
        
        return compression_results
    
    def demonstrate_noise_reduction(self, A, svd_results, data_info):
        """Demonstrate noise reduction using SVD"""
        print(f"\n🔇 NOISE REDUCTION DEMONSTRATION")
        print("=" * 50)
        
        if 'clean_data' not in data_info:
            print("No clean data available for noise reduction analysis")
            return {'noise_reduction_performed': False}
        
        clean_data = data_info['clean_data']
        noise = data_info['noise']
        
        U_reduced = svd_results['U_reduced']
        s = svd_results['s']
        Vt_reduced = svd_results['Vt_reduced']
        
        print(f"Original SNR: {data_info['snr']:.2f}")
        
        # Try different numbers of components for denoising
        denoising_results = {}
        test_ranks = [1, 3, 5, 10, 20] if len(s) > 20 else list(range(1, min(len(s), 10) + 1))
        
        print(f"\nDenoising results:")
        print(f"{'Rank':<6} {'SNR_improved':<12} {'PSNR':<8} {'Noise_reduction':<15}")
        print("-" * 45)
        
        for k in test_ranks:
            if k > len(s):
                continue
                
            # Reconstruct with k components
            A_denoised = U_reduced[:, :k] @ np.diag(s[:k]) @ Vt_reduced[:k, :]
            
            # Compute metrics
            noise_residual = A_denoised - clean_data
            improved_snr = np.std(clean_data) / np.std(noise_residual) if np.std(noise_residual) > 0 else np.inf
            
            # Peak Signal-to-Noise Ratio (for image-like data)
            mse = np.mean((A_denoised - clean_data)**2)
            max_val = np.max(clean_data) - np.min(clean_data)
            psnr = 20 * np.log10(max_val / np.sqrt(mse)) if mse > 0 else np.inf
            
            # Noise reduction factor
            original_noise_power = np.var(noise)
            residual_noise_power = np.var(noise_residual)
            noise_reduction_db = 10 * np.log10(original_noise_power / residual_noise_power) if residual_noise_power > 0 else np.inf
            
            print(f"{k:<6} {improved_snr:<12.2f} {psnr:<8.1f} {noise_reduction_db:<15.1f} dB")
            
            denoising_results[k] = {
                'denoised': A_denoised,
                'improved_snr': improved_snr,
                'psnr': psnr,
                'noise_reduction_db': noise_reduction_db,
                'residual_noise': noise_residual
            }
        
        # Find best denoising rank
        if denoising_results:
            best_rank = max(denoising_results.keys(), 
                          key=lambda k: denoising_results[k]['improved_snr'])
            print(f"\nBest denoising rank: {best_rank} (SNR: {denoising_results[best_rank]['improved_snr']:.2f})")
        
        return denoising_results
    
    def demonstrate_pca_connection(self, A, svd_results):
        """Demonstrate connection between SVD and PCA"""
        print(f"\n🎯 PCA CONNECTION")
        print("=" * 30)
        
        # Center the data (subtract mean)
        A_centered = A - np.mean(A, axis=0)
        
        # Compute covariance matrix
        if A.shape[0] > 1:
            cov_matrix = (A_centered.T @ A_centered) / (A.shape[0] - 1)
        else:
            cov_matrix = A_centered.T @ A_centered
        
        # SVD of centered data
        U_pca, s_pca, Vt_pca = np.linalg.svd(A_centered, full_matrices=False)
        
        # Principal components are columns of V (rows of Vt)
        principal_components = Vt_pca.T
        
        # Explained variance
        explained_variance = s_pca**2 / (A.shape[0] - 1) if A.shape[0] > 1 else s_pca**2
        total_variance = np.sum(explained_variance)
        explained_variance_ratio = explained_variance / total_variance
        
        print(f"PCA Analysis:")
        print(f"   Total variance: {total_variance:.4f}")
        print(f"   Explained variance by first 5 components:")
        
        cumulative_variance = 0
        for i in range(min(5, len(explained_variance))):
            cumulative_variance += explained_variance_ratio[i]
            print(f"     PC{i+1}: {explained_variance_ratio[i]:.4f} ({explained_variance_ratio[i]*100:.1f}%), "
                  f"Cumulative: {cumulative_variance:.4f} ({cumulative_variance*100:.1f}%)")
        
        # Project data onto principal components
        projected_data = A_centered @ principal_components
        
        print(f"\nDimensionality reduction potential:")
        for threshold in [0.8, 0.9, 0.95, 0.99]:
            components_needed = np.sum(np.cumsum(explained_variance_ratio) < threshold) + 1
            print(f"   {threshold*100:.0f}% variance: {components_needed} components "
                  f"({components_needed/A.shape[1]*100:.1f}% of features)")
        
        return {
            'A_centered': A_centered,
            'principal_components': principal_components,
            'explained_variance': explained_variance,
            'explained_variance_ratio': explained_variance_ratio,
            'projected_data': projected_data,
            'covariance_matrix': cov_matrix
        }
    
    def create_comprehensive_visualizations(self, A, svd_results, compression_results, data_type):
        """Create comprehensive visualizations of SVD analysis"""
        fig = plt.figure(figsize=(20, 15))
        
        # Original data
        plt.subplot(3, 4, 1)
        plt.imshow(A, cmap='viridis', aspect='auto')
        plt.title('Original Matrix')
        plt.colorbar()
        
        # Singular values
        plt.subplot(3, 4, 2)
        s = svd_results['s']
        plt.semilogy(s, 'bo-', alpha=0.7)
        plt.xlabel('Index')
        plt.ylabel('Singular Value (log scale)')
        plt.title('Singular Value Spectrum')
        plt.grid(True, alpha=0.3)
        
        # Cumulative energy
        plt.subplot(3, 4, 3)
        energy = s**2
        cumulative_energy = np.cumsum(energy) / np.sum(energy)
        plt.plot(cumulative_energy, 'ro-', alpha=0.7)
        plt.axhline(y=0.9, color='g', linestyle='--', alpha=0.7, label='90%')
        plt.axhline(y=0.95, color='orange', linestyle='--', alpha=0.7, label='95%')
        plt.xlabel('Number of Components')
        plt.ylabel('Cumulative Energy')
        plt.title('Energy Distribution')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Compression quality
        plt.subplot(3, 4, 4)
        if compression_results:
            ranks = sorted(compression_results.keys())
            errors = [compression_results[r]['error_relative'] for r in ranks]
            compressions = [compression_results[r]['compression_ratio'] for r in ranks]
            
            plt.semilogy(ranks, errors, 'go-', alpha=0.7)
            plt.xlabel('Rank')
            plt.ylabel('Relative Error (log scale)')
            plt.title('Compression vs. Quality')
            plt.grid(True, alpha=0.3)
        
        # Show some rank-k approximations
        if compression_results:
            ranks_to_show = sorted(compression_results.keys())[:4]
            for i, rank in enumerate(ranks_to_show):
                plt.subplot(3, 4, 5 + i)
                approx = compression_results[rank]['approximation']
                plt.imshow(approx, cmap='viridis', aspect='auto')
                error = compression_results[rank]['error_relative']
                plt.title(f'Rank-{rank} Approx\n(Error: {error:.3f})')
                plt.colorbar()
        
        # Singular vectors visualization
        U = svd_results['U_reduced']
        Vt = svd_results['Vt_reduced']
        
        # First few left singular vectors
        plt.subplot(3, 4, 9)
        if U.shape[1] >= 3:
            plt.plot(U[:, 0], label='u₁', linewidth=2)
            plt.plot(U[:, 1], label='u₂', linewidth=2)
            plt.plot(U[:, 2], label='u₃', linewidth=2)
        else:
            for i in range(U.shape[1]):
                plt.plot(U[:, i], label=f'u_{i+1}', linewidth=2)
        plt.xlabel('Index')
        plt.ylabel('Value')
        plt.title('Left Singular Vectors')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # First few right singular vectors
        plt.subplot(3, 4, 10)
        if Vt.shape[0] >= 3:
            plt.plot(Vt[0, :], label='v₁', linewidth=2)
            plt.plot(Vt[1, :], label='v₂', linewidth=2)
            plt.plot(Vt[2, :], label='v₃', linewidth=2)
        else:
            for i in range(Vt.shape[0]):
                plt.plot(Vt[i, :], label=f'v_{i+1}', linewidth=2)
        plt.xlabel('Index')
        plt.ylabel('Value')
        plt.title('Right Singular Vectors')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Compression ratio vs error trade-off
        plt.subplot(3, 4, 11)
        if compression_results:
            compressions = [compression_results[r]['compression_ratio'] for r in ranks]
            plt.loglog(compressions, errors, 'bo-', alpha=0.7)
            for i, rank in enumerate(ranks):
                plt.annotate(f'r={rank}', (compressions[i], errors[i]), 
                           xytext=(5, 5), textcoords='offset points')
            plt.xlabel('Compression Ratio (log scale)')
            plt.ylabel('Relative Error (log scale)')
            plt.title('Compression Trade-off')
            plt.grid(True, alpha=0.3)
        
        # Matrix reconstruction visualization
        plt.subplot(3, 4, 12)
        if compression_results:
            # Show best compromise rank
            best_rank = min(compression_results.keys(), 
                          key=lambda r: compression_results[r]['error_relative'] + 
                                       compression_results[r]['compression_ratio'])
            error_matrix = A - compression_results[best_rank]['approximation']
            plt.imshow(error_matrix, cmap='RdBu_r', aspect='auto')
            plt.title(f'Error Matrix (Rank-{best_rank})')
            plt.colorbar()
        
        plt.tight_layout()
        plt.show()
        
        return {'comprehensive_visualization_created': True}
    
    def explain_deep_learning_applications(self, svd_results, compression_results):
        """Explain SVD applications in deep learning"""
        print(f"\n🧠 DEEP LEARNING APPLICATIONS")
        print("=" * 50)
        
        rank = svd_results['rank']
        condition_number = svd_results['condition_number']
        
        print(f"🎯 MODEL COMPRESSION:")
        print(f"   - Replace weight matrices with low-rank factorizations")
        print(f"   - W ≈ UΣV^T where U, V have fewer columns")
        print(f"   - Reduce parameters while preserving performance")
        
        if compression_results:
            best_compression = min(compression_results.values(), 
                                 key=lambda x: x['compression_ratio'])
            print(f"   - Example: {best_compression['compression_ratio']:.2f} compression ratio")
            print(f"   - Error: {best_compression['error_relative']:.3f}")
        
        print(f"\n📊 ATTENTION ANALYSIS:")
        print(f"   - SVD of attention weight matrices")
        print(f"   - Understand which patterns are captured")
        print(f"   - Identify redundant attention heads")
        print(f"   - Current matrix rank: {rank}")
        
        print(f"\n🔍 REPRESENTATIONAL ANALYSIS:")
        print(f"   - SVD of activation matrices")
        print(f"   - Measure effective dimensionality")
        print(f"   - Detect feature redundancy")
        print(f"   - Condition number: {condition_number:.2e}")
        
        if condition_number > 1e12:
            print(f"   ⚠️  High condition number → numerical instability")
        elif condition_number > 1e6:
            print(f"   ⚠️  Moderate condition number → potential issues")
        else:
            print(f"   ✓ Good condition number → numerically stable")
        
        print(f"\n🎨 GENERATIVE MODELS:")
        print(f"   - Latent space analysis with SVD")
        print(f"   - Principal directions in generated data")
        print(f"   - Mode collapse detection")
        
        print(f"\n⚡ OPTIMIZATION INSIGHTS:")
        print(f"   - Gradient covariance analysis")
        print(f"   - Learning rate adaptation")
        print(f"   - Understanding loss landscapes")
        
        print(f"\n💡 PRACTICAL IMPLEMENTATIONS:")
        print(f"   - TensorFlow/PyTorch: torch.svd(), tf.linalg.svd()")
        print(f"   - Automatic mixed precision with SVD")
        print(f"   - Distributed SVD for large matrices")
    
    def get_result_explanation_question(self, results: Dict[str, Any]) -> str:
        svd_results = results["svd_results"]
        compression_results = results["compression_results"]
        singular_analysis = results["singular_value_analysis"]
        
        rank = svd_results["rank"]
        condition_number = svd_results["condition_number"]
        
        # Get best compression result
        best_rank = None
        best_error = None
        best_compression = None
        
        if compression_results:
            best_rank = min(compression_results.keys(), 
                          key=lambda r: compression_results[r]['error_relative'])
            best_error = compression_results[best_rank]['error_relative']
            best_compression = compression_results[best_rank]['compression_ratio']
        
        return f"""
Analyzing the SVD decomposition results:

MATRIX PROPERTIES:
- Dimensions: {results["data_matrix"].shape}
- Rank: {rank}
- Condition number: {condition_number:.2e}
- Data type: {results["data_type"]}

SINGULAR VALUE ANALYSIS:
- Energy concentration: {singular_analysis["effective_ranks"]["energy_95pct"]} components for 95% energy
- Effective rank (1% threshold): {singular_analysis["effective_ranks"]["relative_1pct"]}

COMPRESSION PERFORMANCE:
- Best rank tested: {best_rank if best_rank else 'N/A'}
- Relative error: {best_error:.4f if best_error else 'N/A'}
- Compression ratio: {best_compression:.4f if best_compression else 'N/A'}

QUESTIONS:

1. SVD Decomposition Understanding:
   - How do the singular values reveal the "importance" of different components?
   - What does the rapid decay of singular values tell us about the data structure?
   - Why is the rank-k approximation optimal in the Frobenius norm sense?

2. Compression Analysis:
   - How do you choose the optimal rank for compression?
   - What's the trade-off between compression ratio and reconstruction quality?
   - How does this relate to dimensionality reduction in machine learning?

3. Condition Number Implications:
   - What does the condition number {condition_number:.2e} tell us about numerical stability?
   - How would this affect solving linear systems involving this matrix?
   - What are the implications for gradient-based optimization?

4. Deep Learning Applications:
   - How could you use SVD to compress a neural network layer?
   - What would SVD of attention weights reveal about a Transformer model?
   - How might this help with model interpretability?

5. Data Structure Insights:
   - What does the singular value spectrum reveal about your data?
   - If this were a dataset, what would low-rank structure indicate?
   - How could you use this for feature selection or dimensionality reduction?

6. Practical Implementation:
   - When would you prefer SVD over other factorization methods?
   - How would you implement incremental SVD for streaming data?
   - What are the computational trade-offs of different SVD algorithms?
        """

# Test function for the exercise
def test_exercise_9():
    """Test function for Exercise 9"""
    print("Testing Exercise 9: Singular Value Decomposition (SVD)")
    
    # Mock logging system for testing
    class MockLoggingSystem:
        def set_current_exercise(self, ex_num, step): pass
        def complete_step(self, ex_num, step): pass
        def complete_exercise(self, ex_num): pass
        def log_student_response(self, ex_num, step, question, response): 
            print(f"Logged: {response}")
    
    mock_logger = MockLoggingSystem()
    exercise = Exercise9(mock_logger)
    
    # Test parameters
    test_params = {
        "data_type": "synthetic",
        "matrix_rows": 50,
        "matrix_cols": 40,
        "noise_level": 0.1,
        "compression_ranks": "3,5,10,15",
        "random_seed": 42
    }
    
    try:
        results = exercise.execute_exercise(test_params)
        print("✓ Exercise 9 test completed successfully!")
        return True
    except Exception as e:
        print(f"❌ Exercise 9 test failed: {e}")
        return False

if __name__ == "__main__":
    test_exercise_9()