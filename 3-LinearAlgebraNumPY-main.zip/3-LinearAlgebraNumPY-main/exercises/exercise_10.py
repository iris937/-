# exercises/exercise_10.py
"""
Exercise 10: Eigenvalues and Eigenvectors
Understanding eigendecomposition and its applications in linear algebra and ML
"""

import numpy as np
import matplotlib.pyplot as plt
from typing import Dict, Any, Tuple
import sys
import os

# Add parent directory to path to import exercise_base
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from exercise_base import ExerciseBase

class Exercise10(ExerciseBase):
    def __init__(self, logging_system):
        super().__init__(logging_system, 10, "Eigenvalues and Eigenvectors")
    
    def define_steps(self) -> list:
        return [
            "concept_explanation",
            "concept_check", 
            "parameters",
            "execution",
            "results"
        ]
    
    def get_concept_explanation(self) -> str:
        return """
🎭 EIGENVALUES AND EIGENVECTORS

KEY CONCEPTS:

1. EIGENVALUE EQUATION:
   - Av = λv where v ≠ 0
   - λ: eigenvalue (scalar)
   - v: eigenvector (direction that doesn't change under transformation)
   - Geometric interpretation: A stretches v by factor λ

2. CHARACTERISTIC EQUATION:
   - det(A - λI) = 0
   - Polynomial of degree n (for n×n matrix)
   - n eigenvalues (counting multiplicities)
   - May be complex even for real matrices

3. EIGENDECOMPOSITION:
   - A = PDP⁻¹ (if diagonalizable)
   - P: matrix of eigenvectors
   - D: diagonal matrix of eigenvalues
   - For symmetric matrices: A = QΛQ^T (orthogonal diagonalization)

4. PROPERTIES:
   - trace(A) = sum of eigenvalues
   - det(A) = product of eigenvalues
   - rank(A) = number of non-zero eigenvalues
   - Eigenvalues of A^k are λ^k

5. SPECIAL CASES:
   - Symmetric matrices: real eigenvalues, orthogonal eigenvectors
   - Positive definite: all eigenvalues > 0
   - Orthogonal matrices: |λ| = 1
   - Stochastic matrices: largest eigenvalue = 1

6. APPLICATIONS IN MACHINE LEARNING:
   - Principal Component Analysis (PCA)
   - Spectral clustering
   - PageRank algorithm
   - Markov chain analysis
   - Stability analysis of dynamical systems
   - Neural network weight initialization
   - Understanding gradient flow

NUMPY OPERATIONS:
- λ, v = np.linalg.eig(A): eigenvalues and eigenvectors
- λ = np.linalg.eigvals(A): eigenvalues only
- λ, v = np.linalg.eigh(A): for symmetric matrices (more stable)
        """
    
    def get_concept_question(self) -> str:
        return """
Explain what eigenvalues and eigenvectors represent geometrically. How do they 
help us understand the behavior of linear transformations? Give examples of 
eigenvalue applications in machine learning and optimization.
        """
    
    def get_required_parameters(self) -> Dict[str, str]:
        return {
            "matrix_type": "Enter matrix type ('symmetric', 'random', 'covariance', or 'transition')",
            "matrix_size": "Enter matrix size (e.g., 5)",
            "condition_number": "Enter desired condition number (e.g., 10, for random matrices)",
            "random_seed": "Enter random seed (e.g., 42)"
        }
    
    def execute_exercise(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the eigenvalues and eigenvectors exercise"""
        
        # Extract parameters
        matrix_type = params["matrix_type"].lower().strip()
        n = int(params["matrix_size"])
        condition_number = float(params["condition_number"])
        seed = int(params["random_seed"])
        
        np.random.seed(seed)
        
        # Create test matrix based on type
        test_matrix, matrix_info = self.create_test_matrix(matrix_type, n, condition_number)
        
        # Compute eigendecomposition
        eigen_results = self.compute_eigendecomposition(test_matrix, matrix_type)
        
        # Analyze eigenvalue properties
        eigenvalue_analysis = self.analyze_eigenvalue_properties(eigen_results, test_matrix)
        
        # Geometric interpretation
        geometric_results = self.analyze_geometric_interpretation(test_matrix, eigen_results)
        
        # Power iteration demonstration
        power_iteration_results = self.demonstrate_power_iteration(test_matrix)
        
        # Applications demonstration
        application_results = self.demonstrate_applications(test_matrix, eigen_results, matrix_type)
        
        # Visualizations
        if n <= 4:
            visualization_results = self.create_visualizations(test_matrix, eigen_results, geometric_results)
        else:
            visualization_results = self.create_large_matrix_visualizations(test_matrix, eigen_results)
        
        # Connection to machine learning
        self.explain_ml_connections(eigen_results, application_results)
        
        results = {
            'test_matrix': test_matrix,
            'matrix_info': matrix_info,
            'matrix_type': matrix_type,
            'eigen_results': eigen_results,
            'eigenvalue_analysis': eigenvalue_analysis,
            'geometric_results': geometric_results,
            'power_iteration_results': power_iteration_results,
            'application_results': application_results,
            'visualization_results': visualization_results
        }
        
        return results
    
    def create_test_matrix(self, matrix_type, n, condition_number):
        """Create different types of test matrices"""
        print(f"\n🏗️ CREATING {matrix_type.upper()} MATRIX")
        print("=" * 50)
        
        if matrix_type == 'symmetric':
            # Create symmetric matrix with controlled eigenvalues
            eigenvalues = np.linspace(1, condition_number, n)
            Q = np.random.randn(n, n)
            Q, _ = np.linalg.qr(Q)  # Orthogonal matrix
            A = Q @ np.diag(eigenvalues) @ Q.T
            
            matrix_info = {
                'type': 'symmetric',
                'known_eigenvalues': eigenvalues,
                'known_eigenvectors': Q
            }
            
        elif matrix_type == 'covariance':
            # Create covariance-like matrix (positive semi-definite)
            X = np.random.randn(n*3, n)  # More samples than features
            A = (X.T @ X) / (X.shape[0] - 1)
            
            matrix_info = {
                'type': 'covariance',
                'data_matrix': X,
                'note': 'positive_semi_definite'
            }
            
        elif matrix_type == 'transition':
            # Create stochastic transition matrix
            A = np.random.rand(n, n)
            A = A / A.sum(axis=1, keepdims=True)  # Row stochastic
            
            matrix_info = {
                'type': 'transition',
                'note': 'stochastic_matrix',
                'largest_eigenvalue_should_be_1': True
            }
            
        else:  # random
            # Create random matrix with controlled condition number
            U, _ = np.linalg.qr(np.random.randn(n, n))
            V, _ = np.linalg.qr(np.random.randn(n, n))
            eigenvalues = np.linspace(1, condition_number, n)
            A = U @ np.diag(eigenvalues) @ V.T
            
            matrix_info = {
                'type': 'random',
                'target_condition_number': condition_number
            }
        
        print(f"Matrix shape: {A.shape}")
        print(f"Matrix type: {matrix_info['type']}")
        if A.shape[0] <= 5:
            print(f"Matrix A:")
            print(A)
        else:
            print(f"Matrix statistics: mean={np.mean(A):.3f}, std={np.std(A):.3f}")
        
        return A, matrix_info
    
    def compute_eigendecomposition(self, A, matrix_type):
        """Compute eigenvalues and eigenvectors"""
        print(f"\n🔬 EIGENDECOMPOSITION ANALYSIS")
        print("=" * 40)
        
        n = A.shape[0]
        
        # Choose appropriate method based on matrix type
        if matrix_type in ['symmetric', 'covariance']:
            # Use more stable algorithm for symmetric matrices
            eigenvalues, eigenvectors = np.linalg.eigh(A)
            method = 'eigh (symmetric)'
        else:
            eigenvalues, eigenvectors = np.linalg.eig(A)
            method = 'eig (general)'
        
        print(f"Method used: {method}")
        print(f"Number of eigenvalues: {len(eigenvalues)}")
        
        # Sort eigenvalues in descending order
        idx = np.argsort(eigenvalues)[::-1]
        eigenvalues = eigenvalues[idx]
        eigenvectors = eigenvectors[:, idx]
        
        print(f"\nEigenvalues (sorted):")
        for i, λ in enumerate(eigenvalues):
            if np.isreal(λ):
                print(f"   λ_{i+1} = {λ.real:.6f}")
            else:
                print(f"   λ_{i+1} = {λ:.6f}")
        
        # Check if all eigenvalues are real
        all_real = np.all(np.isreal(eigenvalues))
        print(f"\nAll eigenvalues real: {all_real}")
        
        # Verify eigenvalue equation Av = λv
        print(f"\nVerification (Av = λv):")
        verification_errors = []
        for i in range(min(n, 3)):  # Check first few
            v = eigenvectors[:, i]
            λ = eigenvalues[i]
            Av = A @ v
            λv = λ * v
            error = np.linalg.norm(Av - λv)
            verification_errors.append(error)
            print(f"   ||Av_{i+1} - λ_{i+1}v_{i+1}|| = {error:.2e}")
        
        max_verification_error = max(verification_errors)
        print(f"   Maximum verification error: {max_verification_error:.2e}")
        
        return {
            'eigenvalues': eigenvalues,
            'eigenvectors': eigenvectors,
            'method': method,
            'all_real': all_real,
            'verification_errors': verification_errors,
            'max_verification_error': max_verification_error
        }
    
    def analyze_eigenvalue_properties(self, eigen_results, A):
        """Analyze properties of eigenvalues"""
        print(f"\n📊 EIGENVALUE PROPERTIES ANALYSIS")
        print("=" * 50)
        
        eigenvalues = eigen_results['eigenvalues']
        eigenvectors = eigen_results['eigenvectors']
        
        # Basic properties
        trace_A = np.trace(A)
        det_A = np.linalg.det(A)
        trace_eigenvals = np.sum(eigenvalues)
        det_eigenvals = np.prod(eigenvalues)
        
        print(f"Matrix properties:")
        print(f"   Trace(A) = {trace_A:.6f}")
        print(f"   Det(A) = {det_A:.6f}")
        print(f"   Sum of eigenvalues = {trace_eigenvals:.6f}")
        print(f"   Product of eigenvalues = {det_eigenvals:.6f}")
        print(f"   Trace verification: {np.abs(trace_A - trace_eigenvals) < 1e-10}")
        print(f"   Determinant verification: {np.abs(det_A - det_eigenvals) < 1e-10}")
        
        # Spectral properties
        spectral_radius = np.max(np.abs(eigenvalues))
        condition_number = np.max(np.real(eigenvalues)) / np.min(np.real(eigenvalues)) if np.min(np.real(eigenvalues)) > 1e-15 else np.inf
        
        print(f"\nSpectral properties:")
        print(f"   Spectral radius: ρ(A) = {spectral_radius:.6f}")
        print(f"   Condition number: κ(A) = {condition_number:.2e}")
        
        # Classification
        eigenval_real = np.real(eigenvalues)
        if np.all(eigenval_real > 1e-10):
            definiteness = "Positive definite"
        elif np.all(eigenval_real >= -1e-10):
            definiteness = "Positive semi-definite"
        elif np.all(eigenval_real < -1e-10):
            definiteness = "Negative definite"
        elif np.all(eigenval_real <= 1e-10):
            definiteness = "Negative semi-definite"
        else:
            definiteness = "Indefinite"
        
        print(f"   Matrix definiteness: {definiteness}")
        
        # Eigenvalue distribution analysis
        if len(eigenvalues) > 1:
            eigenval_gaps = np.diff(np.sort(np.real(eigenvalues))[::-1])
            print(f"   Largest eigenvalue gap: {np.max(eigenval_gaps):.6f}")
            print(f"   Smallest eigenvalue gap: {np.min(eigenval_gaps):.6f}")
        
        # Orthogonality check for eigenvectors (if matrix is symmetric)
        if np.allclose(A, A.T):  # Symmetric matrix
            orthogonality_matrix = eigenvectors.T @ eigenvectors
            is_orthogonal = np.allclose(orthogonality_matrix, np.eye(len(eigenvalues)))
            print(f"\nEigenvector orthogonality:")
            print(f"   Eigenvectors orthogonal: {is_orthogonal}")
            if not is_orthogonal:
                off_diagonal_norm = np.linalg.norm(orthogonality_matrix - np.eye(len(eigenvalues)), 'fro')
                print(f"   Orthogonality error: {off_diagonal_norm:.2e}")
        
        return {
            'trace_A': trace_A,
            'det_A': det_A,
            'spectral_radius': spectral_radius,
            'condition_number': condition_number,
            'definiteness': definiteness,
            'eigenvalue_gaps': eigenval_gaps if len(eigenvalues) > 1 else None
        }
    
    def analyze_geometric_interpretation(self, A, eigen_results):
        """Analyze geometric interpretation of eigenvalues/eigenvectors"""
        print(f"\n🎨 GEOMETRIC INTERPRETATION")
        print("=" * 40)
        
        eigenvalues = eigen_results['eigenvalues']
        eigenvectors = eigen_results['eigenvectors']
        n = A.shape[0]
        
        print(f"Geometric analysis of transformation A:")
        
        # Analyze each eigenvalue/eigenvector pair
        for i in range(min(n, 3)):  # Show first few
            λ = eigenvalues[i]
            v = eigenvectors[:, i]
            
            print(f"\nEigenvalue λ_{i+1} = {λ:.4f}:")
            print(f"   Eigenvector v_{i+1} = {v}")
            
            # Geometric interpretation
            if np.isreal(λ):
                λ_real = λ.real
                if λ_real > 1:
                    interpretation = f"Stretching by factor {λ_real:.2f}"
                elif λ_real > 0:
                    interpretation = f"Shrinking by factor {λ_real:.2f}"
                elif λ_real == 0:
                    interpretation = "Collapse to zero (singularity)"
                else:
                    interpretation = f"Reflection + scaling by {abs(λ_real):.2f}"
            else:
                interpretation = f"Rotation + scaling (complex eigenvalue)"
            
            print(f"   Geometric effect: {interpretation}")
            
            # Test the eigenvalue equation
            Av = A @ v
            λv = λ * v
            
            if n <= 3:  # For small matrices, show the vectors
                print(f"   Av = {Av}")
                print(f"   λv = {λv}")
        
        # Analyze invariant subspaces
        if np.allclose(A, A.T):  # Symmetric matrix
            print(f"\nInvariant subspaces (symmetric matrix):")
            print(f"   Each eigenvector spans a 1D invariant subspace")
            print(f"   Orthogonal eigenvectors span orthogonal subspaces")
        
        # Dominant eigenvalue analysis
        if len(eigenvalues) > 1:
            λ1 = eigenvalues[0]
            λ2 = eigenvalues[1]
            dominance_ratio = abs(λ1) / abs(λ2) if abs(λ2) > 1e-15 else np.inf
            
            print(f"\nDominance analysis:")
            print(f"   Dominant eigenvalue: λ_1 = {λ1:.4f}")
            print(f"   Dominance ratio: |λ_1|/|λ_2| = {dominance_ratio:.2f}")
            
            if dominance_ratio > 10:
                print(f"   Strong dominance → rapid convergence in power iteration")
            elif dominance_ratio > 2:
                print(f"   Moderate dominance")
            else:
                print(f"   Weak dominance → slow convergence")
        
        return {
            'dominant_eigenvalue': eigenvalues[0],
            'dominance_ratio': dominance_ratio if len(eigenvalues) > 1 else 1,
            'geometric_interpretations': [f"λ_{i+1}: scaling by {eigenvalues[i]:.3f}" for i in range(min(n, 3))]
        }
    
    def demonstrate_power_iteration(self, A):
        """Demonstrate power iteration method"""
        print(f"\n⚡ POWER ITERATION DEMONSTRATION")
        print("=" * 50)
        
        n = A.shape[0]
        
        # Initialize random vector
        x = np.random.randn(n)
        x = x / np.linalg.norm(x)
        
        print(f"Finding dominant eigenvalue using power iteration...")
        
        eigenvalue_estimates = []
        convergence_errors = []
        
        # True dominant eigenvalue for comparison
        true_eigenvals = np.linalg.eigvals(A)
        true_dominant = true_eigenvals[np.argmax(np.abs(true_eigenvals))]
        
        for iteration in range(20):
            # Power iteration step
            y = A @ x
            
            # Rayleigh quotient (eigenvalue estimate)
            eigenval_estimate = (x.T @ y) / (x.T @ x)
            eigenvalue_estimates.append(eigenval_estimate)
            
            # Normalize for next iteration
            y_norm = np.linalg.norm(y)
            if y_norm > 1e-15:
                x = y / y_norm
            
            # Compute convergence error
            error = abs(eigenval_estimate - true_dominant)
            convergence_errors.append(error)
            
            if iteration < 10 or iteration % 5 == 0:
                print(f"   Iteration {iteration+1:2d}: λ ≈ {eigenval_estimate:.6f}, error = {error:.2e}")
        
        print(f"\nPower iteration results:")
        print(f"   True dominant eigenvalue: {true_dominant:.6f}")
        print(f"   Final estimate: {eigenvalue_estimates[-1]:.6f}")
        print(f"   Final error: {convergence_errors[-1]:.2e}")
        
        # Analyze convergence rate
        if len(convergence_errors) > 5:
            # Fit exponential decay to convergence
            log_errors = np.log(np.array(convergence_errors[5:]) + 1e-15)
            if len(log_errors) > 2:
                convergence_rate = np.polyfit(range(len(log_errors)), log_errors, 1)[0]
                print(f"   Convergence rate: {convergence_rate:.4f} (log scale)")
        
        return {
            'eigenvalue_estimates': eigenvalue_estimates,
            'convergence_errors': convergence_errors,
            'true_dominant': true_dominant,
            'final_estimate': eigenvalue_estimates[-1],
            'final_eigenvector': x
        }
    
    def demonstrate_applications(self, A, eigen_results, matrix_type):
        """Demonstrate applications of eigendecomposition"""
        print(f"\n🎯 EIGENDECOMPOSITION APPLICATIONS")
        print("=" * 50)
        
        eigenvalues = eigen_results['eigenvalues']
        eigenvectors = eigen_results['eigenvectors']
        
        applications = {}
        
        # 1. Matrix powers
        print(f"1. MATRIX POWERS:")
        if np.allclose(A, A.T) and np.all(np.isreal(eigenvalues)):
            # For symmetric matrices: A^k = Q Λ^k Q^T
            k = 5
            A_k_eigen = eigenvectors @ np.diag(eigenvalues**k) @ eigenvectors.T
            A_k_direct = np.linalg.matrix_power(A, k)
            
            power_error = np.linalg.norm(A_k_eigen - A_k_direct, 'fro')
            print(f"   A^{k} computed via eigendecomposition")
            print(f"   Error vs direct computation: {power_error:.2e}")
            
            applications['matrix_power'] = {
                'k': k,
                'A_k_eigen': A_k_eigen,
                'error': power_error
            }
        
        # 2. Matrix exponential (for stable matrices)
        print(f"\n2. MATRIX EXPONENTIAL:")
        if np.all(np.real(eigenvalues) < 10):  # Avoid overflow
            exp_eigenvalues = np.exp(eigenvalues)
            if np.allclose(A, A.T):
                exp_A = eigenvectors @ np.diag(exp_eigenvalues) @ eigenvectors.T
                print(f"   exp(A) computed via eigendecomposition")
                print(f"   Largest element: {np.max(np.abs(exp_A)):.3f}")
                
                applications['matrix_exponential'] = {
                    'exp_A': exp_A,
                    'exp_eigenvalues': exp_eigenvalues
                }
        
        # 3. Pseudoinverse (for singular matrices)
        print(f"\n3. PSEUDOINVERSE:")
        tolerance = 1e-10
        eigenvals_inv = np.where(np.abs(eigenvalues) > tolerance, 1/eigenvalues, 0)
        
        if np.allclose(A, A.T):
            A_pinv_eigen = eigenvectors @ np.diag(eigenvals_inv) @ eigenvectors.T
            A_pinv_numpy = np.linalg.pinv(A)
            
            pinv_error = np.linalg.norm(A_pinv_eigen - A_pinv_numpy, 'fro')
            print(f"   Pseudoinverse computed via eigendecomposition")
            print(f"   Error vs NumPy pinv: {pinv_error:.2e}")
            
            applications['pseudoinverse'] = {
                'A_pinv': A_pinv_eigen,
                'error': pinv_error
            }
        
        # 4. Condition number analysis
        print(f"\n4. CONDITION NUMBER ANALYSIS:")
        if np.all(np.real(eigenvalues) > 1e-15):
            cond_eigen = np.max(np.real(eigenvalues)) / np.min(np.real(eigenvalues))
            cond_numpy = np.linalg.cond(A)
            
            print(f"   Condition number (eigenvalues): {cond_eigen:.2e}")
            print(f"   Condition number (NumPy): {cond_numpy:.2e}")
            
            applications['condition_analysis'] = {
                'cond_eigen': cond_eigen,
                'cond_numpy': cond_numpy
            }
        
        # 5. Stability analysis (for transition matrices)
        if matrix_type == 'transition':
            print(f"\n5. STABILITY ANALYSIS (Markov Chain):")
            
            # Find stationary distribution (eigenvector for λ=1)
            unit_eigenvalue_idx = np.argmin(np.abs(eigenvalues - 1))
            stationary_dist = np.real(eigenvectors[:, unit_eigenvalue_idx])
            stationary_dist = np.abs(stationary_dist) / np.sum(np.abs(stationary_dist))
            
            print(f"   Stationary distribution: {stationary_dist}")
            
            # Check convergence rate (second largest eigenvalue)
            sorted_eigenvals = np.sort(np.abs(eigenvalues))[::-1]
            if len(sorted_eigenvals) > 1:
                second_largest = sorted_eigenvals[1]
                mixing_time = -1 / np.log(second_largest) if second_largest < 1 else np.inf
                print(f"   Second largest eigenvalue: {second_largest:.4f}")
                print(f"   Mixing time estimate: {mixing_time:.2f}")
                
                applications['markov_analysis'] = {
                    'stationary_distribution': stationary_dist,
                    'second_largest_eigenvalue': second_largest,
                    'mixing_time': mixing_time
                }
        
        return applications
    
    def create_visualizations(self, A, eigen_results, geometric_results):
        """Create visualizations for small matrices"""
        eigenvalues = eigen_results['eigenvalues']
        eigenvectors = eigen_results['eigenvectors']
        n = A.shape[0]
        
        if n == 2:
            return self.create_2d_visualization(A, eigen_results)
        elif n <= 4:
            return self.create_small_matrix_visualization(A, eigen_results)
        else:
            return self.create_large_matrix_visualizations(A, eigen_results)
    
    def create_2d_visualization(self, A, eigen_results):
        """Create 2D transformation visualization"""
        eigenvalues = eigen_results['eigenvalues']
        eigenvectors = eigen_results['eigenvectors']
        
        fig, axes = plt.subplots(1, 3, figsize=(18, 6))
        
        # Original unit circle and eigenvectors
        theta = np.linspace(0, 2*np.pi, 100)
        unit_circle = np.array([np.cos(theta), np.sin(theta)])
        
        # Transform unit circle
        transformed_circle = A @ unit_circle
        
        # Plot 1: Original space with eigenvectors
        axes[0].plot(unit_circle[0], unit_circle[1], 'b-', linewidth=2, label='Unit circle')
        
        for i in range(2):
            v = eigenvectors[:, i]
            λ = eigenvalues[i]
            
            # Draw eigenvector
            axes[0].arrow(0, 0, v[0], v[1], head_width=0.1, head_length=0.1, 
                         fc=f'C{i}', ec=f'C{i}', linewidth=2, 
                         label=f'v_{i+1} (λ={λ:.2f})')
            
            # Draw negative direction
            axes[0].arrow(0, 0, -v[0], -v[1], head_width=0.05, head_length=0.05, 
                         fc=f'C{i}', ec=f'C{i}', alpha=0.5, linewidth=1)
        
        axes[0].set_xlim(-1.5, 1.5)
        axes[0].set_ylim(-1.5, 1.5)
        axes[0].set_aspect('equal')
        axes[0].grid(True, alpha=0.3)
        axes[0].legend()
        axes[0].set_title('Original Space\n(Unit Circle + Eigenvectors)')
        
        # Plot 2: Transformed space
        axes[1].plot(transformed_circle[0], transformed_circle[1], 'r-', linewidth=2, label='Transformed')
        
        for i in range(2):
            v = eigenvectors[:, i]
            λ = eigenvalues[i]
            
            # Transform eigenvector
            transformed_v = A @ v
            
            axes[1].arrow(0, 0, transformed_v[0], transformed_v[1], 
                         head_width=0.1, head_length=0.1, fc=f'C{i}', ec=f'C{i}', 
                         linewidth=2, label=f'A·v_{i+1} = {λ:.2f}·v_{i+1}')
        
        axes[1].set_aspect('equal')
        axes[1].grid(True, alpha=0.3)
        axes[1].legend()
        axes[1].set_title('Transformed Space\n(A × Unit Circle)')
        
        # Plot 3: Eigenvalue spectrum
        axes[2].scatter(np.real(eigenvalues), np.imag(eigenvalues), 
                       s=100, c=['C0', 'C1'], alpha=0.7)
        
        for i, λ in enumerate(eigenvalues):
            axes[2].annotate(f'λ_{i+1} = {λ:.3f}', 
                           (np.real(λ), np.imag(λ)), 
                           xytext=(5, 5), textcoords='offset points')
        
        axes[2].axhline(y=0, color='k', linestyle='-', alpha=0.3)
        axes[2].axvline(x=0, color='k', linestyle='-', alpha=0.3)
        axes[2].grid(True, alpha=0.3)
        axes[2].set_xlabel('Real Part')
        axes[2].set_ylabel('Imaginary Part')
        axes[2].set_title('Eigenvalue Spectrum')
        
        plt.tight_layout()
        plt.show()
        
        return {'2d_visualization_created': True}
    
    def create_large_matrix_visualizations(self, A, eigen_results):
        """Create visualizations for larger matrices"""
        eigenvalues = eigen_results['eigenvalues']
        eigenvectors = eigen_results['eigenvectors']
        
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        
        # Matrix heatmap
        im1 = axes[0, 0].imshow(A, cmap='RdBu_r', aspect='auto')
        axes[0, 0].set_title('Matrix A')
        plt.colorbar(im1, ax=axes[0, 0])
        
        # Eigenvalue spectrum
        axes[0, 1].scatter(np.real(eigenvalues), np.imag(eigenvalues), alpha=0.7, s=50)
        axes[0, 1].axhline(y=0, color='k', linestyle='-', alpha=0.3)
        axes[0, 1].axvline(x=0, color='k', linestyle='-', alpha=0.3)
        axes[0, 1].set_xlabel('Real Part')
        axes[0, 1].set_ylabel('Imaginary Part')
        axes[0, 1].set_title('Eigenvalue Spectrum')
        axes[0, 1].grid(True, alpha=0.3)
        
        # Eigenvalue magnitudes
        axes[0, 2].bar(range(len(eigenvalues)), np.abs(eigenvalues), alpha=0.7)
        axes[0, 2].set_xlabel('Index')
        axes[0, 2].set_ylabel('|λ|')
        axes[0, 2].set_title('Eigenvalue Magnitudes')
        axes[0, 2].grid(True, alpha=0.3)
        
        # First few eigenvectors
        n_show = min(3, eigenvectors.shape[1])
        for i in range(n_show):
            axes[1, i].plot(np.real(eigenvectors[:, i]), 'o-', alpha=0.7, 
                           label=f'Real(v_{i+1})')
            if not np.allclose(np.imag(eigenvectors[:, i]), 0):
                axes[1, i].plot(np.imag(eigenvectors[:, i]), 's--', alpha=0.7, 
                               label=f'Imag(v_{i+1})')
            axes[1, i].set_xlabel('Component')
            axes[1, i].set_ylabel('Value')
            axes[1, i].set_title(f'Eigenvector {i+1}\n(λ={eigenvalues[i]:.3f})')
            axes[1, i].legend()
            axes[1, i].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.show()
        
        return {'large_matrix_visualization_created': True}
    
    def explain_ml_connections(self, eigen_results, application_results):
        """Explain connections to machine learning"""
        print(f"\n🧠 MACHINE LEARNING CONNECTIONS")
        print("=" * 60)
        
        eigenvalues = eigen_results['eigenvalues']
        
        print(f"🎯 PRINCIPAL COMPONENT ANALYSIS (PCA):")
        print(f"   - Eigendecomposition of covariance matrix")
        print(f"   - Eigenvectors = principal components")
        print(f"   - Eigenvalues = explained variance")
        print(f"   - Dimensionality reduction via top eigenvectors")
        
        print(f"\n📊 SPECTRAL CLUSTERING:")
        print(f"   - Eigendecomposition of graph Laplacian")
        print(f"   - Bottom eigenvectors reveal cluster structure")
        print(f"   - Number of zero eigenvalues = number of components")
        
        print(f"\n🔗 PAGERANK ALGORITHM:")
        print(f"   - Dominant eigenvector of transition matrix")
        print(f"   - Eigenvalue λ=1 corresponds to stationary distribution")
        print(f"   - Convergence rate determined by second eigenvalue")
        
        print(f"\n🎭 NEURAL NETWORK ANALYSIS:")
        print(f"   - Weight matrix eigenvalues affect gradient flow")
        print(f"   - Spectral radius determines stability")
        
        if len(eigenvalues) > 0:
            spectral_radius = np.max(np.abs(eigenvalues))
            print(f"   - Current spectral radius: {spectral_radius:.3f}")
            
            if spectral_radius > 1.1:
                print(f"   ⚠️  Large spectral radius → potential exploding gradients")
            elif spectral_radius < 0.9:
                print(f"   ⚠️  Small spectral radius → potential vanishing gradients")
            else:
                print(f"   ✓ Good spectral radius for training stability")
        
        print(f"\n⚡ OPTIMIZATION LANDSCAPES:")
        print(f"   - Hessian eigenvalues determine convergence")
        print(f"   - Condition number affects optimization difficulty")
        print(f"   - Negative eigenvalues indicate saddle points")
        
        if 'condition_analysis' in application_results:
            cond_num = application_results['condition_analysis']['cond_eigen']
            print(f"   - Current condition number: {cond_num:.2e}")
            
            if cond_num > 1e6:
                print(f"   ⚠️  Ill-conditioned → optimization challenges")
            elif cond_num > 1e3:
                print(f"   ⚠️  Moderately conditioned")
            else:
                print(f"   ✓ Well-conditioned for optimization")
        
        print(f"\n🎨 DIMENSIONALITY REDUCTION:")
        print(f"   - Keep eigenvectors with largest eigenvalues")
        print(f"   - Trade-off between compression and information loss")
        print(f"   - Applications: visualization, feature extraction, noise reduction")
        
        print(f"\n🔍 MODEL INTERPRETABILITY:")
        print(f"   - Eigenvectors reveal important directions in data")
        print(f"   - Eigenvalue ratios show relative importance")
        print(f"   - Can identify dominant patterns and outliers")
    
    def get_result_explanation_question(self, results: Dict[str, Any]) -> str:
        eigen_results = results["eigen_results"]
        eigenvalue_analysis = results["eigenvalue_analysis"]
        matrix_type = results["matrix_type"]
        
        eigenvalues = eigen_results["eigenvalues"]
        spectral_radius = eigenvalue_analysis["spectral_radius"]
        condition_number = eigenvalue_analysis["condition_number"]
        definiteness = eigenvalue_analysis["definiteness"]
        
        return f"""
Analyzing the eigenvalue decomposition results:

MATRIX PROPERTIES:
- Type: {matrix_type}
- Size: {results["test_matrix"].shape}
- All eigenvalues real: {eigen_results["all_real"]}

EIGENVALUE ANALYSIS:
- Largest eigenvalue: {eigenvalues[0]:.4f}
- Smallest eigenvalue: {eigenvalues[-1]:.4f}
- Spectral radius: {spectral_radius:.4f}
- Condition number: {condition_number:.2e}
- Definiteness: {definiteness}

QUESTIONS:

1. Eigenvalue Interpretation:
   - What do the eigenvalues tell you about the linear transformation?
   - How do positive vs. negative eigenvalues affect the transformation?
   - What would zero eigenvalues indicate about the matrix?

2. Geometric Understanding:
   - How do eigenvectors represent "natural directions" of the transformation?
   - What happens to vectors along eigenvector directions?
   - How does the spectral radius relate to the transformation's "strength"?

3. Stability and Conditioning:
   - What does the condition number {condition_number:.2e} tell you about numerical stability?
   - How would this affect solving linear systems with this matrix?
   - What are the implications for iterative algorithms?

4. Machine Learning Applications:
   - If this were a covariance matrix, what would the eigenvalues represent?
   - How could you use these eigenvectors for dimensionality reduction?
   - What would this eigendecomposition tell you about data structure?

5. Optimization Perspectives:
   - If this were a Hessian matrix, what would the eigenvalues indicate?
   - How does the definiteness ({definiteness}) affect optimization?
   - What would negative eigenvalues suggest about the optimization landscape?

6. Practical Considerations:
   - How would you choose which eigenvectors to keep for compression?
   - What trade-offs exist between compression and information preservation?
   - How might you use this analysis to improve a machine learning model?

7. Comparison with SVD:
   - How does eigendecomposition compare to SVD for your matrix?
   - When would you prefer one over the other?
   - What are the computational trade-offs?
        """

# Test function for the exercise
def test_exercise_10():
    """Test function for Exercise 10"""
    print("Testing Exercise 10: Eigenvalues and Eigenvectors")
    
    # Mock logging system for testing
    class MockLoggingSystem:
        def set_current_exercise(self, ex_num, step): pass
        def complete_step(self, ex_num, step): pass
        def complete_exercise(self, ex_num): pass
        def log_student_response(self, ex_num, step, question, response): 
            print(f"Logged: {response}")
    
    mock_logger = MockLoggingSystem()
    exercise = Exercise10(mock_logger)
    
    # Test parameters
    test_params = {
        "matrix_type": "symmetric",
        "matrix_size": 4,
        "condition_number": 10,
        "random_seed": 42
    }
    
    try:
        results = exercise.execute_exercise(test_params)
        print("✓ Exercise 10 test completed successfully!")
        return True
    except Exception as e:
        print(f"❌ Exercise 10 test failed: {e}")
        return False

if __name__ == "__main__":
    test_exercise_10()