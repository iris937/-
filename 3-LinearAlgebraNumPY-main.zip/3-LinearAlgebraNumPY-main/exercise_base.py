# exercise_base.py
"""
Base class for all exercises in the Linear Algebra learning system
Provides common functionality for concept explanation, step management, and logging
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
import numpy as np
import matplotlib.pyplot as plt
from logging_system import LoggingSystem

class ExerciseBase(ABC):
    def __init__(self, logging_system: LoggingSystem, exercise_num: int, title: str):
        self.logging_system = logging_system
        self.exercise_num = exercise_num
        self.title = title
        self.current_step = "start"
        
        # Define the steps for this exercise
        self.steps = self.define_steps()
    
    @abstractmethod
    def define_steps(self) -> list:
        """Define the steps for this exercise. Must be implemented by subclasses."""
        pass
    
    @abstractmethod
    def get_concept_explanation(self) -> str:
        """Get the concept explanation. Must be implemented by subclasses."""
        pass
    
    @abstractmethod
    def get_concept_question(self) -> str:
        """Get a question about the concept. Must be implemented by subclasses."""
        pass
    
    @abstractmethod
    def execute_exercise(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the main exercise. Must be implemented by subclasses."""
        pass
    
    @abstractmethod
    def get_result_explanation_question(self, results: Dict[str, Any]) -> str:
        """Get a question about the results. Must be implemented by subclasses."""
        pass
    
    @abstractmethod
    def get_required_parameters(self) -> Dict[str, str]:
        """Get required parameters for the exercise. Must be implemented by subclasses."""
        pass
    
    def run(self, resume_step: Optional[str] = None) -> bool:
        """Run the exercise with step-by-step progression"""
        self.logging_system.set_current_exercise(self.exercise_num, "start")
        
        # Determine starting step
        if resume_step:
            self.current_step = resume_step
            print(f"\n▶ Resuming from step: {resume_step}")
        else:
            self.current_step = "start"
        
        try:
            # Step 1: Explain concept
            if self.current_step == "start" or self.current_step == "concept_explanation":
                if not self.step_concept_explanation():
                    return False
            
            # Step 2: Concept understanding check
            if self.current_step in ["start", "concept_explanation", "concept_check"]:
                if not self.step_concept_check():
                    return False
            
            # Step 3: Get parameters
            if self.current_step in ["start", "concept_explanation", "concept_check", "parameters"]:
                params = self.step_get_parameters()
                if params is None:
                    return False
            else:
                # If resuming from later step, we need to get params again
                params = self.step_get_parameters()
                if params is None:
                    return False
            
            # Step 4: Execute exercise
            if self.current_step in ["start", "concept_explanation", "concept_check", "parameters", "execution"]:
                results = self.step_execute_exercise(params)
                if results is None:
                    return False
            
            # Step 5: Explain results
            if self.current_step in ["start", "concept_explanation", "concept_check", "parameters", "execution", "results"]:
                if not self.step_explain_results(results):
                    return False
            
            # Step 6: Complete exercise
            self.step_complete_exercise()
            return True
            
        except KeyboardInterrupt:
            print("\n\n⚠ Exercise interrupted by user")
            self.logging_system.set_current_exercise(self.exercise_num, self.current_step)
            print(f"Progress saved at step: {self.current_step}")
            return False
        except Exception as e:
            print(f"\n❌ Error in exercise: {e}")
            return False
    
    def step_concept_explanation(self) -> bool:
        """Step 1: Explain the concept"""
        self.current_step = "concept_explanation"
        self.logging_system.set_current_exercise(self.exercise_num, self.current_step)
        
        print(f"\n📚 CONCEPT EXPLANATION: {self.title}")
        print("=" * 60)
        print(self.get_concept_explanation())
        print("=" * 60)
        
        # Wait for user confirmation
        while True:
            response = input("\nDo you understand the concept? (y/n/q to quit): ").lower().strip()
            if response == 'y':
                self.logging_system.complete_step(self.exercise_num, "concept_explanation")
                return True
            elif response == 'n':
                print("\nLet me explain again...")
                print(self.get_concept_explanation())
            elif response == 'q':
                return False
            else:
                print("Please answer 'y' for yes, 'n' for no, or 'q' to quit.")
    
    def step_concept_check(self) -> bool:
        """Step 2: Check concept understanding"""
        self.current_step = "concept_check"
        self.logging_system.set_current_exercise(self.exercise_num, self.current_step)
        
        print("\n❓ CONCEPT CHECK")
        print("=" * 30)
        
        question = self.get_concept_question()
        print(f"Question: {question}")
        
        answer = input("\nYour answer: ").strip()
        
        # Log the response
        self.logging_system.log_student_response(
            self.exercise_num, 
            "concept_check", 
            question, 
            answer
        )
        
        print("✓ Your answer has been recorded.")
        
        self.logging_system.complete_step(self.exercise_num, "concept_check")
        return True
    
    def step_get_parameters(self) -> Optional[Dict[str, Any]]:
        """Step 3: Get required parameters from user"""
        self.current_step = "parameters"
        self.logging_system.set_current_exercise(self.exercise_num, self.current_step)
        
        print("\n⚙️ PARAMETER INPUT")
        print("=" * 30)
        
        required_params = self.get_required_parameters()
        params = {}
        
        for param_name, param_description in required_params.items():
            while True:
                try:
                    value_str = input(f"{param_description}: ").strip()
                    
                    # Try to convert to number if possible
                    if value_str.replace('.', '').replace('-', '').isdigit():
                        if '.' in value_str:
                            params[param_name] = float(value_str)
                        else:
                            params[param_name] = int(value_str)
                    else:
                        params[param_name] = value_str
                    break
                except KeyboardInterrupt:
                    return None
                except:
                    print("Invalid input, please try again.")
        
        # Log parameters
        self.logging_system.log_student_response(
            self.exercise_num,
            "parameters",
            f"Parameters for {self.title}",
            str(params)
        )
        
        self.logging_system.complete_step(self.exercise_num, "parameters")
        return params
    
    def step_execute_exercise(self, params: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Step 4: Execute the exercise"""
        self.current_step = "execution"
        self.logging_system.set_current_exercise(self.exercise_num, self.current_step)
        
        print("\n🔬 EXECUTING EXERCISE")
        print("=" * 30)
        print("Running calculations and generating visualizations...")
        
        try:
            results = self.execute_exercise(params)
            print("✓ Exercise completed successfully!")
            
            self.logging_system.complete_step(self.exercise_num, "execution")
            return results
            
        except Exception as e:
            print(f"❌ Error during execution: {e}")
            return None
    
    def step_explain_results(self, results: Dict[str, Any]) -> bool:
        """Step 5: Get explanation of results from student"""
        self.current_step = "results"
        self.logging_system.set_current_exercise(self.exercise_num, self.current_step)
        
        print("\n📊 RESULTS ANALYSIS")
        print("=" * 30)
        
        question = self.get_result_explanation_question(results)
        print(f"Question: {question}")
        
        explanation = input("\nYour explanation: ").strip()
        
        # Log the explanation
        self.logging_system.log_student_response(
            self.exercise_num,
            "results_explanation",
            question,
            explanation
        )
        
        print("✓ Your explanation has been recorded.")
        
        self.logging_system.complete_step(self.exercise_num, "results")
        return True
    
    def step_complete_exercise(self):
        """Step 6: Complete the exercise"""
        self.logging_system.complete_exercise(self.exercise_num)
        print(f"\n🎉 Exercise {self.exercise_num} completed successfully!")
        
        # Ask if they want to continue to next exercise
        if self.exercise_num < 11:
            continue_choice = input(f"\nReady for the next exercise? (y/n): ").lower().strip()
            if continue_choice != 'y':
                print("You can continue later from the main menu.")
        else:
            print("🎊 Congratulations! You've completed all exercises!")
    
    # Utility methods for common operations
    def create_figure(self, figsize=(10, 6)):
        """Create a matplotlib figure"""
        plt.figure(figsize=figsize)
        return plt
    
    def show_plot(self, title: str = ""):
        """Show a matplotlib plot"""
        if title:
            plt.title(title)
        plt.tight_layout()
        plt.show()
    
    def print_table(self, data: Dict[str, Any], title: str = "Results"):
        """Print data in a formatted table"""
        print(f"\n📋 {title}")
        print("-" * (len(title) + 5))
        for key, value in data.items():
            if isinstance(value, (np.ndarray, list)):
                if hasattr(value, 'shape') and len(value.shape) > 1:
                    print(f"{key}:")
                    print(f"  Shape: {value.shape}")
                    print(f"  Data:\n{value}")
                else:
                    print(f"{key}: {value}")
            else:
                print(f"{key}: {value}")
    
    def save_step_progress(self, step_name: str):
        """Save progress for a specific step"""
        self.current_step = step_name
        self.logging_system.set_current_exercise(self.exercise_num, step_name)