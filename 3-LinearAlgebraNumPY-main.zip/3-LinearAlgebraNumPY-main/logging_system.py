# logging_system.py
"""
Logging System for tracking student progress and responses
Manages session state, student answers, and progress persistence
"""

import json
import os
from datetime import datetime
from typing import Dict, Any, Optional
import shutil

class LoggingSystem:
    def __init__(self):
        self.logs_dir = "logs"
        self.progress_file = os.path.join(self.logs_dir, "progress.json")
        self.session_file = os.path.join(self.logs_dir, "current_session.json")
        self.responses_file = os.path.join(self.logs_dir, "student_responses.json")
        self.backup_dir = os.path.join(self.logs_dir, "backups")
        
        # Ensure directories exist
        os.makedirs(self.logs_dir, exist_ok=True)
        os.makedirs(self.backup_dir, exist_ok=True)
        
        self.session_data = self.load_session()
        
    def load_session(self) -> Dict[str, Any]:
        """Load current session data"""
        if os.path.exists(self.session_file):
            with open(self.session_file, 'r') as f:
                return json.load(f)
        return {}
    
    def save_session(self):
        """Save current session data"""
        with open(self.session_file, 'w') as f:
            json.dump(self.session_data, f, indent=2)
    
    def load_progress(self) -> Dict[str, Any]:
        """Load overall progress data"""
        if os.path.exists(self.progress_file):
            with open(self.progress_file, 'r') as f:
                return json.load(f)
        return {}
    
    def save_progress(self, progress_data: Dict[str, Any]):
        """Save overall progress data"""
        with open(self.progress_file, 'w') as f:
            json.dump(progress_data, f, indent=2)
    
    def load_responses(self) -> Dict[str, Any]:
        """Load student responses"""
        if os.path.exists(self.responses_file):
            with open(self.responses_file, 'r') as f:
                return json.load(f)
        return {}
    
    def save_responses(self, responses_data: Dict[str, Any]):
        """Save student responses"""
        with open(self.responses_file, 'w') as f:
            json.dump(responses_data, f, indent=2)
    
    def start_new_session(self):
        """Start a new learning session"""
        self.session_data = {
            "session_id": datetime.now().strftime("%Y%m%d_%H%M%S"),
            "start_time": datetime.now().isoformat(),
            "current_exercise": None,
            "current_step": None,
            "steps_completed": []
        }
        self.save_session()
        
        # Update progress
        progress = self.load_progress()
        progress["session_start"] = datetime.now().isoformat()
        progress["last_activity"] = datetime.now().isoformat()
        self.save_progress(progress)
    
    def set_current_exercise(self, exercise_num: int, step: str = "start"):
        """Set the current exercise and step"""
        self.session_data["current_exercise"] = exercise_num
        self.session_data["current_step"] = step
        self.session_data["last_activity"] = datetime.now().isoformat()
        self.save_session()
        
        # Update progress
        progress = self.load_progress()
        progress["current_exercise"] = exercise_num
        progress["current_step"] = step
        progress["last_activity"] = datetime.now().isoformat()
        self.save_progress(progress)
    
    def complete_step(self, exercise_num: int, step: str):
        """Mark a step as completed"""
        step_key = f"ex_{exercise_num}_{step}"
        if step_key not in self.session_data.get("steps_completed", []):
            self.session_data.setdefault("steps_completed", []).append(step_key)
        
        self.session_data["last_activity"] = datetime.now().isoformat()
        self.save_session()
        
        # Update progress
        progress = self.load_progress()
        progress.setdefault("completed_steps", [])
        if step_key not in progress["completed_steps"]:
            progress["completed_steps"].append(step_key)
        progress["last_activity"] = datetime.now().isoformat()
        self.save_progress(progress)
    
    def complete_exercise(self, exercise_num: int):
        """Mark an exercise as completed"""
        progress = self.load_progress()
        progress.setdefault("completed_exercises", [])
        if exercise_num not in progress["completed_exercises"]:
            progress["completed_exercises"].append(exercise_num)
        
        progress["last_activity"] = datetime.now().isoformat()
        
        # Clear current exercise from progress
        if progress.get("current_exercise") == exercise_num:
            progress["current_exercise"] = None
            progress["current_step"] = None
        
        self.save_progress(progress)
        
        # Update session
        self.session_data["current_exercise"] = None
        self.session_data["current_step"] = None
        self.save_session()
    
    def log_student_response(self, exercise_num: int, step: str, question: str, response: str):
        """Log a student's response to a question"""
        responses = self.load_responses()
        
        session_id = self.session_data.get("session_id", "unknown")
        timestamp = datetime.now().isoformat()
        
        response_entry = {
            "session_id": session_id,
            "timestamp": timestamp,
            "exercise": exercise_num,
            "step": step,
            "question": question,
            "response": response
        }
        
        # Add to responses log
        responses.setdefault("responses", []).append(response_entry)
        self.save_responses(responses)
        
        print(f"✓ Response logged: {timestamp}")
    
    def get_exercise_status(self, exercise_num: int) -> str:
        """Get the status of an exercise"""
        progress = self.load_progress()
        
        if exercise_num in progress.get("completed_exercises", []):
            return "COMPLETED"
        elif progress.get("current_exercise") == exercise_num:
            return "IN PROGRESS"
        else:
            # Check if any steps were completed
            completed_steps = progress.get("completed_steps", [])
            exercise_steps = [step for step in completed_steps if step.startswith(f"ex_{exercise_num}_")]
            if exercise_steps:
                return "PARTIAL"
            else:
                return "NOT STARTED"
    
    def backup_progress(self):
        """Create a backup of current progress"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_subdir = os.path.join(self.backup_dir, f"backup_{timestamp}")
        os.makedirs(backup_subdir, exist_ok=True)
        
        # Backup all log files
        for filename in [self.progress_file, self.session_file, self.responses_file]:
            if os.path.exists(filename):
                shutil.copy2(filename, backup_subdir)
        
        print(f"✓ Progress backed up to: {backup_subdir}")
    
    def reset_progress(self):
        """Reset all progress (with backup)"""
        # Create backup first
        self.backup_progress()
        
        # Clear all files
        for filename in [self.progress_file, self.session_file, self.responses_file]:
            if os.path.exists(filename):
                os.remove(filename)
        
        # Reset session data
        self.session_data = {}
        
        print("✓ All progress reset successfully!")
    
    def get_student_responses(self, exercise_num: Optional[int] = None) -> list:
        """Get student responses, optionally filtered by exercise"""
        responses = self.load_responses()
        all_responses = responses.get("responses", [])
        
        if exercise_num is not None:
            return [r for r in all_responses if r["exercise"] == exercise_num]
        
        return all_responses
    
    def print_progress_summary(self):
        """Print a summary of current progress"""
        progress = self.load_progress()
        responses = self.load_responses()
        
        print("\n" + "="*50)
        print("PROGRESS SUMMARY")
        print("="*50)
        
        completed = len(progress.get("completed_exercises", []))
        total_responses = len(responses.get("responses", []))
        
        print(f"Exercises completed: {completed}/11")
        print(f"Total responses logged: {total_responses}")
        
        if progress.get("session_start"):
            print(f"Session started: {progress['session_start']}")
        if progress.get("last_activity"):
            print(f"Last activity: {progress['last_activity']}")
        
        current_ex = progress.get("current_exercise")
        if current_ex:
            print(f"Currently working on: Exercise {current_ex}")
            current_step = progress.get("current_step")
            if current_step:
                print(f"Current step: {current_step}")
    
    def is_step_completed(self, exercise_num: int, step: str) -> bool:
        """Check if a specific step is completed"""
        progress = self.load_progress()
        step_key = f"ex_{exercise_num}_{step}"
        return step_key in progress.get("completed_steps", [])
    
    def get_current_session_info(self) -> Dict[str, Any]:
        """Get current session information"""
        return {
            "session_data": self.session_data,
            "progress": self.load_progress()
        }